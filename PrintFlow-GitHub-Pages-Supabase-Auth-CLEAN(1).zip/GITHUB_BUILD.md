# Deploy PrintFlow ke GitHub Pages

## Alur aplikasi
- Login hanya meminta **Username + Password**.
- Tidak ada pilihan role manual.
- Role otomatis mengikuti akun Supabase Auth: MASTER, ADMIN, DESAINER, OPERATOR_CETAK, FINISHING_QC, atau CLIENT.
- Username tenant dibuat dengan email internal `username@taskprint.local` di Supabase Auth.
- Akun Master tunggal menggunakan `mdqputra@gmail.com` dan username `mdqputra`.
- GitHub Pages hanya menjalankan frontend React/Vite.
- Operasi yang membutuhkan hak istimewa tetap melalui Supabase Edge Functions agar Service Role Key tidak pernah masuk ke browser.

## Secrets GitHub yang diperlukan
1. `VITE_SUPABASE_URL`
2. `VITE_SUPABASE_PUBLISHABLE_KEY`
3. `SUPABASE_ACCESS_TOKEN`
4. `SUPABASE_PROJECT_REF`

Tidak perlu `GEMINI_API_KEY` di GitHub Actions. Jika AI Assistant dipakai, simpan `GEMINI_API_KEY` sebagai secret di Supabase Edge Functions.

## Supabase
1. Jalankan `supabase-schema.sql` di Supabase SQL Editor.
2. Pastikan akun Auth Master dibuat dengan email `mdqputra@gmail.com`.
3. Set password Master dari Supabase Dashboard/Auth. Password jangan disimpan di GitHub, SQL, atau file frontend.
4. Trigger schema akan memberi role `MASTER` hanya kepada email tersebut.

## GitHub Pages
Repository: `kamaar05-dotcom/Task-print`

Base path Vite: `/Task-print/`

Workflow: `.github/workflows/main.yml`
