import { Tenant, User, Order, OrderStatus, OrderTrackingInfo, MasterStats, TenantPlan, Role } from '../types.js';
import { supabase } from './supabase.js';

async function edge<T>(functionName: string, body: Record<string, unknown> = {}): Promise<T> {
  const { data, error } = await supabase.functions.invoke(functionName, { body });
  if (error) {
    try {
      const response = (error as any).context;
      if (response && typeof response.json === 'function') {
        const payload = await response.json();
        throw new Error(payload?.message || payload?.error || error.message);
      }
    } catch (nested) {
      if (nested instanceof Error && nested.message) throw nested;
    }
    throw new Error(error.message || `Gagal memanggil ${functionName}`);
  }
  if (data?.error) throw new Error(data.message || data.error);
  return data as T;
}

function mapTenant(t: any): Tenant {
  return {
    id: t.id, name: t.name, code: t.code, plan: t.plan as TenantPlan,
    trackingEnabled: Boolean(t.tracking_enabled), phone: t.phone || '', address: t.address || '',
    status: t.status, createdAt: t.created_at,
  };
}

function mapProfile(p: any, tenant?: any): User & { tenant?: Tenant | null } {
  return {
    id: p.id, username: p.username, email: p.email, name: p.name, role: p.role as Role,
    phone: p.phone || '', tenantId: p.tenant_id || null, tenantName: tenant?.name || (p.role === 'MASTER' ? 'Master Platform' : 'Tenant'),
    tenantPlan: tenant?.plan as TenantPlan | undefined, tenant: tenant ? mapTenant(tenant) : null, createdAt: p.created_at,
  };
}

function mapOrder(o: any): Order {
  return {
    id: o.id, tenantId: o.tenant_id, orderNumber: o.order_number, trackingCode: o.tracking_code,
    customerName: o.customer_name, customerWhatsapp: o.customer_whatsapp, jobType: o.job_type, size: o.size,
    material: o.material, quantity: Number(o.quantity), unit: o.unit, finishing: o.finishing || '', deadline: o.deadline,
    notes: o.notes || '', needsDesign: Boolean(o.needs_design), pic: o.pic || '', status: o.status as OrderStatus,
    files: (o.order_files || []).map((f: any) => ({ id: f.id, name: f.name, fileType: f.file_type, category: f.category, url: f.url, size: f.size, uploadedBy: f.uploaded_by, uploadedAt: f.created_at })),
    timeline: (o.order_timeline || []).sort((a: any,b: any) => new Date(a.created_at).getTime()-new Date(b.created_at).getTime()).map((t: any) => ({ id:t.id,status:t.status as OrderStatus,title:t.title,note:t.note||'',actorName:t.actor_name,actorRole:t.actor_role,timestamp:t.created_at })),
    createdAt: o.created_at, updatedAt: o.updated_at,
  };
}

export interface AITaskPrintOrder { id:string; orderNumber:string; customerName:string; jobType:string; size:string; material:string; quantity:number; unit:string; deadline:string; pic:string; status:string; statusLabel:string; nextStep:string; needsDesign:boolean; notes:string; approvalInfo?:string; }
export interface AITaskPrintResponse { answer:string; orders:AITaskPrintOrder[]; dataUpdatedAt:string; source:'supabase'|'demo'; tenantId:string; }

export const aiTaskPrintApi = {
  ask: async (payload: { question:string; filters?: { customer?:string; orderNumber?:string; pic?:string; status?:string; deadline?:'TODAY'|'TOMORROW'|'OVERDUE' } }) =>
    edge<AITaskPrintResponse>('ai-task-print', payload),
};

export const authApi = {
  login: async (username:string, password:string) => {
    const value = String(username).trim().toLowerCase();
    const email = value.includes('@') ? value : (value === 'mdqputra' ? 'mdqputra@gmail.com' : `${value}@taskprint.local`);
    const { data, error } = await supabase.auth.signInWithPassword({ email, password: String(password) });
    if (error || !data.session) throw new Error('Username atau password salah.');
    return data.session;
  },
  getMe: async () => {
    const { data:{ user: authUser }, error } = await supabase.auth.getUser();
    if (error || !authUser) throw new Error('Sesi Supabase tidak valid.');
    const { data: profile, error: pErr } = await supabase.from('profiles').select('*').eq('id', authUser.id).single();
    if (pErr || !profile) throw new Error('Profil pengguna belum tersedia di Supabase.');
    let tenant = null;
    if (profile.tenant_id) {
      const { data } = await supabase.from('tenants').select('*').eq('id', profile.tenant_id).single();
      tenant = data;
    }
    return mapProfile(profile, tenant);
  },
};

export const masterApi = {
  getSetupStatus: async () => ({ isConfigured:true, email:'mdqputra@gmail.com', name:'Master Platform Owner', username:'mdqputra' }),
  setupPassword: async (_payload:{email:string;password:string;currentPassword?:string}) => { throw new Error('Gunakan pengaturan password Supabase Auth untuk akun Master.'); },
  getTenants: async () => {
    const { data, error } = await supabase.from('tenants').select('*').order('created_at',{ascending:false});
    if (error) throw new Error(error.message);
    const out = [] as Array<Tenant & {orderCount:number;userCount:number}>;
    for (const t of data || []) {
      const [{count:orderCount},{count:userCount}] = await Promise.all([
        supabase.from('orders').select('*',{count:'exact',head:true}).eq('tenant_id',t.id),
        supabase.from('profiles').select('*',{count:'exact',head:true}).eq('tenant_id',t.id),
      ]);
      out.push({...mapTenant(t),orderCount:orderCount||0,userCount:userCount||0});
    }
    return out;
  },
  getStats: async () => {
    const [{count:totalTenants},{count:activeTenants},{count:basicTenantsCount},{count:premiumTenantsCount},{count:totalOrdersAcrossPlatform}] = await Promise.all([
      supabase.from('tenants').select('*',{count:'exact',head:true}),
      supabase.from('tenants').select('*',{count:'exact',head:true}).eq('status','ACTIVE'),
      supabase.from('tenants').select('*',{count:'exact',head:true}).eq('plan','BASIC'),
      supabase.from('tenants').select('*',{count:'exact',head:true}).eq('plan','PREMIUM'),
      supabase.from('orders').select('*',{count:'exact',head:true}),
    ]);
    return {totalTenants:totalTenants||0,activeTenants:activeTenants||0,basicTenantsCount:basicTenantsCount||0,premiumTenantsCount:premiumTenantsCount||0,totalOrdersAcrossPlatform:totalOrdersAcrossPlatform||0} as MasterStats;
  },
  createTenant: async (payload:any) => edge<{tenant:Tenant;admin:User}>('master-create-tenant', payload),
  updateTenant: async (id:string,payload:any) => {
    const patch:any = {...payload};
    if (patch.plan) patch.tracking_enabled = patch.plan === 'PREMIUM';
    delete patch.plan;
    const { data,error } = await supabase.from('tenants').update({...patch,updated_at:new Date().toISOString()}).eq('id',id).select().single();
    if (error) throw new Error(error.message);
    return mapTenant(data);
  },
};

export const userApi = {
  getUsers: async (tenantId?:string) => {
    let q = supabase.from('profiles').select('*,tenants(*)').neq('role','MASTER').order('created_at');
    if (tenantId) q = q.eq('tenant_id',tenantId);
    const {data,error}=await q;
    if(error) throw new Error(error.message);
    return (data||[]).map((p:any)=>mapProfile(p,p.tenants));
  },
  createUser: async (payload:any) => edge<User>('admin-create-user', payload),
  deleteUser: async (id:string) => edge<{message:string}>('admin-delete-user',{userId:id}),
};

export const orderApi = {
  getOrders: async (tenantId?:string) => {
    let q = supabase.from('orders').select('*,order_files(*),order_timeline(*)').order('created_at',{ascending:false});
    if (tenantId) q=q.eq('tenant_id',tenantId);
    const {data,error}=await q; if(error) throw new Error(error.message); return (data||[]).map(mapOrder);
  },
  getOrderById: async (id:string) => { const {data,error}=await supabase.from('orders').select('*,order_files(*),order_timeline(*)').eq('id',id).single(); if(error) throw new Error(error.message); return mapOrder(data); },
  createOrder: async (payload:any) => {
    const {data:{user},error:ue}=await supabase.auth.getUser(); if(ue||!user) throw new Error('Sesi login tidak valid.');
    const {data:profile}=await supabase.from('profiles').select('tenant_id,name').eq('id',user.id).single();
    if(!profile?.tenant_id) throw new Error('Akun tidak memiliki tenant.');
    const {data:tenant}=await supabase.from('tenants').select('code').eq('id',profile.tenant_id).single();
    const prefix=(tenant?.code||'ORD').toUpperCase(); const now=new Date(); const ym=`${now.getFullYear()}${String(now.getMonth()+1).padStart(2,'0')}`;
    const orderNumber=`${prefix}-${ym}-${Date.now().toString().slice(-6)}`;
    const trackingCode=`trk-${prefix.toLowerCase()}-${crypto.randomUUID().replaceAll('-','').slice(0,12)}`;
    const {data,error}=await supabase.from('orders').insert({tenant_id:profile.tenant_id,order_number:orderNumber,tracking_code:trackingCode,customer_name:payload.customerName.trim(),customer_whatsapp:(payload.customerWhatsapp||'').replace(/[^0-9]/g,''),job_type:payload.jobType.trim(),size:payload.size||'-',material:payload.material||'-',quantity:Number(payload.quantity)||1,unit:payload.unit||'pcs',finishing:payload.finishing||'Tanpa finishing tambahan',deadline:payload.deadline?new Date(payload.deadline).toISOString():new Date(Date.now()+172800000).toISOString(),notes:payload.notes||'',needs_design:Boolean(payload.needsDesign),pic:payload.pic||profile.name,status:'PESANAN_MASUK'}).select().single();
    if(error) throw new Error(error.message);
    const {error:tlError}=await supabase.from('order_timeline').insert({order_id:data.id,tenant_id:profile.tenant_id,status:'PESANAN_MASUK',title:'Pesanan Masuk & Didaftarkan',note:`Order dibuat oleh ${profile.name}. ${payload.needsDesign?'Membutuhkan bantuan desain.':'File siap cetak (tanpa desain).'}`,actor_name:profile.name,actor_role:'ADMIN'});
    if(tlError) console.warn(tlError.message);
    return mapOrder({...data,order_files:[],order_timeline:[]});
  },
  updateStatus: async (id:string,nextStatus:OrderStatus,note?:string) => {
    const {data:{user}}=await supabase.auth.getUser(); if(!user) throw new Error('Sesi login tidak valid.');
    const {data:profile}=await supabase.from('profiles').select('tenant_id,name,role').eq('id',user.id).single(); if(!profile?.tenant_id) throw new Error('Tenant tidak ditemukan.');
    const {error}=await supabase.from('orders').update({status:nextStatus,updated_at:new Date().toISOString()}).eq('id',id).eq('tenant_id',profile.tenant_id); if(error) throw new Error(error.message);
    const titles:any={PESANAN_MASUK:'Pesanan Masuk',VERIFIKASI:'Verifikasi Spesifikasi & Kelayakan',DESAIN:'Proses Pengerjaan Desain',APPROVAL:'Menunggu Approval Konsumen',PRODUKSI_CETAK:'Proses Produksi / Cetak',FINISHING_QC:'Tahap Finishing & Quality Control',SIAP_DIAMBIL_DIKIRIM:'Siap Diambil / Siap Dikirim',SELESAI:'Pesanan Selesai Diterima'};
    await supabase.from('order_timeline').insert({order_id:id,tenant_id:profile.tenant_id,status:nextStatus,title:titles[nextStatus]||nextStatus,note:note||`Status diperbarui menjadi ${titles[nextStatus]||nextStatus}.`,actor_name:profile.name,actor_role:profile.role});
    return orderApi.getOrderById(id);
  },
  attachFile: async (id:string,file:any) => {
    const {data,error}=await supabase.from('orders').select('tenant_id').eq('id',id).single(); if(error||!data) throw new Error('Order tidak ditemukan.');
    const {data:{user}}=await supabase.auth.getUser(); if(!user) throw new Error('Sesi login tidak valid.');
    const {data:profile}=await supabase.from('profiles').select('name,role').eq('id',user.id).single();
    const {error:fe}=await supabase.from('order_files').insert({order_id:id,tenant_id:data.tenant_id,name:file.name,file_type:file.fileType||'application/octet-stream',category:file.category||'FILE_DESAIN',url:file.url,size:file.size||'1.0 MB',uploaded_by:profile?.name||'User'}); if(fe) throw new Error(fe.message);
    return orderApi.getOrderById(id);
  },
  deleteOrder: async (id:string) => { const {error}=await supabase.from('orders').delete().eq('id',id); if(error) throw new Error(error.message); return {message:'Order berhasil dihapus.'}; },
};

export const trackingApi = {
  getTracking: async (code:string) => {
    const {data,error}=await supabase.from('orders').select('*,tenants(*),order_timeline(*)').or(`tracking_code.eq.${code},order_number.eq.${code}`).single();
    if(error||!data) { const e:any=new Error('Nomor order atau kode tracking tidak ditemukan.'); e.code='ORDER_NOT_FOUND'; throw e; }
    const t=data.tenants; if(!t) throw new Error('Tenant tidak ditemukan.');
    if(t.plan!=='PREMIUM'||!t.tracking_enabled||t.status!=='ACTIVE'){const e:any=new Error('Bisnis percetakan ini menggunakan paket BASIC. Fitur Client Tracking dan QR Code hanya aktif untuk paket PREMIUM.'); e.code='TRACKING_DISABLED';e.plan=t.plan;e.tenantName=t.name;throw e;}
    return {orderNumber:data.order_number,trackingCode:data.tracking_code,tenantName:t.name,tenantPhone:t.phone||'',tenantAddress:t.address||'',customerName:data.customer_name,jobType:data.job_type,size:data.size,material:data.material,quantity:data.quantity,unit:data.unit,finishing:data.finishing||'',deadline:data.deadline,status:data.status as OrderStatus,needsDesign:data.needs_design,timeline:(data.order_timeline||[]).map((x:any)=>({id:x.id,status:x.status,title:x.title,note:x.note||'',actorName:x.actor_name,actorRole:x.actor_role,timestamp:x.created_at})),updatedAt:data.updated_at} as OrderTrackingInfo;
  },
};
