import { Tenant, User, Order, OrderStatus, OrderTrackingInfo, MasterStats, TenantPlan, Role } from '../types.js';

const metaEnv = (import.meta as unknown as { env?: Record<string, string> }).env || {};
const SUPABASE_URL = metaEnv.VITE_SUPABASE_URL || '';
const API_BASE = SUPABASE_URL ? `${SUPABASE_URL.replace(/\/$/, '')}/functions/v1/app-api` : '';

function getAuthHeader(): Record<string, string> {
  const token = localStorage.getItem('alurcetak_token');
  return token ? { Authorization: `Bearer ${token}` } : {};
}

export async function request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  if (!API_BASE) throw new Error('Supabase belum dikonfigurasi. Isi VITE_SUPABASE_URL dan VITE_SUPABASE_ANON_KEY.');
  const headers = { 'Content-Type': 'application/json', ...getAuthHeader(), ...(options.headers || {}) };
  const res = await fetch(`${API_BASE}${endpoint}`, { ...options, headers });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || data.message || 'Terjadi kesalahan pada server');
  return data as T;
}

export interface AITaskPrintOrder { id:string; orderNumber:string; customerName:string; jobType:string; size:string; material:string; quantity:number; unit:string; deadline:string; pic:string; status:string; statusLabel:string; nextStep:string; needsDesign:boolean; notes:string; approvalInfo?:string; }
export interface AITaskPrintResponse { answer:string; orders:AITaskPrintOrder[]; dataUpdatedAt:string; source:'supabase'|'demo'; tenantId:string; }

export const aiTaskPrintApi = {
  ask: async (payload: { question:string; filters?: { customer?:string; orderNumber?:string; pic?:string; status?:string; deadline?:'TODAY'|'TOMORROW'|'OVERDUE' } }) =>
    request<AITaskPrintResponse>('/ai/task-print', { method:'POST', body:JSON.stringify(payload) }),
};

export const authApi = {
  login: async (username:string, password:string) => request<{token:string;user:User}>('/auth/login', { method:'POST', body:JSON.stringify({username,password}) }),
  getMe: async () => request<User & {tenant?:Tenant|null}>('/auth/me'),
  getDemoUsers: async () => [] as Array<{id:string;username:string;name:string;role:Role;tenantId:string|null;tenantName:string;tenantPlan?:TenantPlan}>,
};

export const masterApi = {
  getSetupStatus: async () => request<{isConfigured:boolean;email:string;name:string;username:string}>('/master/setup-status'),
  setupPassword: async (payload:{email:string;password:string;currentPassword?:string}) => request<{success:boolean;message:string}>('/master/setup-password',{method:'POST',body:JSON.stringify(payload)}),
  getTenants: async () => request<Array<Tenant & {orderCount:number;userCount:number}>>('/master/tenants'),
  getStats: async () => request<MasterStats>('/master/stats'),
  createTenant: async (payload:any) => request<{tenant:Tenant;admin:User}>('/master/tenants',{method:'POST',body:JSON.stringify(payload)}),
  updateTenant: async (id:string,payload:any) => request<Tenant>(`/master/tenants/${id}`,{method:'PATCH',body:JSON.stringify(payload)}),
};

export const userApi = {
  getUsers: async (tenantId?:string) => request<User[]>(`/users${tenantId?`?tenantId=${encodeURIComponent(tenantId)}`:''}`),
  createUser: async (payload:any) => request<User>('/users',{method:'POST',body:JSON.stringify(payload)}),
  deleteUser: async (id:string) => request<{message:string}>(`/users/${encodeURIComponent(id)}`,{method:'DELETE'}),
};

export const orderApi = {
  getOrders: async (tenantId?:string) => request<Order[]>(`/orders${tenantId?`?tenantId=${encodeURIComponent(tenantId)}`:''}`),
  getOrderById: async (id:string) => request<Order>(`/orders/${encodeURIComponent(id)}`),
  createOrder: async (payload:any) => request<Order>('/orders',{method:'POST',body:JSON.stringify(payload)}),
  updateStatus: async (id:string,nextStatus:OrderStatus,note?:string) => request<Order>(`/orders/${encodeURIComponent(id)}/status`,{method:'PATCH',body:JSON.stringify({nextStatus,note})}),
  attachFile: async (id:string,file:any) => request<Order>(`/orders/${encodeURIComponent(id)}/files`,{method:'POST',body:JSON.stringify(file)}),
  deleteOrder: async (id:string) => request<{message:string}>(`/orders/${encodeURIComponent(id)}`,{method:'DELETE'}),
};

export const trackingApi = {
  getTracking: async (code:string) => {
    const res = await fetch(`${API_BASE}/tracking/${encodeURIComponent(code)}`);
    const data = await res.json().catch(()=>({}));
    if (!res.ok) { const err:any = new Error(data.message || 'Tracking gagal'); err.code=data.error; err.plan=data.plan; err.tenantName=data.tenantName; throw err; }
    return data as OrderTrackingInfo;
  },
};
