import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, Tenant } from '../types.js';
import { authApi } from '../services/api.js';

interface AuthContextType {
  user: (User & { tenant?: Tenant | null }) | null;
  token: string | null;
  isLoading: boolean;
  demoUsers: never[];
  login: (username:string,password:string)=>Promise<void>;
  logout: ()=>Promise<void>;
  switchUser: (userId:string)=>Promise<void>;
  refreshUser: ()=>Promise<void>;
}
const AuthContext=createContext<AuthContextType|undefined>(undefined);

export const AuthProvider:React.FC<{children:React.ReactNode}>=({children})=>{
  const [user,setUser]=useState<(User&{tenant?:Tenant|null})|null>(null);
  const [token,setToken]=useState<string|null>(()=>localStorage.getItem('alurcetak_token'));
  const [isLoading,setIsLoading]=useState(true);

  const refreshUser=async()=>{
    const saved=localStorage.getItem('alurcetak_token');
    if(!saved){setUser(null);setToken(null);setIsLoading(false);return;}
    try{ const data=await authApi.getMe(); setUser(data); setToken(saved); }
    catch{ localStorage.removeItem('alurcetak_token'); setUser(null); setToken(null); }
    finally{setIsLoading(false);}
  };

  const login=async(username:string,password:string)=>{
    const result=await authApi.login(username,password);
    localStorage.setItem('alurcetak_token',result.token);
    setToken(result.token); setUser(result.user);
  };

  const logout=async()=>{localStorage.removeItem('alurcetak_token');setToken(null);setUser(null);};
  const switchUser=async(_userId:string)=>{ throw new Error('Mode ganti role/demo telah dinonaktifkan. Silakan login dengan username dan password.'); };

  useEffect(()=>{refreshUser();},[]);
  return <AuthContext.Provider value={{user,token,isLoading,demoUsers:[],login,logout,switchUser,refreshUser}}>{children}</AuthContext.Provider>;
};
export const useAuth=()=>{const c=useContext(AuthContext);if(!c)throw new Error('useAuth must be used within AuthProvider');return c;};
