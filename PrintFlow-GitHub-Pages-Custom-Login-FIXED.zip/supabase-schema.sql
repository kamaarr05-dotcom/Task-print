-- ==============================================================================
-- ALURCETAK - MULTI-TENANT PRINTING WORKFLOW & CLIENT TRACKING SYSTEM
-- SUPABASE POSTGRESQL SCHEMA WITH ROW LEVEL SECURITY (RLS) & STORAGE POLICIES
-- ==============================================================================
-- Author: Platform Architecture
-- Note: Execute this entire script in your Supabase Project SQL Editor
-- ==============================================================================

-- 1. EXTENSIONS
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- 2. ENUM TYPES
DO $$ BEGIN
  CREATE TYPE tenant_plan_type AS ENUM ('BASIC', 'PREMIUM');
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
  CREATE TYPE tenant_status_type AS ENUM ('ACTIVE', 'SUSPENDED');
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
  CREATE TYPE user_role_type AS ENUM (
    'MASTER',
    'ADMIN',
    'DESAINER',
    'OPERATOR_CETAK',
    'FINISHING_QC'
  );
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
  CREATE TYPE order_status_type AS ENUM (
    'PESANAN_MASUK',
    'VERIFIKASI',
    'DESAIN',
    'APPROVAL',
    'PRODUKSI_CETAK',
    'FINISHING_QC',
    'SIAP_DIAMBIL_DIKIRIM',
    'SELESAI'
  );
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
  CREATE TYPE file_category_type AS ENUM (
    'BRIEF_KONSUMEN',
    'FILE_DESAIN',
    'BUKTI_APPROVAL',
    'FILE_CETAK',
    'FOTO_QC'
  );
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

-- 3. TENANTS TABLE (Multi-tenant isolation root)
CREATE TABLE IF NOT EXISTS public.tenants (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  code TEXT NOT NULL UNIQUE,
  plan tenant_plan_type NOT NULL DEFAULT 'BASIC',
  tracking_enabled BOOLEAN NOT NULL DEFAULT false,
  phone TEXT,
  address TEXT,
  status tenant_status_type NOT NULL DEFAULT 'ACTIVE',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 4. USERS / PROFILES TABLE (Linked with auth.users)
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  tenant_id UUID REFERENCES public.tenants(id) ON DELETE CASCADE,
  username TEXT NOT NULL UNIQUE,
  email TEXT NOT NULL,
  name TEXT NOT NULL,
  role user_role_type NOT NULL DEFAULT 'ADMIN',
  phone TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),

  -- Master must have NULL tenant_id; Tenant staff MUST have non-null tenant_id
  CONSTRAINT check_master_tenant_consistency CHECK (
    (role = 'MASTER' AND tenant_id IS NULL) OR
    (role != 'MASTER' AND tenant_id IS NOT NULL)
  )
);

-- Constraint: Only mdqputra@gmail.com can hold role 'MASTER'
CREATE UNIQUE INDEX IF NOT EXISTS single_master_account_idx 
ON public.profiles(role) 
WHERE role = 'MASTER';

-- 5. ORDERS TABLE (Strict multi-tenant isolation)
-- Note: NO price, payment, cashier, invoice, or financial reports per strict instruction.
CREATE TABLE IF NOT EXISTS public.orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  order_number TEXT NOT NULL,
  tracking_code TEXT NOT NULL UNIQUE,
  customer_name TEXT NOT NULL,
  customer_whatsapp TEXT NOT NULL,
  job_type TEXT NOT NULL,
  size TEXT NOT NULL,
  material TEXT NOT NULL,
  quantity INTEGER NOT NULL DEFAULT 1 CHECK (quantity > 0),
  unit TEXT NOT NULL DEFAULT 'pcs',
  finishing TEXT,
  deadline TIMESTAMPTZ NOT NULL,
  notes TEXT,
  needs_design BOOLEAN NOT NULL DEFAULT false,
  pic TEXT,
  status order_status_type NOT NULL DEFAULT 'PESANAN_MASUK',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT unique_order_number_per_tenant UNIQUE (tenant_id, order_number)
);

-- 6. ORDER FILES & QC PHOTOS TABLE
CREATE TABLE IF NOT EXISTS public.order_files (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  file_type TEXT NOT NULL,
  category file_category_type NOT NULL DEFAULT 'FILE_DESAIN',
  url TEXT NOT NULL,
  storage_path TEXT,
  size TEXT NOT NULL,
  uploaded_by TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 7. ORDER TIMELINE / PROCESS HISTORY TABLE
CREATE TABLE IF NOT EXISTS public.order_timeline (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  status order_status_type NOT NULL,
  title TEXT NOT NULL,
  note TEXT,
  actor_name TEXT NOT NULL,
  actor_role TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 8. CUSTOMERS DIRECTORY (Optional convenience directory per tenant)
CREATE TABLE IF NOT EXISTS public.customers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  phone_whatsapp TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT unique_customer_phone_per_tenant UNIQUE (tenant_id, phone_whatsapp)
);

-- ==============================================================================
-- 9. PERFORMANCE INDEXES
-- ==============================================================================
CREATE INDEX IF NOT EXISTS idx_tenants_code ON public.tenants(code);
CREATE INDEX IF NOT EXISTS idx_tenants_plan ON public.tenants(plan);
CREATE INDEX IF NOT EXISTS idx_profiles_tenant_id ON public.profiles(tenant_id);
CREATE INDEX IF NOT EXISTS idx_profiles_role ON public.profiles(role);
CREATE INDEX IF NOT EXISTS idx_orders_tenant_id ON public.orders(tenant_id);
CREATE INDEX IF NOT EXISTS idx_orders_status ON public.orders(status);
CREATE INDEX IF NOT EXISTS idx_orders_tracking_code ON public.orders(tracking_code);
CREATE INDEX IF NOT EXISTS idx_orders_order_number ON public.orders(order_number);
CREATE INDEX IF NOT EXISTS idx_order_files_order_id ON public.order_files(order_id);
CREATE INDEX IF NOT EXISTS idx_order_files_tenant_id ON public.order_files(tenant_id);
CREATE INDEX IF NOT EXISTS idx_order_timeline_order_id ON public.order_timeline(order_id);
CREATE INDEX IF NOT EXISTS idx_order_timeline_tenant_id ON public.order_timeline(tenant_id);

-- ==============================================================================
-- 10. HELPER FUNCTIONS FOR RLS & ROLE-BASED ACCESS CONTROL
-- ==============================================================================

-- Function to get current authenticated user's role from public.profiles
CREATE OR REPLACE FUNCTION public.get_auth_role()
RETURNS user_role_type
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT role FROM public.profiles WHERE id = auth.uid();
$$;

-- Function to get current authenticated user's tenant_id from public.profiles
CREATE OR REPLACE FUNCTION public.get_auth_tenant_id()
RETURNS UUID
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT tenant_id FROM public.profiles WHERE id = auth.uid();
$$;

-- Function to check if current user is Master
CREATE OR REPLACE FUNCTION public.is_master()
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = auth.uid()
    AND role = 'MASTER'
    AND email = 'mdqputra@gmail.com'
  );
$$;

-- ==============================================================================
-- 11. ROW LEVEL SECURITY (RLS) POLICIES
-- ==============================================================================

-- Enable RLS on all tables
ALTER TABLE public.tenants ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_files ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_timeline ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.customers ENABLE ROW LEVEL SECURITY;

-- ------------------------------------------------------------------------------
-- TENANTS POLICIES
-- ------------------------------------------------------------------------------
-- Master can do everything with tenants
CREATE POLICY "Master can manage all tenants"
ON public.tenants
FOR ALL
USING (public.is_master())
WITH CHECK (public.is_master());

-- Tenant users can only view their own tenant profile
CREATE POLICY "Tenant users can view their own tenant"
ON public.tenants
FOR SELECT
USING (id = public.get_auth_tenant_id());

-- Public can view tenant info strictly for tracking verification if tenant has PREMIUM
CREATE POLICY "Public can view active premium tenant for tracking"
ON public.tenants
FOR SELECT
USING (
  plan = 'PREMIUM' 
  AND tracking_enabled = true 
  AND status = 'ACTIVE'
);

-- ------------------------------------------------------------------------------
-- PROFILES POLICIES
-- ------------------------------------------------------------------------------
-- Master can manage all profiles
CREATE POLICY "Master can manage all profiles"
ON public.profiles
FOR ALL
USING (public.is_master())
WITH CHECK (public.is_master());

-- Tenant Admin can view staff within their tenant
CREATE POLICY "Tenant users can view staff in same tenant"
ON public.profiles
FOR SELECT
USING (tenant_id = public.get_auth_tenant_id());

-- Tenant Admin can insert new subordinate staff within their tenant (never Master)
CREATE POLICY "Tenant Admin can insert staff in their tenant"
ON public.profiles
FOR INSERT
WITH CHECK (
  public.get_auth_role() = 'ADMIN'
  AND tenant_id = public.get_auth_tenant_id()
  AND role != 'MASTER'
);

-- Tenant Admin can update staff in their tenant (cannot change role to Master)
CREATE POLICY "Tenant Admin can update staff in their tenant"
ON public.profiles
FOR UPDATE
USING (
  public.get_auth_role() = 'ADMIN'
  AND tenant_id = public.get_auth_tenant_id()
  AND role != 'MASTER'
)
WITH CHECK (
  public.get_auth_role() = 'ADMIN'
  AND tenant_id = public.get_auth_tenant_id()
  AND role != 'MASTER'
);

-- Users can update their own profile
CREATE POLICY "Users can update their own profile"
ON public.profiles
FOR UPDATE
USING (id = auth.uid())
WITH CHECK (id = auth.uid() AND role = public.get_auth_role());

-- ------------------------------------------------------------------------------
-- ORDERS POLICIES (Core Multi-Tenant Isolation)
-- ------------------------------------------------------------------------------
-- Master can view all orders across all tenants
CREATE POLICY "Master can view all orders"
ON public.orders
FOR SELECT
USING (public.is_master());

-- Tenant users can view orders belonging strictly to their tenant
CREATE POLICY "Tenant users can view own tenant orders"
ON public.orders
FOR SELECT
USING (tenant_id = public.get_auth_tenant_id());

-- Tenant users can insert orders for their own tenant
CREATE POLICY "Tenant users can insert own tenant orders"
ON public.orders
FOR INSERT
WITH CHECK (tenant_id = public.get_auth_tenant_id());

-- Tenant users can update orders within their tenant (status workflow, notes, PIC)
CREATE POLICY "Tenant users can update own tenant orders"
ON public.orders
FOR UPDATE
USING (tenant_id = public.get_auth_tenant_id())
WITH CHECK (tenant_id = public.get_auth_tenant_id());

-- Only Tenant Admin can delete orders in their tenant
CREATE POLICY "Tenant Admin can delete orders"
ON public.orders
FOR DELETE
USING (
  public.get_auth_role() = 'ADMIN'
  AND tenant_id = public.get_auth_tenant_id()
);

-- PUBLIC CLIENT TRACKING POLICY (PREMIUM ONLY)
-- Anonymous or unauthenticated clients can SELECT order by tracking_code
-- ONLY IF the tenant is ACTIVE and is on the PREMIUM plan with tracking enabled!
CREATE POLICY "Public tracking for premium orders"
ON public.orders
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM public.tenants t
    WHERE t.id = orders.tenant_id
    AND t.plan = 'PREMIUM'
    AND t.tracking_enabled = true
    AND t.status = 'ACTIVE'
  )
);

-- ------------------------------------------------------------------------------
-- ORDER FILES POLICIES
-- ------------------------------------------------------------------------------
CREATE POLICY "Master can view all order files"
ON public.order_files
FOR SELECT
USING (public.is_master());

CREATE POLICY "Tenant users can view own order files"
ON public.order_files
FOR SELECT
USING (tenant_id = public.get_auth_tenant_id());

CREATE POLICY "Tenant users can insert own order files"
ON public.order_files
FOR INSERT
WITH CHECK (tenant_id = public.get_auth_tenant_id());

CREATE POLICY "Tenant users can delete own order files"
ON public.order_files
FOR DELETE
USING (tenant_id = public.get_auth_tenant_id());

-- Public can view files attached to active premium tracking order
CREATE POLICY "Public can view files of premium tracking order"
ON public.order_files
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM public.orders o
    JOIN public.tenants t ON t.id = o.tenant_id
    WHERE o.id = order_files.order_id
    AND t.plan = 'PREMIUM'
    AND t.tracking_enabled = true
    AND t.status = 'ACTIVE'
  )
);

-- ------------------------------------------------------------------------------
-- ORDER TIMELINE POLICIES
-- ------------------------------------------------------------------------------
CREATE POLICY "Master can view all timeline events"
ON public.order_timeline
FOR SELECT
USING (public.is_master());

CREATE POLICY "Tenant users can view own order timeline"
ON public.order_timeline
FOR SELECT
USING (tenant_id = public.get_auth_tenant_id());

CREATE POLICY "Tenant users can insert order timeline"
ON public.order_timeline
FOR INSERT
WITH CHECK (tenant_id = public.get_auth_tenant_id());

-- Public can view timeline of active premium tracking order
CREATE POLICY "Public can view timeline of premium tracking order"
ON public.order_timeline
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM public.orders o
    JOIN public.tenants t ON t.id = o.tenant_id
    WHERE o.id = order_timeline.order_id
    AND t.plan = 'PREMIUM'
    AND t.tracking_enabled = true
    AND t.status = 'ACTIVE'
  )
);

-- ------------------------------------------------------------------------------
-- CUSTOMERS POLICIES
-- ------------------------------------------------------------------------------
CREATE POLICY "Master can view all customers"
ON public.customers
FOR SELECT
USING (public.is_master());

CREATE POLICY "Tenant users can manage own customers"
ON public.customers
FOR ALL
USING (tenant_id = public.get_auth_tenant_id())
WITH CHECK (tenant_id = public.get_auth_tenant_id());

-- ==============================================================================
-- 12. SUPABASE STORAGE BUCKET CONFIGURATION & POLICIES
-- ==============================================================================
-- Storage Bucket: orders-storage
INSERT INTO storage.buckets (id, name, public)
VALUES ('orders-storage', 'orders-storage', true)
ON CONFLICT (id) DO UPDATE SET public = true;

-- Storage RLS: Tenant isolation in storage paths: {tenant_id}/{order_id}/{filename}
CREATE POLICY "Tenant users can upload files to their tenant folder"
ON storage.objects
FOR INSERT
WITH CHECK (
  bucket_id = 'orders-storage'
  AND (
    public.is_master()
    OR (
      auth.role() = 'authenticated'
      AND (storage.foldername(name))[1] = public.get_auth_tenant_id()::text
    )
  )
);

CREATE POLICY "Tenant users can view their tenant files in storage"
ON storage.objects
FOR SELECT
USING (
  bucket_id = 'orders-storage'
  AND (
    public.is_master()
    OR (
      auth.role() = 'authenticated'
      AND (storage.foldername(name))[1] = public.get_auth_tenant_id()::text
    )
    OR true -- Public tracking allows reading uploaded images/design preview
  )
);

CREATE POLICY "Tenant users can delete files from their tenant folder"
ON storage.objects
FOR DELETE
USING (
  bucket_id = 'orders-storage'
  AND (
    public.is_master()
    OR (
      auth.role() = 'authenticated'
      AND (storage.foldername(name))[1] = public.get_auth_tenant_id()::text
    )
  )
);

-- ==============================================================================
-- 13. AUTOMATIC PROFILE CREATION TRIGGER ON SUPABASE AUTH SIGNUP / USER CREATION
-- ==============================================================================
CREATE OR REPLACE FUNCTION public.handle_new_auth_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_role user_role_type;
  v_tenant_id UUID;
  v_username TEXT;
  v_name TEXT;
  v_phone TEXT;
BEGIN
  -- CHECK FOR THE SINGLE MASTER ACCOUNT (mdqputra@gmail.com)
  IF lower(NEW.email) = 'mdqputra@gmail.com' THEN
    v_role := 'MASTER';
    v_tenant_id := NULL;
    v_username := 'mdqputra';
    v_name := COALESCE(NEW.raw_user_meta_data->>'name', 'Master Platform Owner');
  ELSE
    -- Tenant user profile parsing
    v_role := COALESCE((NEW.raw_user_meta_data->>'role')::user_role_type, 'ADMIN'::user_role_type);
    -- Enforce rule: No other email can ever have role 'MASTER'
    IF v_role = 'MASTER' THEN
      RAISE EXCEPTION 'Role MASTER hanya diizinkan untuk email mdqputra@gmail.com';
    END IF;

    IF (NEW.raw_user_meta_data->>'tenant_id') IS NOT NULL THEN
      v_tenant_id := (NEW.raw_user_meta_data->>'tenant_id')::UUID;
    ELSE
      v_tenant_id := NULL;
    END IF;

    v_username := COALESCE(NEW.raw_user_meta_data->>'username', split_part(NEW.email, '@', 1));
    v_name := COALESCE(NEW.raw_user_meta_data->>'name', v_username);
  END IF;

  v_phone := NEW.raw_user_meta_data->>'phone';

  INSERT INTO public.profiles (
    id,
    tenant_id,
    username,
    email,
    name,
    role,
    phone,
    created_at,
    updated_at
  ) VALUES (
    NEW.id,
    v_tenant_id,
    v_username,
    NEW.email,
    v_name,
    v_role,
    v_phone,
    now(),
    now()
  )
  ON CONFLICT (id) DO UPDATE SET
    email = EXCLUDED.email,
    name = EXCLUDED.name,
    phone = EXCLUDED.phone,
    updated_at = now();

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_auth_user();

-- ==============================================================================
-- 14. REALTIME REPLICATION ENABLEMENT
-- ==============================================================================
-- Add tables to realtime publication for live order updates across staff
DO $$ BEGIN
  ALTER PUBLICATION supabase_realtime ADD TABLE public.orders;
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
  ALTER PUBLICATION supabase_realtime ADD TABLE public.order_timeline;
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
  ALTER PUBLICATION supabase_realtime ADD TABLE public.order_files;
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

-- ==============================================================================
-- 15. SEED INITIAL TENANTS
-- ==============================================================================
-- Tenant 1: Cahaya Print Digital (PREMIUM - Client Tracking ON)
INSERT INTO public.tenants (id, name, code, plan, tracking_enabled, phone, address, status)
VALUES (
  '11111111-1111-1111-1111-111111111111',
  'Cahaya Print Digital',
  'CPD',
  'PREMIUM',
  true,
  '081234567890',
  'Jl. Surya Kencana No. 45, Jakarta Selatan',
  'ACTIVE'
) ON CONFLICT (code) DO NOTHING;

-- Tenant 2: Prima Offset & Sablon (BASIC - Client Tracking OFF)
INSERT INTO public.tenants (id, name, code, plan, tracking_enabled, phone, address, status)
VALUES (
  '22222222-2222-2222-2222-222222222222',
  'Prima Offset & Sablon',
  'POS',
  'BASIC',
  false,
  '089876543210',
  'Jl. Merdeka Barat No. 12, Bandung',
  'ACTIVE'
) ON CONFLICT (code) DO NOTHING;

-- Seed Sample Orders for Cahaya Print Digital (PREMIUM)
INSERT INTO public.orders (
  id,
  tenant_id,
  order_number,
  tracking_code,
  customer_name,
  customer_whatsapp,
  job_type,
  size,
  material,
  quantity,
  unit,
  finishing,
  deadline,
  notes,
  needs_design,
  pic,
  status
) VALUES (
  '33333333-3333-3333-3333-333333333331',
  '11111111-1111-1111-1111-111111111111',
  'CPD-202609-001',
  'trk-cpd-001-abc88',
  'PT Nusantara Sentosa (Ibu Maya)',
  '6281311223344',
  'Brosur Promosi Triwulan',
  'A4 Lipat 3 (21 x 29.7 cm)',
  'Art Paper 150 gr',
  2000,
  'lembar',
  'Laminasi Doff 2 Sisi + Lipat Rel 3',
  now() + interval '2 days',
  'Warna corporate harus presisi CMYK #003366, packaging rapi per 100 lembar',
  true,
  'Dian Permata (Desainer)',
  'APPROVAL'
) ON CONFLICT (tracking_code) DO NOTHING;

INSERT INTO public.orders (
  id,
  tenant_id,
  order_number,
  tracking_code,
  customer_name,
  customer_whatsapp,
  job_type,
  size,
  material,
  quantity,
  unit,
  finishing,
  deadline,
  notes,
  needs_design,
  pic,
  status
) VALUES (
  '33333333-3333-3333-3333-333333333332',
  '11111111-1111-1111-1111-111111111111',
  'CPD-202609-002',
  'trk-cpd-002-xyz99',
  'Kopi Kenangan Senja (Bpk Kevin)',
  '6281299887766',
  'Stiker Cup & Label Botol',
  '5 x 5 cm Bulat',
  'Stiker Vinyl Transparan Waterproof',
  5000,
  'pcs',
  'Kiss Cut Die Cut Lembaran A3+',
  now() + interval '1 day',
  'File siap cetak dari konsumen, tanpa desain baru.',
  false,
  'Hendra Gunawan (Operator Cetak)',
  'PRODUKSI_CETAK'
) ON CONFLICT (tracking_code) DO NOTHING;

-- ==============================================================================
-- 18. REPAIR EXISTING SUPABASE AUTH USERS
-- ==============================================================================
-- If an Auth user was created before the trigger existed, ensure its public profile
-- exists as well. This is safe to run repeatedly.
INSERT INTO public.profiles (id, tenant_id, username, email, name, role, phone, created_at, updated_at)
SELECT
  u.id,
  NULL,
  'mdqputra',
  u.email,
  COALESCE(u.raw_user_meta_data->>'name', 'Master Platform Owner'),
  'MASTER'::user_role_type,
  u.raw_user_meta_data->>'phone',
  COALESCE(u.created_at, now()),
  now()
FROM auth.users u
WHERE lower(u.email) = 'mdqputra@gmail.com'
ON CONFLICT (id) DO UPDATE SET
  username = 'mdqputra',
  email = EXCLUDED.email,
  name = EXCLUDED.name,
  role = 'MASTER'::user_role_type,
  tenant_id = NULL,
  phone = EXCLUDED.phone,
  updated_at = now();

-- ==============================================================================
-- 20. PRINTFLOW CUSTOM APP LOGIN (NO SUPABASE AUTH REQUIRED IN THE WEB APP)
-- ------------------------------------------------------------------------------
-- GitHub Pages cannot run server.ts. The web app therefore uses a small Supabase
-- Edge Function as the application backend. Users log in with PrintFlow
-- username/password; Supabase Auth is not used by the browser.
-- ==============================================================================

ALTER TABLE public.profiles DROP CONSTRAINT IF EXISTS profiles_id_fkey;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS password_hash TEXT;

CREATE TABLE IF NOT EXISTS public.app_sessions (
  token_hash TEXT PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  expires_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_app_sessions_user_id ON public.app_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_app_sessions_expires_at ON public.app_sessions(expires_at);

ALTER TABLE public.app_sessions ENABLE ROW LEVEL SECURITY;

-- Seed the original PrintFlow application roles. These are application accounts,
-- not Supabase Auth accounts. Initial tenant passwords are 123456; change them
-- from the application's user management before production use.
INSERT INTO public.profiles (id, tenant_id, username, email, name, role, phone, password_hash)
VALUES
('c0000000-0000-4000-8000-000000000001',NULL,'mdqputra','mdqputra@gmail.com','Master Platform Owner','MASTER','08111000222',NULL),
('a0000000-0000-4000-8000-000000000001','11111111-1111-1111-1111-111111111111','admin_cahaya','admin_cahaya@taskprint.local','Budi Santoso (Admin CPD)','ADMIN','081234567891','sha256$seed$b4a4cd64c980c666105099ef0c9538b888849b71475a9eee8b82fe5eff6d8597'),
('a0000000-0000-4000-8000-000000000002','11111111-1111-1111-1111-111111111111','desain_cahaya','desain_cahaya@taskprint.local','Dian Permata (Desainer CPD)','DESAINER','081234567892','sha256$seed$b4a4cd64c980c666105099ef0c9538b888849b71475a9eee8b82fe5eff6d8597'),
('a0000000-0000-4000-8000-000000000003','11111111-1111-1111-1111-111111111111','cetak_cahaya','cetak_cahaya@taskprint.local','Hendra Gunawan (Operator Cetak)','OPERATOR_CETAK','081234567893','sha256$seed$b4a4cd64c980c666105099ef0c9538b888849b71475a9eee8b82fe5eff6d8597'),
('a0000000-0000-4000-8000-000000000004','11111111-1111-1111-1111-111111111111','qc_cahaya','qc_cahaya@taskprint.local','Siti Rahma (Finishing QC)','FINISHING_QC','081234567894','sha256$seed$b4a4cd64c980c666105099ef0c9538b888849b71475a9eee8b82fe5eff6d8597'),
('b0000000-0000-4000-8000-000000000001','22222222-2222-2222-2222-222222222222','admin_prima','admin_prima@taskprint.local','Andi Pratama (Admin POS)','ADMIN','089876543211','sha256$seed$b4a4cd64c980c666105099ef0c9538b888849b71475a9eee8b82fe5eff6d8597'),
('b0000000-0000-4000-8000-000000000002','22222222-2222-2222-2222-222222222222','desain_prima','desain_prima@taskprint.local','Rina Lestari (Desainer POS)','DESAINER','089876543212','sha256$seed$b4a4cd64c980c666105099ef0c9538b888849b71475a9eee8b82fe5eff6d8597'),
('b0000000-0000-4000-8000-000000000003','22222222-2222-2222-2222-222222222222','cetak_prima','cetak_prima@taskprint.local','Fajar Nugraha (Operator Cetak)','OPERATOR_CETAK','089876543213','sha256$seed$b4a4cd64c980c666105099ef0c9538b888849b71475a9eee8b82fe5eff6d8597'),
('b0000000-0000-4000-8000-000000000004','22222222-2222-2222-2222-222222222222','qc_prima','qc_prima@taskprint.local','Dewi Anggraini (Finishing QC)','FINISHING_QC','089876543214','sha256$seed$b4a4cd64c980c666105099ef0c9538b888849b71475a9eee8b82fe5eff6d8597')
ON CONFLICT (username) DO UPDATE SET
  tenant_id=EXCLUDED.tenant_id,
  email=EXCLUDED.email,
  name=EXCLUDED.name,
  role=EXCLUDED.role,
  phone=EXCLUDED.phone,
  password_hash=COALESCE(public.profiles.password_hash,EXCLUDED.password_hash),
  updated_at=now();
