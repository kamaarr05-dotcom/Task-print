# PrintFlow — GitHub Pages + Supabase

Arsitektur deployment:
- Frontend: Vite/React di GitHub Pages.
- Database: Supabase PostgreSQL.
- Login: login aplikasi PrintFlow (username/password + role), **bukan Supabase Auth di browser**.
- Backend aplikasi: Supabase Edge Function `app-api`.
- Storage: Supabase Storage melalui signed upload URL.
- Tracking publik: endpoint `app-api/tracking/...`.
- GitHub Actions hanya membangun dan deploy frontend. **Tidak membutuhkan SUPABASE_ACCESS_TOKEN atau SUPABASE_PROJECT_REF.**

## GitHub Actions secrets
Buat hanya:
- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_ANON_KEY`

`VITE_SUPABASE_PUBLISHABLE_KEY` tetap didukung oleh kode untuk kompatibilitas, tetapi workflow menggunakan nama `VITE_SUPABASE_ANON_KEY` seperti konfigurasi lama.

## Supabase setup
1. Jalankan `supabase-schema.sql` di SQL Editor.
2. Deploy function `supabase/functions/app-api/index.ts` sebagai Edge Function bernama `app-api` dan nonaktifkan JWT verification untuk function tersebut (`verify_jwt = false`).
3. Jika AI Task Print dipakai, buat secret Edge Function `GEMINI_API_KEY` di Supabase.
4. Login aplikasi menggunakan username/password PrintFlow. Tidak perlu membuat akun pengguna di Supabase Auth.
