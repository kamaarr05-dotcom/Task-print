# PrintFlow

PrintFlow adalah aplikasi manajemen alur kerja percetakan multi-tenant.

## Deployment
- Frontend: GitHub Pages
- Data: Supabase PostgreSQL
- Login: username/password aplikasi PrintFlow dengan role MASTER/ADMIN/DESAINER/OPERATOR_CETAK/FINISHING_QC
- Backend: Supabase Edge Function `app-api`
- Storage: Supabase Storage

GitHub Actions hanya membutuhkan:
- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_ANON_KEY`

Tidak ada `SUPABASE_ACCESS_TOKEN` di workflow frontend.
