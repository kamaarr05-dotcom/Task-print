import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, Tenant, Role, TenantPlan } from '../types.js';
import { authApi } from '../services/api.js';
import { supabase } from '../services/supabase.js';

interface DemoUserItem {
  id: string;
  username: string;
  name: string;
  role: Role;
  tenantId: string | null;
  tenantName: string;
  tenantPlan?: TenantPlan;
}

interface AuthContextType {
  user: (User & { tenant?: Tenant | null }) | null;
  token: string | null;
  isLoading: boolean;
  demoUsers: DemoUserItem[];
  login: (username: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  refreshUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<(User & { tenant?: Tenant | null }) | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [demoUsers, setDemoUsers] = useState<DemoUserItem[]>([]);

  const loadProfile = async () => {
    try {
      const current = await authApi.getMe();
      setUser(current);
      const { data: sessionData } = await supabase.auth.getSession();
      setToken(sessionData.session?.access_token || null);
      return current;
    } catch {
      setUser(null);
      setToken(null);
      return null;
    }
  };

  const refreshUser = async () => {
    setIsLoading(true);
    try { await loadProfile(); } finally { setIsLoading(false); }
  };

  useEffect(() => {
    let mounted = true;
    authApi.getDemoUsers().then(list => { if (mounted) setDemoUsers(list.filter(u => u.role !== 'MASTER')); }).catch(() => {});
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      if (!mounted) return;
      setToken(session?.access_token || null);
      if (!session) setUser(null);
      else setTimeout(() => { if (mounted) loadProfile(); }, 0);
    });
    refreshUser();
    return () => { mounted = false; listener.subscription.unsubscribe(); };
  }, []);

  const login = async (username: string, password: string) => {
    if (!username.trim()) throw new Error('Username/email wajib diisi.');
    if (!password) throw new Error('Password wajib diisi.');
    setIsLoading(true);
    try {
      const session = await authApi.login(username.trim(), password);
      const { error } = await supabase.auth.setSession({ access_token: session.access_token, refresh_token: session.refresh_token });
      if (error) throw new Error(`Supabase Auth gagal: ${error.message}`);
      await loadProfile();
    } finally { setIsLoading(false); }
  };

  const logout = async () => {
    await supabase.auth.signOut();
    setUser(null); setToken(null);
  };

  return (
    <AuthContext.Provider value={{ user, token, isLoading, demoUsers, login, logout, refreshUser }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
};
