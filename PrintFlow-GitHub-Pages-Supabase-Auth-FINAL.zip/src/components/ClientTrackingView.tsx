import React, { useState, useEffect } from 'react';
import QRCode from 'qrcode';
import { OrderTrackingInfo, OrderStatus } from '../types.js';
import { trackingApi } from '../services/api.js';
import { STATUS_CONFIG, formatDate, formatWhatsappUrl, getTrackingUrl } from '../utils/helpers.js';
import { WorkflowProgressBar } from './WorkflowProgressBar.js';
import { TaskPrintLogo } from './TaskPrintLogo.js';
import {
  Search,
  Printer,
  QrCode,
  Lock,
  Building2,
  Calendar,
  Layers,
  Clock,
  CheckCircle2,
  MessageCircle,
  AlertCircle,
  ArrowLeft,
  Share2,
} from 'lucide-react';

interface ClientTrackingViewProps {
  initialCode?: string;
  onBackToApp?: () => void;
}

export const ClientTrackingView: React.FC<ClientTrackingViewProps> = ({
  initialCode = '',
  onBackToApp,
}) => {
  const [searchCode, setSearchCode] = useState(initialCode);
  const [trackingData, setTrackingData] = useState<OrderTrackingInfo | null>(null);
  const [errorInfo, setErrorInfo] = useState<{
    code?: string;
    message: string;
    tenantName?: string;
  } | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [qrUrl, setQrUrl] = useState('');

  const fetchTracking = async (code: string) => {
    if (!code.trim()) return;
    setIsLoading(true);
    setErrorInfo(null);
    setTrackingData(null);

    try {
      const data = await trackingApi.getTracking(code.trim());
      setTrackingData(data);

      // Generate current tracking link QR code
      const currentUrl = getTrackingUrl(data.trackingCode);
      const qr = await QRCode.toDataURL(currentUrl, {
        width: 180,
        margin: 2,
        color: { dark: '#0f172a', light: '#ffffff' },
      });
      setQrUrl(qr);
    } catch (err: any) {
      setErrorInfo({
        code: err.code || 'ERROR',
        message: err.message || 'Gagal memuat status pesanan.',
        tenantName: err.tenantName,
      });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (initialCode) {
      setSearchCode(initialCode);
      fetchTracking(initialCode);
    }
  }, [initialCode]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchTracking(searchCode);
  };

  // Masking customer name for public view (e.g. "PT Nusantara Sentosa" -> "PT Nusantara...")
  const maskCustomerName = (name: string) => {
    if (name.length <= 4) return name;
    return name.slice(0, 4) + '***';
  };

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col justify-between">
      {/* Top Bar */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 py-3.5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <TaskPrintLogo size={36} />
            <div>
              <span className="font-black text-sm text-[#1E3A5F] tracking-tight block leading-none">
                TASK<span className="text-[#00A896]">PRINT</span>
              </span>
              <span className="text-[10px] text-slate-500 font-medium">
                Client Tracking System
              </span>
            </div>
          </div>

          {onBackToApp && (
            <button
              onClick={onBackToApp}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-slate-700 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer border border-slate-200"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              Kembali ke Dashboard Staff
            </button>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-3xl w-full mx-auto px-4 py-8 flex-1">
        {/* Search Input Box */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm mb-6">
          <h1 className="text-base sm:text-lg font-bold text-slate-900 mb-1">
            Pantau Progres Pesanan Cetak Anda
          </h1>
          <p className="text-xs text-slate-500 mb-4">
            Masukkan Nomor Order (contoh: <code className="bg-slate-100 px-1 py-0.5 rounded text-indigo-700 font-mono">CPD-202609-001</code>) atau scan QR Code yang diberikan oleh percetakan.
          </p>

          <form onSubmit={handleSearchSubmit} className="flex gap-2">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                required
                placeholder="Contoh: CPD-202609-001 atau kode tracking..."
                value={searchCode}
                onChange={e => setSearchCode(e.target.value)}
                className="w-full pl-9 pr-3 py-2 text-xs sm:text-sm border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono"
              />
            </div>
            <button
              type="submit"
              disabled={isLoading}
              className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs sm:text-sm rounded-xl shadow-xs transition-colors shrink-0 cursor-pointer"
            >
              {isLoading ? 'Mencari...' : 'Lacak Sekarang'}
            </button>
          </form>

          {/* Preset quick test badges */}
          <div className="mt-3 flex flex-wrap items-center gap-1.5 text-[11px] text-slate-500">
            <span>Uji Cepat:</span>
            <button
              type="button"
              onClick={() => {
                setSearchCode('CPD-202609-001');
                fetchTracking('CPD-202609-001');
              }}
              className="px-2 py-0.5 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded hover:bg-emerald-100 font-mono"
            >
              CPD-202609-001 (Premium • Tracking ON)
            </button>
            <button
              type="button"
              onClick={() => {
                setSearchCode('POS-202609-001');
                fetchTracking('POS-202609-001');
              }}
              className="px-2 py-0.5 bg-amber-50 text-amber-800 border border-amber-200 rounded hover:bg-amber-100 font-mono"
            >
              POS-202609-001 (Basic • Tracking OFF)
            </button>
          </div>
        </div>

        {/* CASE 1: TRACKING DISABLED FOR BASIC PLAN */}
        {errorInfo && errorInfo.code === 'TRACKING_DISABLED' && (
          <div className="bg-white border-2 border-amber-300 rounded-2xl p-6 shadow-sm space-y-4">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-full bg-amber-100 text-amber-700 flex items-center justify-center shrink-0">
                <Lock className="w-5 h-5" />
              </div>
              <div className="space-y-1">
                <span className="px-2 py-0.5 text-[10px] font-bold bg-amber-100 text-amber-800 rounded-md">
                  PAKET BASIC • Rp150.000
                </span>
                <h2 className="text-base font-bold text-slate-900">
                  Fitur Client Tracking Tidak Aktif
                </h2>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Percetakan <strong>{errorInfo.tenantName || 'ini'}</strong> terdaftar pada paket <strong>BASIC (Rp150.000)</strong>.
                  Fitur pelacakan mandiri oleh konsumen via QR Code & tautan publik dinonaktifkan pada paket ini.
                </p>
              </div>
            </div>

            <div className="p-4 bg-amber-50/70 border border-amber-200 rounded-xl text-xs text-amber-900 space-y-1">
              <p className="font-semibold">Informasi untuk Konsumen:</p>
              <p className="text-[11px] text-slate-600">
                Silakan hubungi pihak percetakan secara langsung melalui kontak telepon atau WhatsApp yang tertera pada nota fisik pesanan Anda untuk menanyakan progres pekerjaan.
              </p>
            </div>
          </div>
        )}

        {/* CASE 2: GENERAL ERROR */}
        {errorInfo && errorInfo.code !== 'TRACKING_DISABLED' && (
          <div className="bg-rose-50 border border-rose-200 rounded-2xl p-6 text-center space-y-2">
            <AlertCircle className="w-8 h-8 text-rose-600 mx-auto" />
            <h3 className="font-bold text-rose-900 text-sm">Pesanan Tidak Ditemukan</h3>
            <p className="text-xs text-rose-700 max-w-sm mx-auto">{errorInfo.message}</p>
          </div>
        )}

        {/* CASE 3: SUCCESSFUL TRACKING RESULT (PREMIUM) */}
        {trackingData && (
          <div className="space-y-6">
            {/* Header Card: Tenant & Order Highlight */}
            <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
                <div>
                  <div className="flex items-center gap-1.5 text-xs text-slate-500 font-medium">
                    <Building2 className="w-3.5 h-3.5 text-indigo-600" />
                    <span>Percetakan:</span>
                    <strong className="text-slate-800">{trackingData.tenantName}</strong>
                  </div>
                  <h2 className="text-xl font-black font-mono text-slate-900 mt-1">
                    #{trackingData.orderNumber}
                  </h2>
                  <p className="text-xs text-slate-400 font-medium">
                    Tenggat Selesai: {formatDate(trackingData.deadline)}
                  </p>
                </div>

                <div className="flex flex-col sm:items-end gap-1">
                  <span
                    className={`px-3 py-1 text-xs rounded-full font-bold border self-start sm:self-auto ${
                      STATUS_CONFIG[trackingData.status]?.bg
                    } ${STATUS_CONFIG[trackingData.status]?.color} ${
                      STATUS_CONFIG[trackingData.status]?.border
                    }`}
                  >
                    {STATUS_CONFIG[trackingData.status]?.label}
                  </span>
                  <span className="text-[11px] text-slate-400">
                    Update Terakhir: {formatDate(trackingData.updatedAt)}
                  </span>
                </div>
              </div>

              {/* Stepper Progress */}
              <div className="mt-4">
                <WorkflowProgressBar
                  currentStatus={trackingData.status}
                  needsDesign={trackingData.needsDesign}
                />
              </div>
            </div>

            {/* Job Summary & QR Code */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {/* Specs */}
              <div className="sm:col-span-2 bg-white rounded-2xl border border-slate-200 p-5 shadow-sm space-y-3">
                <h3 className="font-bold text-xs uppercase tracking-wider text-slate-800">
                  Ringkasan Pekerjaan
                </h3>

                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                    <span className="text-[10px] text-slate-400 block">Jenis Cetakan</span>
                    <span className="font-bold text-slate-900">{trackingData.jobType}</span>
                  </div>

                  <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                    <span className="text-[10px] text-slate-400 block">Jumlah</span>
                    <span className="font-bold text-slate-900">
                      {trackingData.quantity} {trackingData.unit}
                    </span>
                  </div>

                  <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                    <span className="text-[10px] text-slate-400 block">Ukuran</span>
                    <span className="font-semibold text-slate-800">{trackingData.size}</span>
                  </div>

                  <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                    <span className="text-[10px] text-slate-400 block">Bahan</span>
                    <span className="font-semibold text-slate-800">{trackingData.material}</span>
                  </div>

                  <div className="col-span-2 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                    <span className="text-[10px] text-slate-400 block">Finishing</span>
                    <span className="font-semibold text-slate-800">{trackingData.finishing}</span>
                  </div>
                </div>

                {trackingData.tenantPhone && (
                  <div className="pt-2">
                    <a
                      href={formatWhatsappUrl(
                        trackingData.tenantPhone,
                        `Halo ${trackingData.tenantName}, saya ingin menanyakan pesanan #${trackingData.orderNumber}.`
                      )}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center justify-center gap-1.5 w-full py-2 px-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-colors shadow-2xs"
                    >
                      <MessageCircle className="w-4 h-4" />
                      Hubungi Percetakan via WhatsApp
                    </a>
                  </div>
                )}
              </div>

              {/* QR Code */}
              <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm flex flex-col items-center justify-center text-center">
                <span className="text-xs font-bold text-slate-800 mb-2">QR Code Pelacakan</span>
                {qrUrl ? (
                  <img src={qrUrl} alt="QR Code Tracking" className="w-28 h-28 rounded-lg" />
                ) : (
                  <QrCode className="w-28 h-28 text-slate-300" />
                )}
                <span className="text-[10px] text-slate-400 mt-2 font-mono">
                  {trackingData.trackingCode}
                </span>
              </div>
            </div>

            {/* Timeline Log */}
            <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm space-y-3">
              <h3 className="font-bold text-xs uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-slate-500" />
                Riwayat Perjalanan Pesanan
              </h3>

              <div className="space-y-3 relative before:absolute before:left-3 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-200">
                {trackingData.timeline.map((item, idx) => (
                  <div key={item.id || idx} className="flex items-start gap-3 relative z-10">
                    <div className="w-6 h-6 rounded-full bg-white border-2 border-indigo-600 flex items-center justify-center shrink-0">
                      <div className="w-2 h-2 rounded-full bg-indigo-600" />
                    </div>
                    <div className="flex-1 bg-slate-50 p-3 rounded-xl border border-slate-100">
                      <div className="flex justify-between items-center text-xs">
                        <span className="font-bold text-slate-900">{item.title}</span>
                        <span className="text-[10px] text-slate-400 font-mono">
                          {formatDate(item.timestamp)}
                        </span>
                      </div>
                      {item.note && (
                        <p className="text-xs text-slate-600 mt-1">{item.note}</p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 py-4 text-center text-xs text-slate-400">
        Platform Manajemen Alur Kerja Percetakan Multi-Tenant • Sistem Terisolasi & Terintegrasi
      </footer>
    </div>
  );
};
