import React, { useState } from 'react';
import { orderApi } from '../services/api.js';
import { uploadOrderFileToSupabase } from '../services/supabase.js';
import { useAuth } from '../context/AuthContext.js';
import {
  X,
  Plus,
  Calendar,
  Layers,
  FileText,
  User,
  Phone,
  CheckCircle2,
  Sparkles,
  Upload,
} from 'lucide-react';

interface OrderCreateModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOrderCreated: () => void;
}

const JOB_TYPE_PRESETS = [
  'Brosur & Flier',
  'Banner & Spanduk Outdoor',
  'Roll Up Banner Indoor',
  'Stiker Label Kemasan (Vinyl)',
  'Kartu Nama Eksekutif',
  'Buku Nota / Faktur NCR',
  'Kotak Kemasan / Box Packaging',
  'Sablon & Merchandise',
  'Kalender Dinding / Meja',
];

const MATERIAL_PRESETS = [
  'Art Paper 150 gr',
  'Art Carton 260 gr',
  'Flexi Frontlite 280 gr',
  'Flexi Korea 440 gr',
  'Albatros / Luster Matte',
  'Stiker Vinyl Transparan Waterproof',
  'Stiker Cromo Glossy',
  'Kertas NCR 3 Rangkap',
  'HVS 80 gr',
];

export const OrderCreateModal: React.FC<OrderCreateModalProps> = ({
  isOpen,
  onClose,
  onOrderCreated,
}) => {
  const { user } = useAuth();

  const [customerName, setCustomerName] = useState('');
  const [customerWhatsapp, setCustomerWhatsapp] = useState('');
  const [jobType, setJobType] = useState(JOB_TYPE_PRESETS[0]);
  const [customJobType, setCustomJobType] = useState('');
  const [size, setSize] = useState('A4 (21 x 29.7 cm)');
  const [material, setMaterial] = useState(MATERIAL_PRESETS[0]);
  const [quantity, setQuantity] = useState<number>(500);
  const [unit, setUnit] = useState('lembar');
  const [finishing, setFinishing] = useState('Laminasi Doff 2 Sisi');
  const [deadline, setDeadline] = useState(
    () => new Date(Date.now() + 86400000 * 2).toISOString().slice(0, 16)
  );
  const [needsDesign, setNeedsDesign] = useState(true);
  const [pic, setPic] = useState(user?.name || '');
  const [notes, setNotes] = useState('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [fileAttachment, setFileAttachment] = useState<{
    name: string;
    url: string;
    fileType: string;
    category: string;
    size: string;
  } | null>(null);

  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setSelectedFile(file);
    const reader = new FileReader();
    reader.onload = () => {
      setFileAttachment({
        name: file.name,
        url: reader.result as string,
        fileType: file.type || 'application/octet-stream',
        category: needsDesign ? 'BRIEF_KONSUMEN' : 'FILE_CETAK',
        size: `${(file.size / (1024 * 1024)).toFixed(2)} MB`,
      });
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const finalJobType = customJobType.trim() ? customJobType.trim() : jobType;

    if (!customerName || !finalJobType || !quantity) {
      alert('Nama konsumen, jenis pekerjaan, dan jumlah wajib diisi.');
      return;
    }

    setIsSubmitting(true);
    try {
      const created = await orderApi.createOrder({
        customerName,
        customerWhatsapp,
        jobType: finalJobType,
        size,
        material,
        quantity: Number(quantity),
        unit,
        finishing,
        deadline: new Date(deadline).toISOString(),
        needsDesign,
        pic: pic || user?.name || 'Staff',
        notes,
      });

      if (selectedFile) {
        await uploadOrderFileToSupabase({
          file: selectedFile,
          fileName: selectedFile.name,
          tenantId: created.tenantId,
          orderId: created.id,
          category: needsDesign ? 'BRIEF_KONSUMEN' : 'FILE_CETAK',
          uploadedByName: user?.name || 'Staff',
        });
      }

      onOrderCreated();
      onClose();
    } catch (err: any) {
      alert(err.message || 'Gagal membuat pesanan baru');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div
      id="order-create-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto"
    >
      <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full my-6 border border-slate-200 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-200 bg-slate-50/70 flex items-center justify-between gap-3 shrink-0">
          <div>
            <div className="flex items-center gap-2">
              <Plus className="w-5 h-5 text-indigo-600" />
              <h2 className="text-lg font-bold text-slate-900">Buat Pesanan Baru</h2>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Nomor order dan kode tracking unik akan dibuat otomatis secara terisolasi untuk{' '}
              <strong className="text-slate-800">{user?.tenantName}</strong>.
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-200 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-4 sm:p-6 overflow-y-auto space-y-4 text-xs">
          {/* Section: Konsumen */}
          <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-3">
            <h3 className="font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5 text-[11px]">
              <User className="w-3.5 h-3.5 text-indigo-600" />
              Data Konsumen
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Nama Konsumen / Instansi *
                </label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: PT Sumber Rejeki (Ibu Linda)"
                  value={customerName}
                  onChange={e => setCustomerName(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Nomor WhatsApp Konsumen
                </label>
                <input
                  type="text"
                  placeholder="081234567xxx (untuk kirim update/link)"
                  value={customerWhatsapp}
                  onChange={e => setCustomerWhatsapp(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500 font-mono"
                />
              </div>
            </div>
          </div>

          {/* Section: Desain Workflow Choice */}
          <div className="bg-indigo-50/40 p-3.5 rounded-xl border border-indigo-200 space-y-2">
            <label className="block font-bold text-slate-900 text-xs">
              Alur Desain Pekerjaan Ini:
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div
                onClick={() => setNeedsDesign(true)}
                className={`p-3 rounded-xl border-2 cursor-pointer transition-all ${
                  needsDesign
                    ? 'border-indigo-600 bg-white shadow-xs'
                    : 'border-slate-200 bg-slate-50/50 hover:border-slate-300'
                }`}
              >
                <div className="flex items-center gap-2">
                  <div
                    className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                      needsDesign ? 'border-indigo-600' : 'border-slate-400'
                    }`}
                  >
                    {needsDesign && <div className="w-2 h-2 rounded-full bg-indigo-600" />}
                  </div>
                  <span className="font-bold text-slate-900 text-xs">Memerlukan Jasa Desain</span>
                </div>
                <p className="text-[10px] text-slate-500 mt-1 pl-6">
                  Alur: Masuk &rarr; Verifikasi &rarr; <strong>Desain</strong> &rarr; <strong>Approval</strong> &rarr; Produksi &rarr; QC &rarr; Selesai.
                </p>
              </div>

              <div
                onClick={() => setNeedsDesign(false)}
                className={`p-3 rounded-xl border-2 cursor-pointer transition-all ${
                  !needsDesign
                    ? 'border-emerald-600 bg-white shadow-xs'
                    : 'border-slate-200 bg-slate-50/50 hover:border-slate-300'
                }`}
              >
                <div className="flex items-center gap-2">
                  <div
                    className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                      !needsDesign ? 'border-emerald-600' : 'border-slate-400'
                    }`}
                  >
                    {!needsDesign && <div className="w-2 h-2 rounded-full bg-emerald-600" />}
                  </div>
                  <span className="font-bold text-slate-900 text-xs">⚡ File Siap Cetak (Tanpa Desain)</span>
                </div>
                <p className="text-[10px] text-emerald-700 mt-1 pl-6 font-medium">
                  Alur langsung: Verifikasi &rarr; <strong>Langsung ke Produksi/Cetak</strong> (melewati Desain & Approval).
                </p>
              </div>
            </div>
          </div>

          {/* Section: Spesifikasi Teknis */}
          <div className="space-y-3">
            <h3 className="font-bold text-slate-800 uppercase tracking-wider text-[11px]">
              Spesifikasi Produk Cetak
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Jenis Pekerjaan *
                </label>
                <select
                  value={jobType}
                  onChange={e => setJobType(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500"
                >
                  {JOB_TYPE_PRESETS.map(j => (
                    <option key={j} value={j}>
                      {j}
                    </option>
                  ))}
                  <option value="CUSTOM">Lainnya / Kustom...</option>
                </select>
                {jobType === 'CUSTOM' && (
                  <input
                    type="text"
                    placeholder="Tuliskan jenis pekerjaan kustom..."
                    value={customJobType}
                    onChange={e => setCustomJobType(e.target.value)}
                    className="w-full mt-1.5 px-3 py-1.5 text-xs border border-indigo-300 rounded-lg focus:outline-none"
                  />
                )}
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Ukuran</label>
                <input
                  type="text"
                  placeholder="Contoh: A4, 2x1 meter, 9x5.5 cm"
                  value={size}
                  onChange={e => setSize(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="sm:col-span-1">
                <label className="block font-semibold text-slate-700 mb-1">Bahan / Kertas</label>
                <input
                  type="text"
                  list="material-presets"
                  placeholder="Pilih atau ketik bahan..."
                  value={material}
                  onChange={e => setMaterial(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />
                <datalist id="material-presets">
                  {MATERIAL_PRESETS.map(m => (
                    <option key={m} value={m} />
                  ))}
                </datalist>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Jumlah (Qty) *</label>
                <input
                  type="number"
                  min={1}
                  required
                  value={quantity}
                  onChange={e => setQuantity(Math.max(1, Number(e.target.value)))}
                  className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500 font-bold"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Satuan</label>
                <select
                  value={unit}
                  onChange={e => setUnit(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500"
                >
                  <option value="lembar">lembar</option>
                  <option value="pcs">pcs</option>
                  <option value="rim">rim</option>
                  <option value="buku">buku</option>
                  <option value="set">set</option>
                  <option value="meter">meter</option>
                  <option value="m²">m²</option>
                  <option value="box">box</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Finishing</label>
                <input
                  type="text"
                  placeholder="Laminasi Doff, Mata Ayam 4 Sudut, Pond Lipat..."
                  value={finishing}
                  onChange={e => setFinishing(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Tenggat Waktu (Deadline) *
                </label>
                <input
                  type="datetime-local"
                  required
                  value={deadline}
                  onChange={e => setDeadline(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500 font-mono"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  PIC / Penanggung Jawab
                </label>
                <input
                  type="text"
                  placeholder="Nama staf PIC..."
                  value={pic}
                  onChange={e => setPic(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Lampiran Berkas Awal (Opsional)
                </label>
                <label className="flex items-center gap-2 px-3 py-2 bg-slate-50 hover:bg-slate-100 border border-slate-300 border-dashed rounded-lg cursor-pointer transition-colors text-slate-600">
                  <Upload className="w-3.5 h-3.5 text-slate-400" />
                  <span className="truncate">
                    {fileAttachment ? fileAttachment.name : 'Pilih file (PDF, AI, CDR, JPG, PNG)'}
                  </span>
                  <input type="file" onChange={handleFileChange} className="hidden" />
                </label>
              </div>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Catatan Tambahan</label>
              <textarea
                rows={2}
                placeholder="Catatan khusus pengerjaan, instruksi packaging, warna acuan CMYK..."
                value={notes}
                onChange={e => setNotes(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100 flex justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
            >
              Batal
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-5 py-2 text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl shadow-xs transition-colors cursor-pointer"
            >
              {isSubmitting ? 'Menyimpan...' : 'Simpan & Daftarkan Order'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
