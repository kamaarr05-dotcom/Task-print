import { OrderStatus, Role } from '../types.js';

export const STATUS_CONFIG: Record<
  OrderStatus,
  { label: string; color: string; bg: string; border: string; step: number; description: string }
> = {
  PESANAN_MASUK: {
    label: 'Pesanan Masuk',
    color: 'text-slate-700',
    bg: 'bg-slate-100',
    border: 'border-slate-300',
    step: 1,
    description: 'Pesanan telah diterima dan tercatat dalam sistem.',
  },
  VERIFIKASI: {
    label: 'Verifikasi',
    color: 'text-blue-700',
    bg: 'bg-blue-50',
    border: 'border-blue-200',
    step: 2,
    description: 'Pemeriksaan spesifikasi, ukuran, bahan, dan kelayakan file cetak.',
  },
  DESAIN: {
    label: 'Desain',
    color: 'text-purple-700',
    bg: 'bg-purple-50',
    border: 'border-purple-200',
    step: 3,
    description: 'Proses perancangan visual, layout, dan penataan oleh Desainer.',
  },
  APPROVAL: {
    label: 'Approval Desain',
    color: 'text-amber-700',
    bg: 'bg-amber-50',
    border: 'border-amber-200',
    step: 4,
    description: 'Menunggu persetujuan (acc proof) dari pihak konsumen sebelum dicetak.',
  },
  PRODUKSI_CETAK: {
    label: 'Produksi / Cetak',
    color: 'text-indigo-700',
    bg: 'bg-indigo-50',
    border: 'border-indigo-200',
    step: 5,
    description: 'Proses cetak pada mesin percetakan (Digital / Offset / Sablon).',
  },
  FINISHING_QC: {
    label: 'Finishing + QC',
    color: 'text-cyan-700',
    bg: 'bg-cyan-50',
    border: 'border-cyan-200',
    step: 6,
    description: 'Tahap potong, laminasi, jilid, lipat, serta pengecekan mutu (QC).',
  },
  SIAP_DIAMBIL_DIKIRIM: {
    label: 'Siap Diambil / Dikirim',
    color: 'text-teal-700',
    bg: 'bg-teal-50',
    border: 'border-teal-200',
    step: 7,
    description: 'Pesanan telah selesai dipacking dan siap diambil atau dikirim.',
  },
  SELESAI: {
    label: 'Selesai',
    color: 'text-emerald-700',
    bg: 'bg-emerald-50',
    border: 'border-emerald-200',
    step: 8,
    description: 'Pesanan telah diterima oleh konsumen dengan baik.',
  },
};

export const ROLE_LABELS: Record<Role, { title: string; badge: string; iconBg: string }> = {
  MASTER: {
    title: 'Platform Master Owner',
    badge: 'bg-purple-900 text-purple-100 border-purple-700',
    iconBg: 'bg-purple-100 text-purple-800',
  },
  ADMIN: {
    title: 'Admin Percetakan',
    badge: 'bg-blue-100 text-blue-800 border-blue-200',
    iconBg: 'bg-blue-100 text-blue-700',
  },
  DESAINER: {
    title: 'Desainer Grafis',
    badge: 'bg-fuchsia-100 text-fuchsia-800 border-fuchsia-200',
    iconBg: 'bg-fuchsia-100 text-fuchsia-700',
  },
  OPERATOR_CETAK: {
    title: 'Operator Cetak',
    badge: 'bg-indigo-100 text-indigo-800 border-indigo-200',
    iconBg: 'bg-indigo-100 text-indigo-700',
  },
  FINISHING_QC: {
    title: 'Finishing & QC',
    badge: 'bg-emerald-100 text-emerald-800 border-emerald-200',
    iconBg: 'bg-emerald-100 text-emerald-700',
  },
};

export function formatDate(dateString?: string): string {
  if (!dateString) return '-';
  try {
    const d = new Date(dateString);
    return new Intl.DateTimeFormat('id-ID', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    }).format(d);
  } catch {
    return dateString;
  }
}

export function formatDeadline(deadlineString?: string): {
  text: string;
  isUrgent: boolean;
  isOverdue: boolean;
} {
  if (!deadlineString) return { text: '-', isUrgent: false, isOverdue: false };
  try {
    const now = new Date().getTime();
    const target = new Date(deadlineString).getTime();
    const diffHours = Math.round((target - now) / (1000 * 60 * 60));

    if (diffHours < 0) {
      return {
        text: `Terlambat ${Math.abs(diffHours)} jam`,
        isUrgent: true,
        isOverdue: true,
      };
    }
    if (diffHours <= 24) {
      return {
        text: `${diffHours} jam lagi`,
        isUrgent: true,
        isOverdue: false,
      };
    }
    const days = Math.round(diffHours / 24);
    return {
      text: `${days} hari lagi`,
      isUrgent: false,
      isOverdue: false,
    };
  } catch {
    return { text: deadlineString, isUrgent: false, isOverdue: false };
  }
}

export function formatWhatsappUrl(phone: string, text?: string): string {
  let cleaned = phone.replace(/[^0-9]/g, '');
  if (cleaned.startsWith('0')) {
    cleaned = '62' + cleaned.slice(1);
  } else if (!cleaned.startsWith('62')) {
    cleaned = '62' + cleaned;
  }
  const query = text ? `?text=${encodeURIComponent(text)}` : '';
  return `https://wa.me/${cleaned}${query}`;
}

export function getTrackingUrl(trackingCode: string): string {
  const base = (import.meta as any).env?.BASE_URL || '/';
  return new URL(`${base}?track=${encodeURIComponent(trackingCode)}`, window.location.origin).toString();
}
