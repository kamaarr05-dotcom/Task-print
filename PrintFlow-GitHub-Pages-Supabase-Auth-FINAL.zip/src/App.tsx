import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext.js';
import { Navbar } from './components/Navbar.js';
import { MasterDashboard } from './components/MasterDashboard.js';
import { OrdersBoard } from './components/OrdersBoard.js';
import { TeamManagement } from './components/TeamManagement.js';
import { OrderDetailModal } from './components/OrderDetailModal.js';
import { OrderCreateModal } from './components/OrderCreateModal.js';
import { ClientTrackingView } from './components/ClientTrackingView.js';
import { AIAssistantTaskPrint } from './components/AIAssistantTaskPrint.js';
import { TaskPrintLogo } from './components/TaskPrintLogo.js';
import { isSupabaseConfigured } from './services/supabase.js';
import {
  Printer,
  QrCode,
  Lock,
  Sparkles,
  LogIn,
  Database,
} from 'lucide-react';

const MainApp: React.FC = () => {
  const { user, login, isLoading } = useAuth();

  const [currentTab, setCurrentTab] = useState<string>('orders');
  const [selectedOrderId, setSelectedOrderId] = useState<string | null>(null);
  const [isCreateOrderOpen, setIsCreateOrderOpen] = useState(false);
  const [refreshTrigger, setRefreshTrigger] = useState(0);

  // Public Tracking View Mode (supports ?track= query parameter)
  const [isTrackingMode, setIsTrackingMode] = useState(false);
  const [trackingCodeParam, setTrackingCodeParam] = useState('');

  // Login form state
  const [loginUsername, setLoginUsername] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  // Check URL query parameters for direct tracking link
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const trackParam = params.get('track');
    if (trackParam) {
      setTrackingCodeParam(trackParam);
      setIsTrackingMode(true);
    }
  }, []);

  // Update default tab when role changes
  useEffect(() => {
    if (user?.role === 'MASTER') {
      setCurrentTab('master');
    } else {
      setCurrentTab('orders');
    }
  }, [user?.role]);

  const handleOpenPublicTracking = (code?: string) => {
    setTrackingCodeParam(code || '');
    setIsTrackingMode(true);
  };

  const handleBackFromTracking = () => {
    setIsTrackingMode(false);
    if (window.history.pushState) {
      window.history.pushState({}, document.title, window.location.pathname);
    }
  };

  const handleManualLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    setIsLoggingIn(true);
    try {
      await login(loginUsername, loginPassword);
    } catch (err: any) {
      setLoginError(err.message || 'Login gagal. Periksa username/email dan password.');
    } finally {
      setIsLoggingIn(false);
    }
  };

  // If tracking mode is activated (either via URL or by clicking 'Lacak Pesanan')
  if (isTrackingMode) {
    return (
      <ClientTrackingView
        initialCode={trackingCodeParam}
        onBackToApp={handleBackFromTracking}
      />
    );
  }

  // Loading spinner during initial auth check
  if (isLoading && !user) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="text-center space-y-3">
          <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-sm font-semibold text-slate-600">Menyiapkan Ruang Kerja AlurCetak...</p>
        </div>
      </div>
    );
  }

  // Fallback Login Page if user explicitly logs out
  // NOTE: Master account information is strictly HIDDEN from the public UI per specifications
  if (!user) {
    const supabaseActive = isSupabaseConfigured();

    return (
      <div className="min-h-screen bg-slate-100 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
        <div className="sm:mx-auto sm:w-full sm:max-w-md text-center">
          <div className="flex justify-center mb-3">
            <TaskPrintLogo size={68} />
          </div>
          <h1 className="text-2xl font-black text-[#1E3A5F] tracking-tight">
            TASK<span className="text-[#00A896]">PRINT</span>
          </h1>
          <p className="mt-1 text-xs text-slate-500">
            Sistem Manajemen Alur Kerja Percetakan Multi-Tenant
          </p>
          <div className="mt-2 inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-medium border bg-white text-slate-600 border-slate-200">
            <Database className="w-3 h-3 text-[#00A896]" />
            <span>Database: {supabaseActive ? 'Supabase PostgreSQL (Aktif)' : 'Multi-Tenant Connected'}</span>
          </div>
        </div>

        <div className="mt-6 sm:mx-auto sm:w-full sm:max-w-md px-4">
          <div className="bg-white py-6 px-5 sm:px-8 shadow-xl rounded-2xl border border-slate-200">
            {loginError && (
              <div className="mb-4 p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-xl">
                <p>{loginError}</p>
              </div>
            )}

            <form onSubmit={handleManualLogin} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Email / Username
                </label>
                <input
                  type="text"
                  required
                  placeholder="admin_cahaya / email Anda"
                  value={loginUsername}
                  onChange={e => setLoginUsername(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 font-sans"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Password</label>
                <input
                  type="password"
                  required
                  placeholder="Masukkan password Anda"
                  value={loginPassword}
                  onChange={e => setLoginPassword(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 font-sans"
                />
              </div>

              <button
                type="submit"
                disabled={isLoggingIn}
                className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl shadow-xs transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                <LogIn className="w-4 h-4" />
                {isLoggingIn ? 'Memproses...' : 'Masuk ke Sistem'}
              </button>
            </form>

            <div className="mt-6 pt-5 border-t border-slate-100 text-center text-[11px] text-slate-500">
              Semua akun staf sekarang wajib memiliki akun <strong>Supabase Auth</strong>. Gunakan username atau email yang diberikan Admin.
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-100 text-slate-900 flex flex-col">
      {/* Navigation Header */}
      <Navbar
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        onOpenTrackingSearch={() => handleOpenPublicTracking()}
      />

      {/* Dynamic Views */}
      <main className="flex-1">
        {user.role === 'MASTER' ? (
          <MasterDashboard />
        ) : (
          <>
            {currentTab === 'orders' && (
              <OrdersBoard
                onSelectOrder={id => setSelectedOrderId(id)}
                onOpenCreateOrder={() => setIsCreateOrderOpen(true)}
                refreshTrigger={refreshTrigger}
              />
            )}
            {currentTab === 'team' && user.role === 'ADMIN' && (
              <TeamManagement />
            )}
            {currentTab === 'ai-assistant' && (
              <AIAssistantTaskPrint onBack={() => setCurrentTab('orders')} />
            )}
          </>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 py-4 px-6 text-center text-xs text-slate-500">
        <p>
          AlurCetak • Multi-Tenant Printing Workflow Management • Platform 2026
        </p>
      </footer>

      {/* Global Modals */}

      <OrderDetailModal
        orderId={selectedOrderId}
        onClose={() => setSelectedOrderId(null)}
        onOrderUpdated={() => setRefreshTrigger(prev => prev + 1)}
        onOpenPublicTracking={code => handleOpenPublicTracking(code)}
      />

      <OrderCreateModal
        isOpen={isCreateOrderOpen}
        onClose={() => setIsCreateOrderOpen(false)}
        onOrderCreated={() => setRefreshTrigger(prev => prev + 1)}
      />
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <MainApp />
    </AuthProvider>
  );
}
