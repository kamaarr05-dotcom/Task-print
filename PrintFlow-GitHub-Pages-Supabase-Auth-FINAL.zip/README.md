# TASKPRINT

Sistem manajemen alur kerja percetakan multi-tenant.

## Arsitektur

- **Frontend:** React + Vite → GitHub Pages
- **Auth:** Supabase Auth
- **Database:** Supabase PostgreSQL + RLS
- **Storage:** Supabase Storage
- **Realtime:** Supabase Realtime
- **Backend aman:** Supabase Edge Functions
- **AI:** Gemini melalui Edge Function; API key tidak pernah dikirim ke browser

## Login

Semua akun wajib memiliki akun **Supabase Auth**. Form login menerima email atau username.

- Master: `mdqputra@gmail.com`
- Staff yang dibuat Admin/Master memakai username dan memiliki email internal `username@taskprint.local`.
- Password disimpan dan diverifikasi oleh Supabase Auth, bukan di source code atau `localStorage`.

## Supabase

1. Jalankan `supabase-schema.sql` sekali di SQL Editor.
2. Buat akun Master `mdqputra@gmail.com` di Authentication → Users jika belum ada.
3. Pastikan trigger profile pada schema sudah berhasil dibuat.
4. Deploy Edge Functions melalui GitHub Actions dengan secrets yang dijelaskan di `GITHUB_BUILD.md`.

## GitHub Pages

Repository: `kamaar05-dotcom/Task-print`

URL: `https://kamaar05-dotcom.github.io/Task-print/`

GitHub Settings → Pages → Source → **GitHub Actions**.

## Local development

```bash
npm install
npm run dev
```

Buat `.env.local`:

```env
VITE_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=YOUR_SUPABASE_PUBLISHABLE_KEY
```

Jangan masukkan `sb_secret...`, `service_role`, atau `GEMINI_API_KEY` ke `VITE_*`.
