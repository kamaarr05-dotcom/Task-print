import { corsHeaders, json } from '../_shared/cors.ts';
import { caller } from '../_shared/auth.ts';
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  try {
    const { profile, admin } = await caller(req);
    if (profile.role !== 'MASTER') return json({error:'FORBIDDEN',message:'Hanya Master yang dapat membuat tenant.'},403);
    const b=await req.json();
    if(!b.name||!b.plan||!b.adminUsername||!b.adminPassword) return json({error:'VALIDATION',message:'Nama tenant, paket, username admin, dan password wajib diisi.'},400);
    const code=(b.code||String(b.name).substring(0,3)).toUpperCase().replace(/[^A-Z0-9]/g,'')||'PRT';
    const username=String(b.adminUsername).trim().toLowerCase();
    const email=`${username}@taskprint.local`;
    const {data:existing}=await admin.from('profiles').select('id').or(`username.ilike.${username},email.ilike.${email}`).maybeSingle();
    if(existing) return json({error:'ADMIN_EXISTS',message:'Username/email admin sudah digunakan.'},400);
    const {data:tenant,error:te}=await admin.from('tenants').insert({name:String(b.name).trim(),code,plan:b.plan,tracking_enabled:b.plan==='PREMIUM',phone:b.phone||'',address:b.address||'',status:'ACTIVE'}).select().single();
    if(te||!tenant) return json({error:'TENANT_CREATE_FAILED',message:te?.message||'Gagal membuat tenant.'},400);
    const {data:authData,error:ae}=await admin.auth.admin.createUser({email,password:String(b.adminPassword),email_confirm:true,user_metadata:{username,name:b.adminName||`Admin ${b.name}`,role:'ADMIN',tenant_id:tenant.id,phone:b.adminPhone||b.phone||''}});
    if(ae||!authData.user){await admin.from('tenants').delete().eq('id',tenant.id);return json({error:'ADMIN_CREATE_FAILED',message:ae?.message||'Gagal membuat akun admin.'},400);}
    const {data:p}=await admin.from('profiles').select('*,tenants(*)').eq('id',authData.user.id).single();
    return json({tenant:{id:tenant.id,name:tenant.name,code:tenant.code,plan:tenant.plan,trackingEnabled:tenant.tracking_enabled,phone:tenant.phone||'',address:tenant.address||'',status:tenant.status,createdAt:tenant.created_at},admin:{id:p?.id||authData.user.id,tenantId:tenant.id,username:username,email,name:p?.name||b.adminName||`Admin ${b.name}`,role:'ADMIN',phone:p?.phone||'',createdAt:p?.created_at||new Date().toISOString()}} ,201);
  } catch(e:any){
    if(e?.message==='UNAUTHORIZED') return json({error:'UNAUTHORIZED',message:'Sesi login tidak valid.'},401);
    return json({error:'MASTER_TENANT_FAILED',message:'Gagal membuat tenant.'},500);
  }
});
