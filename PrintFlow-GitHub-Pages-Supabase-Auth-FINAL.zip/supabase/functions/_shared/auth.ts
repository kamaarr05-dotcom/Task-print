import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

export async function caller(req: Request) {
  const auth = req.headers.get('Authorization') || '';
  if (!auth.startsWith('Bearer ')) throw new Error('UNAUTHORIZED');
  const token = auth.slice(7);
  const url = Deno.env.get('SUPABASE_URL')!;
  const anon = Deno.env.get('SUPABASE_ANON_KEY')!;
  const adminKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
  const client = createClient(url, anon, { auth: { persistSession: false } });
  const { data, error } = await client.auth.getUser(token);
  if (error || !data.user) throw new Error('UNAUTHORIZED');
  const admin = createClient(url, adminKey, { auth: { persistSession: false } });
  const { data: profile, error: pe } = await admin.from('profiles').select('*').eq('id', data.user.id).single();
  if (pe || !profile) throw new Error('PROFILE_NOT_FOUND');
  return { authUser: data.user, profile, admin };
}
