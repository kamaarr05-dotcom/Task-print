import { corsHeaders, json } from '../_shared/cors.ts';
import { caller } from '../_shared/auth.ts';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  try {
    const { profile, admin } = await caller(req);
    if (profile.role !== 'ADMIN' && profile.role !== 'MASTER') return json({ error:'FORBIDDEN', message:'Hanya Admin atau Master yang dapat membuat user.' },403);
    const body = await req.json();
    const { username, password, name, role, phone, tenantId } = body;
    if (!username || !password || !name || !role) return json({ error:'VALIDATION', message:'Username, password, nama lengkap, dan role wajib diisi.' },400);
    const allowed = ['ADMIN','DESAINER','OPERATOR_CETAK','FINISHING_QC'];
    if (!allowed.includes(role)) return json({ error:'ROLE_INVALID', message:'Role tidak valid.' },400);
    const normalized = String(username).trim().toLowerCase();
    if (normalized === 'master' || normalized === 'mdqputra') return json({ error:'RESERVED', message:'Username tersebut dicadangkan untuk Master.' },400);
    const targetTenantId = profile.role === 'MASTER' ? tenantId : profile.tenant_id;
    if (!targetTenantId) return json({ error:'TENANT_REQUIRED', message:'Tenant ID wajib ditentukan.' },400);
    if (profile.role === 'ADMIN' && tenantId && tenantId !== profile.tenant_id) return json({ error:'FORBIDDEN', message:'Admin tidak dapat membuat user di tenant lain.' },403);
    const { data: existing } = await admin.from('profiles').select('id').ilike('username', normalized).maybeSingle();
    if (existing) return json({ error:'USERNAME_EXISTS', message:`Username '${normalized}' sudah digunakan.` },400);
    const email = `${normalized}@taskprint.local`;
    const { data: authData, error: authError } = await admin.auth.admin.createUser({ email, password:String(password), email_confirm:true, user_metadata:{ username:normalized, name:String(name).trim(), role, tenant_id:targetTenantId, phone:phone||'' } });
    if (authError || !authData.user) return json({ error:'AUTH_CREATE_FAILED', message:authError?.message || 'Gagal membuat akun Auth.' },400);
    const { data: created, error: pe } = await admin.from('profiles').select('*,tenants(*)').eq('id',authData.user.id).single();
    if (pe || !created) { await admin.auth.admin.deleteUser(authData.user.id); return json({ error:'PROFILE_CREATE_FAILED', message:'Profil user gagal dibuat.' },500); }
    return json({ id:created.id, tenantId:created.tenant_id, username:created.username, email:created.email, name:created.name, role:created.role, phone:created.phone||'', tenantName:created.tenants?.name, tenantPlan:created.tenants?.plan, createdAt:created.created_at });
  } catch (e:any) {
    const msg=e?.message || '';
    if (msg==='UNAUTHORIZED') return json({error:'UNAUTHORIZED',message:'Sesi login tidak valid.'},401);
    if (msg==='PROFILE_NOT_FOUND') return json({error:'PROFILE_NOT_FOUND',message:'Profil akun tidak ditemukan.'},403);
    console.error(e); return json({error:'CREATE_USER_FAILED',message:'Gagal membuat user.'},500);
  }
});
