import { corsHeaders, json } from '../_shared/cors.ts';
import { caller } from '../_shared/auth.ts';
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  try {
    const { profile, admin } = await caller(req);
    if (profile.role !== 'ADMIN' && profile.role !== 'MASTER') return json({error:'FORBIDDEN',message:'Akses ditolak.'},403);
    const { userId } = await req.json();
    const { data: target } = await admin.from('profiles').select('id,tenant_id,role').eq('id',userId).single();
    if (!target) return json({error:'NOT_FOUND',message:'Pengguna tidak ditemukan.'},404);
    if (target.role === 'MASTER') return json({error:'FORBIDDEN',message:'Akun Master tidak dapat dihapus.'},403);
    if (target.id === profile.id) return json({error:'SELF_DELETE',message:'Anda tidak dapat menghapus akun sendiri.'},400);
    if (profile.role === 'ADMIN' && target.tenant_id !== profile.tenant_id) return json({error:'FORBIDDEN',message:'Anda tidak dapat mengelola user tenant lain.'},403);
    const { error } = await admin.auth.admin.deleteUser(target.id);
    if (error) return json({error:'AUTH_DELETE_FAILED',message:error.message},400);
    return json({message:'Pengguna berhasil dihapus.'});
  } catch(e:any) {
    if(e?.message==='UNAUTHORIZED') return json({error:'UNAUTHORIZED',message:'Sesi login tidak valid.'},401);
    return json({error:'DELETE_USER_FAILED',message:'Gagal menghapus pengguna.'},500);
  }
});
