import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { corsHeaders, json } from '../_shared/cors.ts';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  try {
    const { username, password } = await req.json();
    if (!username || !password) return json({ error: 'LOGIN_REQUIRED', message: 'Username/email dan password wajib diisi.' }, 400);
    const url = Deno.env.get('SUPABASE_URL')!;
    const anonKey = Deno.env.get('SUPABASE_ANON_KEY')!;
    const adminKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const admin = createClient(url, adminKey, { auth: { persistSession: false } });
    const value = String(username).trim().toLowerCase();
    let email = value;
    if (!value.includes('@')) {
      const { data: profile, error } = await admin.from('profiles').select('email').ilike('username', value).maybeSingle();
      if (error || !profile?.email) return json({ error: 'INVALID_LOGIN', message: 'Username atau password salah.' }, 401);
      email = profile.email;
    }
    const { data: profile } = await admin.from('profiles').select('id,tenant_id,role').eq('email', email).maybeSingle();
    if (profile?.tenant_id) {
      const { data: tenant } = await admin.from('tenants').select('status').eq('id', profile.tenant_id).single();
      if (tenant?.status === 'SUSPENDED') return json({ error: 'TENANT_SUSPENDED', message: 'Tenant sedang dinonaktifkan oleh Master.' }, 403);
    }
    const authClient = createClient(url, anonKey, { auth: { persistSession: false, autoRefreshToken: false } });
    const { data, error } = await authClient.auth.signInWithPassword({ email, password: String(password) });
    if (error || !data.session || !data.user) return json({ error: 'INVALID_LOGIN', message: 'Username atau password salah.' }, 401);
    return json({ ...data.session, user: data.user });
  } catch (e) {
    console.error(e);
    return json({ error: 'LOGIN_FAILED', message: 'Login gagal. Periksa akun dan password.' }, 500);
  }
});
