import { corsHeaders, json } from '../_shared/cors.ts';
import { caller } from '../_shared/auth.ts';

const LABEL:any={PESANAN_MASUK:'Pesanan Masuk',VERIFIKASI:'Verifikasi',DESAIN:'Pengerjaan Desain',APPROVAL:'Menunggu Approval',PRODUKSI_CETAK:'Produksi / Cetak',FINISHING_QC:'Finishing & QC',SIAP_DIAMBIL_DIKIRIM:'Siap Diambil / Dikirim',SELESAI:'Selesai'};
const NEXT:any={PESANAN_MASUK:'Verifikasi',VERIFIKASI:'Desain atau Produksi',DESAIN:'Approval',APPROVAL:'Produksi / Cetak',PRODUKSI_CETAK:'Finishing & QC',FINISHING_QC:'Siap Diambil / Dikirim',SIAP_DIAMBIL_DIKIRIM:'Selesai',SELESAI:'-'};
const human=(v:string)=>{try{return new Intl.DateTimeFormat('id-ID',{dateStyle:'long',timeZone:'Asia/Jakarta'}).format(new Date(v));}catch{return v}};
function overdue(o:any){return new Date(o.deadline).getTime()<Date.now()&&o.status!=='SELESAI'}
function dateKey(v:string){return new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Jakarta',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date(v));}
function filterOrders(orders:any[],q:string,f:any){
  const today=dateKey(new Date().toISOString()); const tomorrow=dateKey(new Date(Date.now()+86400000).toISOString());
  return orders.filter(o=>{
    if(f.customer&&!o.customer_name.toLowerCase().includes(f.customer.toLowerCase()))return false;
    if(f.orderNumber&&!o.order_number.toLowerCase().includes(f.orderNumber.toLowerCase()))return false;
    if(f.pic&&!String(o.pic||'').toLowerCase().includes(f.pic.toLowerCase()))return false;
    if(f.status&&o.status!==f.status)return false;
    if(f.deadline==='TODAY'&&dateKey(o.deadline)!==today)return false;
    if(f.deadline==='TOMORROW'&&dateKey(o.deadline)!==tomorrow)return false;
    if(f.deadline==='OVERDUE'&&!overdue(o))return false;
    const text=[o.order_number,o.customer_name,o.job_type,o.material,o.pic,o.status].join(' ').toLowerCase();
    if(q.includes('terlambat')||q.includes('telat')||q.includes('overdue'))return overdue(o);
    if(q.includes('besok'))return dateKey(o.deadline)===tomorrow;
    if(q.includes('hari ini'))return dateKey(o.deadline)===today;
    if(q.includes('produksi'))return o.status==='PRODUKSI_CETAK';
    if(q.includes('approval'))return o.status==='APPROVAL';
    if(q.includes('belum selesai'))return o.status!=='SELESAI';
    return text.includes(q) || !q || /ringkasan|pesanan|status|cek/.test(q);
  });
}
function fallback(question:string,orders:any[]){
  if(!orders.length)return 'Tidak ada pesanan yang cocok dengan pertanyaan atau filter Anda pada tenant ini.';
  const q=question.toLowerCase();
  if(/siapa\s+pic|pic/.test(q))return orders.map(o=>`${o.customer_name} (${o.order_number}) → PIC: ${o.pic||'-'}; status: ${LABEL[o.status]||o.status}.`).join('\n');
  if(/terlambat|telat|overdue/.test(q))return `Ada ${orders.length} pesanan yang terlambat:\n`+orders.slice(0,25).map(o=>`• ${o.order_number} — ${o.customer_name} — deadline ${human(o.deadline)} — ${LABEL[o.status]||o.status}`).join('\n');
  return `Saya menemukan ${orders.length} pesanan yang relevan:\n`+orders.slice(0,25).map(o=>`• ${o.order_number} — ${o.customer_name} — ${LABEL[o.status]||o.status} — deadline ${human(o.deadline)} — PIC ${o.pic||'-'}`).join('\n');
}
async function gemini(question:string,orders:any[],fallbackText:string){
  const key=Deno.env.get('GEMINI_API_KEY'); if(!key)return fallbackText;
  const safe=orders.slice(0,30).map(o=>({nomor_pesanan:o.order_number,customer:o.customer_name,pekerjaan:o.job_type,ukuran:o.size,material:o.material,jumlah:o.quantity,unit:o.unit,deadline:human(o.deadline),pic:o.pic,status:LABEL[o.status]||o.status,tahap_berikutnya:NEXT[o.status]||'-',butuh_desain:o.needs_design,catatan:String(o.notes||'').slice(0,260)}));
  const prompt=`Anda adalah AI Assistant Task Print. Jawab Bahasa Indonesia, ringkas, jelas, tanpa membuat data baru. Pertanyaan: ${question}\nDATA TENANT SAJA:\n${JSON.stringify(safe)}\nMaksimal 8 baris utama. Jika tidak ada data, katakan tidak ditemukan.`;
  try{const r=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${encodeURIComponent(key)}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({contents:[{parts:[{text:prompt}]}]})});const j=await r.json();return j?.candidates?.[0]?.content?.parts?.[0]?.text?.trim()||fallbackText;}catch{return fallbackText;}
}
Deno.serve(async(req)=>{
  if(req.method==='OPTIONS')return new Response('ok',{headers:corsHeaders});
  try{
    const {profile,admin}=await caller(req); if(profile.role==='MASTER')return json({error:'AI_TENANT_REQUIRED',message:'AI Assistant digunakan dari ruang tenant Premium.'},403);
    if(!profile.tenant_id)return json({error:'AI_TENANT_REQUIRED',message:'Tenant tidak ditemukan.'},403);
    const {data:tenant}=await admin.from('tenants').select('id,name,plan,status').eq('id',profile.tenant_id).single();
    if(!tenant||tenant.status!=='ACTIVE'||tenant.plan!=='PREMIUM')return json({error:'AI_PREMIUM_REQUIRED',message:'AI Assistant hanya tersedia untuk Paket Premium Rp300.000.'},403);
    const b=await req.json(); const question=String(b.question||'').trim(); const f=b.filters||{}; if(!question&&!Object.values(f).some(Boolean))return json({error:'QUESTION_REQUIRED',message:'Pertanyaan AI wajib diisi.'},400);
    const {data:orders,error}=await admin.from('orders').select('*,order_timeline(*),order_files(*)').eq('tenant_id',profile.tenant_id).order('updated_at',{ascending:false}); if(error)return json({error:'AI_DATA_READ_FAILED',message:error.message},500);
    let matches=filterOrders(orders||[],question.toLowerCase(),f); if(!/semua\s+(pesanan|order)|riwayat|selesai/.test(question.toLowerCase())&&matches.length>0&&/ringkasan|pesanan/.test(question.toLowerCase())&&!f.status&&!f.deadline){const active=matches.filter(o=>o.status!=='SELESAI');if(active.length)matches=active;}
    const answer=await gemini(question||'Tampilkan data sesuai filter.',matches,fallback(question,matches));
    const responseOrders=matches.slice(0,30).map(o=>({id:o.id,orderNumber:o.order_number,customerName:o.customer_name,jobType:o.job_type,size:o.size,material:o.material,quantity:o.quantity,unit:o.unit,deadline:o.deadline,pic:o.pic||'',status:o.status,statusLabel:LABEL[o.status]||o.status,nextStep:NEXT[o.status]||'-',needsDesign:Boolean(o.needs_design),notes:String(o.notes||'')}));
    return json({answer,orders:responseOrders,dataUpdatedAt:new Date().toISOString(),source:'supabase',tenantId:profile.tenant_id});
  }catch(e:any){if(e?.message==='UNAUTHORIZED')return json({error:'UNAUTHORIZED',message:'Sesi login tidak valid.'},401);console.error(e);return json({error:'AI_ASSISTANT_FAILED',message:'AI Assistant gagal memproses permintaan.'},500)}
});
