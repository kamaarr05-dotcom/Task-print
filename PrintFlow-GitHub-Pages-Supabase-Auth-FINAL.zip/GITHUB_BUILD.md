# PrintFlow — GitHub Pages + Supabase

Arsitektur final:
- Frontend React/Vite: GitHub Pages
- Auth + Database + Storage + Realtime: Supabase
- Privileged user creation/deletion + tenant creation: Supabase Edge Functions
- Gemini AI: Supabase Edge Function (API key server-side)
- Tidak ada Express `/api` yang dibutuhkan browser.

## GitHub Secrets
Wajib:
- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_PUBLISHABLE_KEY`

Untuk deploy Edge Functions otomatis:
- `SUPABASE_ACCESS_TOKEN`
- `SUPABASE_PROJECT_REF`
- `GEMINI_API_KEY`

Jangan pernah memakai `sb_secret...` / `service_role` sebagai VITE secret.

## Supabase SQL
Jalankan `supabase-schema.sql` sekali di Supabase SQL Editor.

## Login
Semua login sekarang melewati Supabase Auth. Field login menerima email atau username.
Untuk username staf yang dibuat oleh Admin, aplikasi akan menyelesaikan username menjadi email internal `@taskprint.local`, lalu Supabase Auth melakukan `signInWithPassword`.

Akun Master tunggal: `mdqputra@gmail.com`.

## GitHub Pages
Repository `kamaar05-dotcom/Task-print` akan menggunakan:
`https://kamaar05-dotcom.github.io/Task-print/`

Di GitHub: Settings → Pages → Source → GitHub Actions.
