# GitHub Build

Workflow: `.github/workflows/build-webapp.yml`

The workflow uses:
- Eclipse Temurin Java JDK 21
- Node.js 20
- `npm install --no-audit --no-fund`
- `npm run lint`
- `npm run build`
- Uploads `dist/` as the `printflow-webapp-dist` GitHub Actions artifact.

It supports both repository layouts:
1. Source files already extracted at repository root (`package.json` at root).
2. Source stored as a ZIP file in the repository; the workflow extracts the first ZIP it finds and builds the directory containing `package.json`.

Runtime secrets such as Supabase/Gemini keys should be configured separately and must not be committed to the repository.
