import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext.js';
import { ROLE_LABELS } from '../utils/helpers.js';
import { TaskPrintLogo } from './TaskPrintLogo.js';
import { AppIconPreviewModal } from './AppIconPreviewModal.js';
import {
  Smartphone,
  ShieldCheck,
  Building2,
  QrCode,
  Lock,
  Search,
  UserCheck,
  LogOut,
  RefreshCw,
  Users,
  Layers,
  Sparkles,
} from 'lucide-react';

interface NavbarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  onOpenRoleSwitcher: () => void;
  onOpenTrackingSearch: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  setCurrentTab,
  onOpenRoleSwitcher,
  onOpenTrackingSearch,
}) => {
  const { user, logout } = useAuth();
  const [isIconModalOpen, setIsIconModalOpen] = useState(false);

  if (!user) return null;

  const isMaster = user.role === 'MASTER';
  const tenant = user.tenant;
  const isPremium = user.tenantPlan === 'PREMIUM';

  return (
    <header className="sticky top-0 z-30 bg-white border-b border-slate-200 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-3">
          {/* Left: Brand & Tenant Info */}
          <div className="flex items-center gap-3 min-w-0">
            <div className="flex items-center gap-2 cursor-pointer" onClick={() => setCurrentTab('orders')}>
              <TaskPrintLogo size={38} />
              <div className="hidden sm:block">
                <span className="text-base font-black tracking-tight text-[#1E3A5F] flex items-center gap-1">
                  TASK<span className="text-[#00A896]">PRINT</span>
                </span>
                <span className="text-[10px] text-slate-500 uppercase tracking-wider block -mt-1 font-semibold">
                  Workflow Percetakan
                </span>
              </div>
            </div>

            {/* Tenant Separation Badge */}
            <div className="h-7 w-px bg-slate-200 mx-1 hidden sm:block" />

            {isMaster ? (
              <div className="flex items-center gap-1.5 px-3 py-1 bg-purple-50 border border-purple-200 rounded-lg">
                <ShieldCheck className="w-4 h-4 text-purple-700" />
                <div className="text-left">
                  <span className="text-xs font-bold text-purple-900 block leading-none">
                    PLATFORM MASTER
                  </span>
                  <span className="text-[10px] text-purple-600 font-medium">
                    Owner & Multi-Tenant Control
                  </span>
                </div>
              </div>
            ) : (
              <div className="flex flex-col min-w-0">
                <div className="flex items-center gap-2">
                  <Building2 className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <span className="text-xs sm:text-sm font-bold text-slate-800 truncate">
                    {user.tenantName || 'Tenant'}
                  </span>
                  {/* Plan Badge */}
                  {isPremium ? (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300 rounded-full shrink-0">
                      <QrCode className="w-3 h-3 text-emerald-600" />
                      <span className="hidden md:inline">PREMIUM Rp300.000 •</span> Tracking ON
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-300 rounded-full shrink-0">
                      <Lock className="w-3 h-3 text-amber-600" />
                      <span className="hidden md:inline">BASIC Rp150.000 •</span> Tracking OFF
                    </span>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Center: Navigation Links */}
          <nav className="hidden md:flex items-center gap-1">
            {isMaster ? (
              <button
                id="nav-master-tenants"
                onClick={() => setCurrentTab('master')}
                className={`px-3 py-2 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 ${
                  currentTab === 'master'
                    ? 'bg-purple-100 text-purple-900'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <Layers className="w-4 h-4" />
                Kelola Semua Tenant
              </button>
            ) : (
              <>
                <button
                  id="nav-orders-tab"
                  onClick={() => setCurrentTab('orders')}
                  className={`px-3 py-2 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 ${
                    currentTab === 'orders'
                      ? 'bg-indigo-50 text-indigo-700'
                      : 'text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  <Layers className="w-4 h-4" />
                  Alur Order & Kanban
                </button>

                {user.role === 'ADMIN' && (
                  <button
                    id="nav-team-tab"
                    onClick={() => setCurrentTab('team')}
                    className={`px-3 py-2 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 ${
                      currentTab === 'team'
                        ? 'bg-indigo-50 text-indigo-700'
                        : 'text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    <Users className="w-4 h-4" />
                    Manajemen Tim & Akun
                  </button>
                )}
                {isPremium && (
                  <button
                    id="nav-ai-assistant-tab"
                    onClick={() => setCurrentTab('ai-assistant')}
                    className={`px-3 py-2 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 ${currentTab === 'ai-assistant' ? 'bg-indigo-50 text-indigo-700' : 'text-slate-600 hover:bg-slate-100'}`}
                    title="AI Assistant Task Print – Premium Rp300.000"
                  >
                    <Sparkles className="w-4 h-4" />
                    AI Assistant
                  </button>
                )}
              </>
            )}

            <button
              id="nav-tracking-search"
              onClick={onOpenTrackingSearch}
              className="px-3 py-2 text-xs font-semibold text-slate-600 hover:text-indigo-600 hover:bg-slate-100 rounded-lg transition-colors flex items-center gap-1.5"
              title="Cek Halaman Tracking Publik Konsumen"
            >
              <Search className="w-4 h-4" />
              Lacak Pesanan Klien
            </button>
          </nav>

          {/* Right: Quick Switcher & User Profile */}
          <div className="flex items-center gap-2">
            {/* App Icon Spec Modal Trigger */}
            <button
              id="open-app-icon-modal-btn"
              onClick={() => setIsIconModalOpen(true)}
              className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-bold text-[#1E3A5F] bg-teal-50 hover:bg-teal-100 border border-teal-200 rounded-xl transition-all shadow-2xs cursor-pointer"
              title="Lihat spesifikasi & unduh Icon Aplikasi Android / Favicon"
            >
              <Smartphone className="w-3.5 h-3.5 text-[#00A896]" />
              <span className="hidden sm:inline">Icon App</span>
            </button>

            {/* Fast Demo Role Switcher */}
            <button
              id="open-role-switcher-btn"
              onClick={onOpenRoleSwitcher}
              className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-bold text-amber-900 bg-amber-100 hover:bg-amber-200 border border-amber-300 rounded-xl transition-all shadow-2xs cursor-pointer"
              title="Uji role & isolasi antar-tenant"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-600" />
              <span className="hidden sm:inline">Ganti Akun Demo</span>
              <span className="sm:hidden">Akun</span>
            </button>

            {/* User Pill */}
            <div className="flex items-center gap-2 pl-2 border-l border-slate-200">
              <div className="hidden lg:block text-right">
                <p className="text-xs font-bold text-slate-800 leading-tight">{user.name}</p>
                <span className="text-[10px] text-slate-500 font-medium">
                  {ROLE_LABELS[user.role]?.title || user.role}
                </span>
              </div>

              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs ${
                  ROLE_LABELS[user.role]?.iconBg || 'bg-slate-200 text-slate-700'
                }`}
              >
                {user.name.charAt(0).toUpperCase()}
              </div>

              <button
                id="logout-btn"
                onClick={logout}
                className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                title="Keluar"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Sub-Navigation Bar */}
        <div className="md:hidden flex items-center justify-around py-2 border-t border-slate-100 text-xs">
          {isMaster ? (
            <button
              onClick={() => setCurrentTab('master')}
              className={`flex-1 text-center py-1 font-semibold ${
                currentTab === 'master' ? 'text-purple-700 border-b-2 border-purple-700' : 'text-slate-500'
              }`}
            >
              Kelola Tenant
            </button>
          ) : (
            <>
              <button
                onClick={() => setCurrentTab('orders')}
                className={`flex-1 text-center py-1 font-semibold ${
                  currentTab === 'orders' ? 'text-indigo-600 border-b-2 border-indigo-600' : 'text-slate-500'
                }`}
              >
                Alur Order
              </button>
              {user.role === 'ADMIN' && (
                <button
                  onClick={() => setCurrentTab('team')}
                  className={`flex-1 text-center py-1 font-semibold ${
                    currentTab === 'team' ? 'text-indigo-600 border-b-2 border-indigo-600' : 'text-slate-500'
                  }`}
                >
                  Tim
                </button>
              )}
            </>
          )}
              {isPremium && (
                <button
                  onClick={() => setCurrentTab('ai-assistant')}
                  className={`flex-1 text-center py-1 font-semibold ${currentTab === 'ai-assistant' ? 'text-indigo-600 border-b-2 border-indigo-600' : 'text-slate-500'}`}
                >
                  AI
                </button>
              )}
          <button
            onClick={onOpenTrackingSearch}
            className="flex-1 text-center py-1 text-slate-500 font-medium hover:text-indigo-600"
          >
            Lacak
          </button>
        </div>
      </div>

      {/* App Icon Spec & Download Modal */}
      <AppIconPreviewModal
        isOpen={isIconModalOpen}
        onClose={() => setIsIconModalOpen(false)}
      />
    </header>
  );
};
