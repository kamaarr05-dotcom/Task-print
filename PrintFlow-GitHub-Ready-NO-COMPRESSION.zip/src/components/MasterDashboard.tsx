import React, { useState, useEffect } from 'react';
import { Tenant, MasterStats, TenantPlan } from '../types.js';
import { masterApi } from '../services/api.js';
import { useAuth } from '../context/AuthContext.js';
import {
  Building2,
  Plus,
  ShieldCheck,
  CheckCircle2,
  XCircle,
  QrCode,
  Lock,
  Layers,
  Users,
  Search,
  ArrowRight,
  TrendingUp,
  AlertCircle,
  Sparkles,
} from 'lucide-react';

interface MasterDashboardProps {}

export const MasterDashboard: React.FC<MasterDashboardProps> = () => {
  const { switchUser } = useAuth();
  const [tenants, setTenants] = useState<Array<Tenant & { orderCount: number; userCount: number }>>([]);
  const [stats, setStats] = useState<MasterStats | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  // Form state for creating tenant
  const [formName, setFormName] = useState('');
  const [formCode, setFormCode] = useState('');
  const [formPlan, setFormPlan] = useState<TenantPlan>('PREMIUM');
  const [formPhone, setFormPhone] = useState('');
  const [formAddress, setFormAddress] = useState('');
  const [formAdminName, setFormAdminName] = useState('');
  const [formAdminUsername, setFormAdminUsername] = useState('');
  const [formAdminPassword, setFormAdminPassword] = useState('');
  const [formAdminPhone, setFormAdminPhone] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [tenantsData, statsData] = await Promise.all([
        masterApi.getTenants(),
        masterApi.getStats(),
      ]);
      setTenants(tenantsData);
      setStats(statsData);
    } catch (e: any) {
      setErrorMsg(e.message || 'Gagal memuat data master');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleCreateTenant = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName || !formAdminUsername || !formAdminPassword) {
      alert('Mohon lengkapi nama tenant dan data admin');
      return;
    }

    setIsSubmitting(true);
    try {
      await masterApi.createTenant({
        name: formName,
        code: formCode || formName.substring(0, 3).toUpperCase(),
        plan: formPlan,
        phone: formPhone,
        address: formAddress,
        adminName: formAdminName || `Admin ${formName}`,
        adminUsername: formAdminUsername,
        adminPassword: formAdminPassword,
        adminPhone: formAdminPhone,
      });

      setIsModalOpen(false);
      // Reset form
      setFormName('');
      setFormCode('');
      setFormPhone('');
      setFormAddress('');
      setFormAdminName('');
      setFormAdminUsername('');
      setFormAdminPassword('123456');
      setFormAdminPhone('');
      await loadData();
    } catch (err: any) {
      alert(err.message || 'Gagal membuat tenant baru');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleTogglePlan = async (tenant: Tenant) => {
    const nextPlan: TenantPlan = tenant.plan === 'PREMIUM' ? 'BASIC' : 'PREMIUM';
    const confirmText =
      nextPlan === 'PREMIUM'
        ? `Upgrade '${tenant.name}' ke PREMIUM (Rp300.000)? Fitur Client Tracking akan AKTIF.`
        : `Ubah '${tenant.name}' ke BASIC (Rp150.000)? Fitur Client Tracking akan NONAKTIF.`;

    if (!confirm(confirmText)) return;

    try {
      await masterApi.updateTenant(tenant.id, { plan: nextPlan });
      await loadData();
    } catch (err: any) {
      alert(err.message || 'Gagal mengubah paket tenant');
    }
  };

  const handleToggleStatus = async (tenant: Tenant) => {
    const nextStatus = tenant.status === 'ACTIVE' ? 'SUSPENDED' : 'ACTIVE';
    try {
      await masterApi.updateTenant(tenant.id, { status: nextStatus });
      await loadData();
    } catch (err: any) {
      alert(err.message || 'Gagal memperbarui status tenant');
    }
  };

  const filteredTenants = tenants.filter(
    t =>
      t.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.code.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-1 bg-purple-100 text-purple-800 text-xs font-bold rounded-lg uppercase tracking-wider">
              Platform Master
            </span>
            <span className="text-xs text-slate-500 font-medium">Luar Struktur Internal Tenant</span>
          </div>
          <h1 className="text-2xl font-black text-slate-900 mt-1">
            Manajemen Bisnis Percetakan (Multi-Tenant)
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Kelola pendaftaran tenant percetakan, penetapan paket Basic (Rp150.000) & Premium (Rp300.000), serta kontrol isolasi data platform.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            id="create-tenant-btn"
            onClick={() => setIsModalOpen(true)}
            className="inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-purple-600 hover:bg-purple-700 text-white font-bold text-sm rounded-xl shadow-sm transition-all shrink-0 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            Tambah Bisnis Percetakan
          </button>
        </div>
      </div>

      {/* Single Master Account Security Banner */}
      <div className="my-4 p-4 bg-purple-50/80 border border-purple-200 rounded-2xl flex flex-col md:flex-row md:items-center justify-between gap-3 shadow-2xs">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-purple-600 text-white flex items-center justify-center shrink-0">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-purple-950">Akun Master Tunggal Sistem:</span>
              <span className="px-2 py-0.5 text-xs font-mono font-bold bg-white text-purple-900 border border-purple-200 rounded-md">
                mdqputra@gmail.com
              </span>
              <span className="text-[10px] bg-purple-200 text-purple-800 font-semibold px-2 py-0.5 rounded-full">
                Platform Owner & Supabase RLS
              </span>
            </div>
            <p className="text-xs text-purple-800 mt-0.5">
              Role Master memiliki otoritas mutlak atas seluruh tenant percetakan dan dilindungi autentikasi aman tanpa password di source code.
            </p>
          </div>
        </div>
      </div>

      {/* Metrics Row */}
      {stats && (
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3 sm:gap-4 my-6">
          <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-2xs">
            <span className="text-xs font-semibold text-slate-500 block">Total Tenant</span>
            <span className="text-2xl font-black text-slate-900 mt-1 block">
              {stats.totalTenants}
            </span>
            <span className="text-[11px] text-emerald-600 font-medium mt-1 flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3" /> {stats.activeTenants} Aktif
            </span>
          </div>

          <div className="bg-emerald-50/60 border border-emerald-200 rounded-xl p-4 shadow-2xs">
            <span className="text-xs font-semibold text-emerald-800 block flex items-center gap-1">
              <QrCode className="w-3.5 h-3.5 text-emerald-600" />
              Paket PREMIUM
            </span>
            <span className="text-2xl font-black text-emerald-950 mt-1 block">
              {stats.premiumTenantsCount}
            </span>
            <span className="text-[11px] text-emerald-700 font-medium mt-1">
              Rp300.000 • Tracking ON
            </span>
          </div>

          <div className="bg-amber-50/60 border border-amber-200 rounded-xl p-4 shadow-2xs">
            <span className="text-xs font-semibold text-amber-800 block flex items-center gap-1">
              <Lock className="w-3.5 h-3.5 text-amber-600" />
              Paket BASIC
            </span>
            <span className="text-2xl font-black text-amber-950 mt-1 block">
              {stats.basicTenantsCount}
            </span>
            <span className="text-[11px] text-amber-700 font-medium mt-1">
              Rp150.000 • Tracking OFF
            </span>
          </div>

          <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-2xs">
            <span className="text-xs font-semibold text-slate-500 block">Total Pesanan</span>
            <span className="text-2xl font-black text-slate-900 mt-1 block">
              {stats.totalOrdersAcrossPlatform}
            </span>
            <span className="text-[11px] text-slate-500 mt-1">Semua Tenant</span>
          </div>

          <div className="col-span-2 md:col-span-1 bg-purple-50/60 border border-purple-200 rounded-xl p-4 shadow-2xs">
            <span className="text-xs font-semibold text-purple-800 block flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-purple-600" />
              Isolasi Tenant
            </span>
            <span className="text-xs font-bold text-purple-900 mt-2 block">
              Terkunci di Database
            </span>
            <span className="text-[10px] text-purple-700 leading-tight block mt-1">
              0% kebocoran lintas bisnis
            </span>
          </div>
        </div>
      )}

      {/* Tenant List */}
      <div className="bg-white border border-slate-200 rounded-2xl shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Building2 className="w-5 h-5 text-slate-600" />
            <h2 className="font-bold text-slate-900">Daftar Bisnis Percetakan Terdaftar</h2>
            <span className="px-2 py-0.5 text-xs bg-slate-100 text-slate-700 rounded-full font-medium">
              {filteredTenants.length}
            </span>
          </div>

          <div className="relative w-full sm:w-64">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Cari tenant atau kode..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
            />
          </div>
        </div>

        {isLoading ? (
          <div className="p-8 text-center text-slate-400 text-sm">Memuat daftar tenant...</div>
        ) : filteredTenants.length === 0 ? (
          <div className="p-8 text-center text-slate-500 text-sm">
            Tidak ada bisnis percetakan ditemukan.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-600">
              <thead className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200 uppercase tracking-wider">
                <tr>
                  <th className="px-4 py-3">Bisnis & Kode</th>
                  <th className="px-4 py-3">Paket Fitur</th>
                  <th className="px-4 py-3">Client Tracking</th>
                  <th className="px-4 py-3">Staf</th>
                  <th className="px-4 py-3">Pesanan</th>
                  <th className="px-4 py-3">Status</th>
                  <th className="px-4 py-3 text-right">Aksi Master</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredTenants.map(t => {
                  const isPrem = t.plan === 'PREMIUM';
                  return (
                    <tr key={t.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="px-4 py-3.5">
                        <div className="font-bold text-slate-900 text-sm">{t.name}</div>
                        <div className="flex items-center gap-2 mt-0.5">
                          <span className="px-1.5 py-0.5 bg-slate-100 text-slate-600 rounded text-[10px] font-mono font-semibold">
                            KODE: {t.code}
                          </span>
                          <span className="text-slate-400 text-[11px]">{t.phone || 'No Telp -'}</span>
                        </div>
                        <p className="text-[11px] text-slate-400 truncate max-w-xs">{t.address}</p>
                      </td>

                      <td className="px-4 py-3.5">
                        {isPrem ? (
                          <div>
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-300 rounded-full">
                              <Sparkles className="w-3 h-3 text-emerald-600" />
                              PREMIUM
                            </span>
                            <span className="text-[11px] text-slate-500 block mt-0.5">
                              Rp300.000 / paket
                            </span>
                          </div>
                        ) : (
                          <div>
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-bold bg-amber-100 text-amber-800 border border-amber-300 rounded-full">
                              BASIC
                            </span>
                            <span className="text-[11px] text-slate-500 block mt-0.5">
                              Rp150.000 / paket
                            </span>
                          </div>
                        )}
                      </td>

                      <td className="px-4 py-3.5">
                        {isPrem ? (
                          <span className="inline-flex items-center gap-1 text-emerald-700 font-semibold">
                            <QrCode className="w-4 h-4" />
                            Aktif (QR & Link)
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-slate-400 font-medium">
                            <Lock className="w-4 h-4" />
                            Nonaktif (Basic)
                          </span>
                        )}
                      </td>

                      <td className="px-4 py-3.5 font-medium text-slate-800">
                        {t.userCount} akun
                      </td>

                      <td className="px-4 py-3.5 font-semibold text-slate-900">
                        {t.orderCount} order
                      </td>

                      <td className="px-4 py-3.5">
                        {t.status === 'ACTIVE' ? (
                          <span className="px-2 py-0.5 text-[11px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-md">
                            Aktif
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 text-[11px] font-semibold bg-rose-50 text-rose-700 border border-rose-200 rounded-md">
                            Ditangguhkan
                          </span>
                        )}
                      </td>

                      <td className="px-4 py-3.5 text-right space-x-1.5 whitespace-nowrap">
                        <button
                          onClick={() => handleTogglePlan(t)}
                          className={`px-2.5 py-1 rounded-lg border text-xs font-medium transition-colors ${
                            isPrem
                              ? 'border-amber-300 text-amber-800 bg-amber-50 hover:bg-amber-100'
                              : 'border-emerald-300 text-emerald-800 bg-emerald-50 hover:bg-emerald-100'
                          }`}
                          title="Ubah paket tenant"
                        >
                          {isPrem ? 'Downgrade Basic' : 'Upgrade Premium'}
                        </button>

                        <button
                          onClick={() => handleToggleStatus(t)}
                          className={`px-2 py-1 rounded-lg text-xs font-medium transition-colors ${
                            t.status === 'ACTIVE'
                              ? 'text-rose-600 hover:bg-rose-50'
                              : 'text-emerald-600 hover:bg-emerald-50'
                          }`}
                        >
                          {t.status === 'ACTIVE' ? 'Suspend' : 'Aktifkan'}
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* CREATE TENANT MODAL */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl max-w-xl w-full p-6 my-8 border border-slate-200">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Building2 className="w-5 h-5 text-purple-600" />
                <h2 className="text-lg font-bold text-slate-900">Tambah Bisnis Percetakan (Tenant)</h2>
              </div>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-700 text-xl font-bold"
              >
                &times;
              </button>
            </div>

            <form onSubmit={handleCreateTenant} className="space-y-4 mt-4">
              {/* BISNIS PERCETAKAN INFO */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Nama Bisnis Percetakan *
                </label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Maju Jaya Printing & Offset"
                  value={formName}
                  onChange={e => setFormName(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Kode Singkatan (Prefix Order)
                  </label>
                  <input
                    type="text"
                    maxLength={4}
                    placeholder="Contoh: MJP"
                    value={formCode}
                    onChange={e => setFormCode(e.target.value.toUpperCase())}
                    className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:outline-none uppercase"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    No. WhatsApp / Telepon
                  </label>
                  <input
                    type="text"
                    placeholder="081234567xxx"
                    value={formPhone}
                    onChange={e => setFormPhone(e.target.value)}
                    className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Alamat Percetakan
                </label>
                <input
                  type="text"
                  placeholder="Jl. Raya No. 123, Kota..."
                  value={formAddress}
                  onChange={e => setFormAddress(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:outline-none"
                />
              </div>

              {/* PAKET FITUR SELECTION */}
              <div className="pt-2">
                <label className="block text-xs font-bold text-slate-800 mb-2">
                  Pilih Paket Fitur *
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div
                    onClick={() => setFormPlan('BASIC')}
                    className={`p-3 rounded-xl border-2 cursor-pointer transition-all ${
                      formPlan === 'BASIC'
                        ? 'border-amber-500 bg-amber-50/50 shadow-xs'
                        : 'border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-sm text-slate-900">Paket BASIC</span>
                      <span className="text-xs font-black text-amber-700">Rp150.000</span>
                    </div>
                    <p className="text-[11px] text-slate-500 mt-1">
                      Fitur operasional alur kerja penuh.
                    </p>
                    <div className="mt-2 flex items-center gap-1 text-[11px] font-semibold text-rose-600">
                      <Lock className="w-3.5 h-3.5" />
                      Client Tracking OFF
                    </div>
                  </div>

                  <div
                    onClick={() => setFormPlan('PREMIUM')}
                    className={`p-3 rounded-xl border-2 cursor-pointer transition-all ${
                      formPlan === 'PREMIUM'
                        ? 'border-emerald-500 bg-emerald-50/50 shadow-xs'
                        : 'border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-sm text-slate-900">Paket PREMIUM</span>
                      <span className="text-xs font-black text-emerald-700">Rp300.000</span>
                    </div>
                    <p className="text-[11px] text-slate-500 mt-1">
                      Semua fitur operasional alur kerja.
                    </p>
                    <div className="mt-2 flex items-center gap-1 text-[11px] font-bold text-emerald-700">
                      <QrCode className="w-3.5 h-3.5" />
                      Client Tracking ON (QR + Link)
                    </div>
                  </div>
                </div>
              </div>

              {/* INITIAL ADMIN CREDENTIALS */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3 mt-3">
                <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                  <Users className="w-3.5 h-3.5 text-purple-600" />
                  Akun Admin Pertama Tenant
                </h3>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                      Nama Admin Lengkap
                    </label>
                    <input
                      type="text"
                      placeholder="Contoh: Rahmat Hidayat"
                      value={formAdminName}
                      onChange={e => setFormAdminName(e.target.value)}
                      className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-purple-500"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                      Username Login *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="admin_nama"
                      value={formAdminUsername}
                      onChange={e => setFormAdminUsername(e.target.value.toLowerCase())}
                      className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-purple-500 font-mono"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                      Password Login *
                    </label>
                    <input
                      type="text"
                      required
                      value={formAdminPassword}
                      onChange={e => setFormAdminPassword(e.target.value)}
                      className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-purple-500 font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                      No. WhatsApp Admin
                    </label>
                    <input
                      type="text"
                      placeholder="08xxxxxxxx"
                      value={formAdminPhone}
                      onChange={e => setFormAdminPhone(e.target.value)}
                      className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-purple-500"
                    />
                  </div>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 text-xs font-bold bg-purple-600 hover:bg-purple-700 text-white rounded-xl shadow-xs transition-colors"
                >
                  {isSubmitting ? 'Menyimpan...' : 'Daftarkan Tenant & Admin'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
