import React from 'react';

interface TaskPrintLogoProps {
  size?: number | string;
  className?: string;
  showText?: boolean;
  textColor?: 'dark' | 'white';
}

/**
 * TaskPrintLogo - Official App Icon and Brand Mark for Task Print SaaS
 * Crafted as a modern, high-contrast Android launcher squircle icon
 * preserving the exact brand geometry: Navy Printer Tray + Teal Checkmark.
 */
export const TaskPrintLogo: React.FC<TaskPrintLogoProps> = ({
  size = 40,
  className = '',
  showText = false,
  textColor = 'dark',
}) => {
  const dimension = typeof size === 'number' ? `${size}px` : size;

  return (
    <div className={`inline-flex items-center gap-3 ${className}`}>
      {/* SaaS App Icon (Android Squircle Format) */}
      <svg
        viewBox="0 0 512 512"
        style={{ width: dimension, height: dimension }}
        className="shrink-0 drop-shadow-sm select-none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <filter id="taskPrintShadow" x="-10%" y="-10%" width="125%" height="125%">
            <feDropShadow dx="0" dy="12" stdDeviation="18" floodColor="#0f172a" floodOpacity="0.10" />
            <feDropShadow dx="0" dy="4" stdDeviation="6" floodColor="#0f172a" floodOpacity="0.05" />
          </filter>

          <linearGradient id="squircleBg" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#FFFFFF" />
            <stop offset="100%" stopColor="#F8FAFC" />
          </linearGradient>

          <linearGradient id="squircleBorder" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#E2E8F0" />
            <stop offset="100%" stopColor="#CBD5E1" />
          </linearGradient>
        </defs>

        {/* Squircle Background Container */}
        <rect
          x="32"
          y="32"
          width="448"
          height="448"
          rx="108"
          ry="108"
          fill="url(#squircleBg)"
          stroke="url(#squircleBorder)"
          strokeWidth="3.5"
          filter="url(#taskPrintShadow)"
        />

        {/* Optical Centered Brand Mark */}
        <g transform="translate(0, -6)">
          {/* Teal Checkmark Symbol */}
          <path
            d="M208 244 L256 292 L368 152"
            fill="none"
            stroke="#00A896"
            strokeWidth="36"
            strokeLinecap="round"
            strokeLinejoin="round"
          />

          {/* Navy Printer Tray Body */}
          <path
            d="M152 254 
               H 214 
               L 236 280 
               H 276 
               L 298 254 
               H 360 
               C 366.6 254 372 259.4 372 266 
               V 338 
               C 372 351.2 361.2 362 348 362 
               H 164 
               C 150.8 362 140 351.2 140 338 
               V 266 
               C 140 259.4 145.4 254 152 254 
               Z"
            fill="#1E3A5F"
          />

          {/* Negative Space Printer Slot Cutout */}
          <rect
            x="168"
            y="288"
            width="176"
            height="32"
            rx="6"
            fill="#FFFFFF"
          />
        </g>
      </svg>

      {/* Optional Brand Typography */}
      {showText && (
        <div className="flex items-baseline gap-1.5 leading-none select-none">
          <span
            className={`font-black tracking-tight text-lg ${
              textColor === 'white' ? 'text-white' : 'text-[#1E3A5F]'
            }`}
          >
            TASK
          </span>
          <span className="font-bold tracking-tight text-lg text-[#00A896]">
            PRINT
          </span>
        </div>
      )}
    </div>
  );
};
