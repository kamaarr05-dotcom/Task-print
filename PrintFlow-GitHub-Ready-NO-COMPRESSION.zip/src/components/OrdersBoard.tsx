import React, { useState, useEffect } from 'react';
import { Order, OrderStatus, Role } from '../types.js';
import { orderApi } from '../services/api.js';
import { useAuth } from '../context/AuthContext.js';
import { subscribeToTenantOrdersRealtime, isSupabaseConfigured } from '../services/supabase.js';
import {
  STATUS_CONFIG,
  ROLE_LABELS,
  formatDeadline,
  formatDate,
  formatWhatsappUrl,
} from '../utils/helpers.js';
import {
  Plus,
  Search,
  Filter,
  Layers,
  Clock,
  CheckCircle2,
  AlertCircle,
  MessageCircle,
  QrCode,
  Lock,
  ArrowRight,
  FileText,
  Paintbrush,
  Printer,
  Sparkles,
  ChevronRight,
  Eye,
  Trash2,
} from 'lucide-react';

interface OrdersBoardProps {
  onSelectOrder: (orderId: string) => void;
  onOpenCreateOrder: () => void;
  refreshTrigger: number;
}

export const OrdersBoard: React.FC<OrdersBoardProps> = ({
  onSelectOrder,
  onOpenCreateOrder,
  refreshTrigger,
}) => {
  const { user } = useAuth();
  const [orders, setOrders] = useState<Order[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [roleTab, setRoleTab] = useState<string>('AUTO');

  const isAdmin = user?.role === 'ADMIN' || user?.role === 'MASTER';
  const isDesigner = user?.role === 'DESAINER';
  const isPrinter = user?.role === 'OPERATOR_CETAK';
  const isQC = user?.role === 'FINISHING_QC';
  const isPremium = user?.tenantPlan === 'PREMIUM';

  const loadOrders = async () => {
    setIsLoading(true);
    try {
      const data = await orderApi.getOrders();
      setOrders(data);
    } catch (e) {
      console.error('Failed to load orders', e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadOrders();
  }, [refreshTrigger, user?.tenantId]);

  // Realtime subscription via Supabase PostgreSQL changes
  useEffect(() => {
    if (!user?.tenantId || !isSupabaseConfigured()) return;
    const channel = subscribeToTenantOrdersRealtime(user.tenantId, (payload) => {
      console.log('Realtime order update from Supabase:', payload);
      loadOrders();
    });
    return () => {
      if (channel) {
        channel.unsubscribe();
      }
    };
  }, [user?.tenantId]);

  // Set default view depending on user's role
  useEffect(() => {
    if (isDesigner) {
      setRoleTab('DESIGN');
    } else if (isPrinter) {
      setRoleTab('PRINT');
    } else if (isQC) {
      setRoleTab('QC');
    } else {
      setRoleTab('ALL');
    }
  }, [user?.role]);

  const handleDeleteOrder = async (e: React.MouseEvent, orderId: string, orderNumber: string) => {
    e.stopPropagation();
    if (!confirm(`Hapus pesanan ${orderNumber}? Tindakan ini tidak dapat dibatalkan.`)) return;
    try {
      await orderApi.deleteOrder(orderId);
      await loadOrders();
    } catch (err: any) {
      alert(err.message || 'Gagal menghapus order');
    }
  };

  // Filter logic
  const filteredOrders = orders.filter(order => {
    // Search matching
    const q = searchQuery.toLowerCase();
    const matchesSearch =
      order.orderNumber.toLowerCase().includes(q) ||
      order.customerName.toLowerCase().includes(q) ||
      order.jobType.toLowerCase().includes(q) ||
      order.material.toLowerCase().includes(q) ||
      order.customerWhatsapp.includes(q);

    if (!matchesSearch) return false;

    // Status filter
    if (statusFilter !== 'ALL' && order.status !== statusFilter) {
      return false;
    }

    // Role Tab filter
    if (roleTab === 'DESIGN') {
      return (
        order.needsDesign &&
        (order.status === 'VERIFIKASI' || order.status === 'DESAIN' || order.status === 'APPROVAL')
      );
    }
    if (roleTab === 'PRINT') {
      return order.status === 'PRODUKSI_CETAK';
    }
    if (roleTab === 'QC') {
      return order.status === 'FINISHING_QC';
    }
    if (roleTab === 'READY') {
      return order.status === 'SIAP_DIAMBIL_DIKIRIM' || order.status === 'SELESAI';
    }

    return true;
  });

  // Calculate quick metrics for current tenant
  const countNeedingDesign = orders.filter(
    o => o.needsDesign && (o.status === 'DESAIN' || o.status === 'APPROVAL')
  ).length;
  const countInPrint = orders.filter(o => o.status === 'PRODUKSI_CETAK').length;
  const countInQC = orders.filter(o => o.status === 'FINISHING_QC').length;
  const countReady = orders.filter(o => o.status === 'SIAP_DIAMBIL_DIKIRIM').length;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Top Banner: Tenant Isolation Notice & Actions */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Ruang Kerja Percetakan
            </span>
            <span className="h-3 w-px bg-slate-200" />
            <span className="text-xs font-semibold text-indigo-700">
              {user?.tenantName || 'Tenant'}
            </span>
            {isPremium ? (
              <span className="px-2 py-0.5 text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300 rounded-full flex items-center gap-1">
                <QrCode className="w-3 h-3" />
                PREMIUM (Tracking ON)
              </span>
            ) : (
              <span className="px-2 py-0.5 text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-300 rounded-full flex items-center gap-1">
                <Lock className="w-3 h-3" />
                BASIC (Tracking OFF)
              </span>
            )}
          </div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 mt-1">
            Manajemen Alur Kerja & Produksi Cetak
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Setiap data order, status, berkas, dan aktivitas terkunci aman pada database internal tenant ini.
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            id="btn-pesanan-baru"
            onClick={onOpenCreateOrder}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            Pesanan Masuk Baru
          </button>
        </div>
      </div>

      {/* Role-Specific Filter Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-xs font-semibold">
        <button
          onClick={() => setRoleTab('ALL')}
          className={`px-3 py-2 rounded-xl border transition-all whitespace-nowrap ${
            roleTab === 'ALL'
              ? 'bg-slate-900 border-slate-900 text-white shadow-xs'
              : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
          }`}
        >
          Semua Alur ({orders.length})
        </button>

        <button
          onClick={() => setRoleTab('DESIGN')}
          className={`px-3 py-2 rounded-xl border transition-all whitespace-nowrap flex items-center gap-1.5 ${
            roleTab === 'DESIGN'
              ? 'bg-purple-700 border-purple-700 text-white shadow-xs'
              : 'bg-white border-slate-200 text-purple-800 hover:bg-purple-50'
          }`}
        >
          <Paintbrush className="w-3.5 h-3.5" />
          Antrian Desain & Approval ({countNeedingDesign})
        </button>

        <button
          onClick={() => setRoleTab('PRINT')}
          className={`px-3 py-2 rounded-xl border transition-all whitespace-nowrap flex items-center gap-1.5 ${
            roleTab === 'PRINT'
              ? 'bg-indigo-700 border-indigo-700 text-white shadow-xs'
              : 'bg-white border-slate-200 text-indigo-800 hover:bg-indigo-50'
          }`}
        >
          <Printer className="w-3.5 h-3.5" />
          Antrian Mesin Cetak ({countInPrint})
        </button>

        <button
          onClick={() => setRoleTab('QC')}
          className={`px-3 py-2 rounded-xl border transition-all whitespace-nowrap flex items-center gap-1.5 ${
            roleTab === 'QC'
              ? 'bg-cyan-700 border-cyan-700 text-white shadow-xs'
              : 'bg-white border-slate-200 text-cyan-800 hover:bg-cyan-50'
          }`}
        >
          <CheckCircle2 className="w-3.5 h-3.5" />
          Finishing & QC ({countInQC})
        </button>

        <button
          onClick={() => setRoleTab('READY')}
          className={`px-3 py-2 rounded-xl border transition-all whitespace-nowrap flex items-center gap-1.5 ${
            roleTab === 'READY'
              ? 'bg-teal-700 border-teal-700 text-white shadow-xs'
              : 'bg-white border-slate-200 text-teal-800 hover:bg-teal-50'
          }`}
        >
          Siap Ambil / Kirim ({countReady})
        </button>
      </div>

      {/* Filter Bar: Search & Status Dropdown */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-white p-3.5 rounded-xl border border-slate-200">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Cari nomor order, nama konsumen, jenis pekerjaan, WA..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>

        <div className="flex items-center gap-2">
          <Filter className="w-3.5 h-3.5 text-slate-400" />
          <select
            value={statusFilter}
            onChange={e => setStatusFilter(e.target.value)}
            className="text-xs border border-slate-200 rounded-lg px-2.5 py-1.5 bg-white text-slate-700 font-medium focus:outline-none"
          >
            <option value="ALL">Semua Status</option>
            <option value="PESANAN_MASUK">1. Pesanan Masuk</option>
            <option value="VERIFIKASI">2. Verifikasi</option>
            <option value="DESAIN">3. Desain</option>
            <option value="APPROVAL">4. Approval</option>
            <option value="PRODUKSI_CETAK">5. Produksi / Cetak</option>
            <option value="FINISHING_QC">6. Finishing + QC</option>
            <option value="SIAP_DIAMBIL_DIKIRIM">7. Siap Diambil/Dikirim</option>
            <option value="SELESAI">8. Selesai</option>
          </select>
        </div>
      </div>

      {/* Orders List / Grid */}
      {isLoading ? (
        <div className="p-16 text-center text-slate-400 text-sm bg-white rounded-2xl border border-slate-200">
          Memuat pesanan percetakan...
        </div>
      ) : filteredOrders.length === 0 ? (
        <div className="p-12 text-center bg-white rounded-2xl border border-slate-200 space-y-3">
          <Layers className="w-10 h-10 text-slate-300 mx-auto" />
          <h3 className="font-bold text-slate-700 text-sm">Tidak ada pesanan pada filter ini</h3>
          <p className="text-xs text-slate-400 max-w-sm mx-auto">
            Gunakan tombol &quot;Pesanan Masuk Baru&quot; di atas untuk mendaftarkan order konsumen pertama Anda.
          </p>
          <button
            onClick={onOpenCreateOrder}
            className="px-4 py-2 bg-indigo-50 text-indigo-700 hover:bg-indigo-100 rounded-xl text-xs font-bold transition-colors cursor-pointer"
          >
            Buat Pesanan Baru Sekarang
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredOrders.map(order => {
            const statusConfig = STATUS_CONFIG[order.status] || STATUS_CONFIG.PESANAN_MASUK;
            const deadlineInfo = formatDeadline(order.deadline);

            return (
              <div
                key={order.id}
                onClick={() => onSelectOrder(order.id)}
                className="bg-white border border-slate-200 hover:border-indigo-300 rounded-2xl p-4 shadow-2xs hover:shadow-md transition-all cursor-pointer flex flex-col justify-between group"
              >
                <div>
                  {/* Top line: Order Number, Needs Design badge, Deadline */}
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div>
                      <span className="font-mono text-xs font-black text-slate-900 tracking-tight">
                        {order.orderNumber}
                      </span>
                      <p className="text-[11px] text-slate-400 font-medium mt-0.5">
                        {formatDate(order.createdAt)}
                      </p>
                    </div>

                    <div className="text-right">
                      <span
                        className={`inline-block px-2 py-0.5 text-[10px] font-bold rounded-md ${
                          deadlineInfo.isOverdue
                            ? 'bg-rose-100 text-rose-800'
                            : deadlineInfo.isUrgent
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-slate-100 text-slate-600'
                        }`}
                      >
                        {deadlineInfo.text}
                      </span>
                    </div>
                  </div>

                  {/* Customer & Job Info */}
                  <div className="space-y-1.5 my-3">
                    <div className="flex items-center justify-between">
                      <h3 className="font-bold text-sm text-slate-900 group-hover:text-indigo-600 transition-colors line-clamp-1">
                        {order.customerName}
                      </h3>
                      {order.customerWhatsapp && (
                        <a
                          href={formatWhatsappUrl(order.customerWhatsapp)}
                          target="_blank"
                          rel="noreferrer"
                          onClick={e => e.stopPropagation()}
                          className="text-emerald-600 hover:text-emerald-700 p-1"
                          title="Chat Konsumen via WhatsApp"
                        >
                          <MessageCircle className="w-3.5 h-3.5" />
                        </a>
                      )}
                    </div>

                    <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-100 text-xs space-y-1">
                      <div className="flex justify-between font-semibold text-slate-800">
                        <span className="truncate pr-2">{order.jobType}</span>
                        <span className="shrink-0 text-indigo-700 font-bold">
                          {order.quantity} {order.unit}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-500 truncate">
                        Ukuran: {order.size} • {order.material}
                      </div>
                      {order.finishing && (
                        <div className="text-[10px] text-slate-500 italic truncate">
                          Finishing: {order.finishing}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Badges: Needs Design vs Direct Print */}
                  <div className="flex flex-wrap items-center gap-1.5 mb-3">
                    {order.needsDesign ? (
                      <span className="px-2 py-0.5 text-[10px] font-medium bg-purple-50 text-purple-700 border border-purple-200 rounded-md">
                        Butuh Desain
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 text-[10px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-md">
                        ⚡ Siap Cetak Langsung
                      </span>
                    )}

                    {order.files.length > 0 && (
                      <span className="px-2 py-0.5 text-[10px] font-medium bg-slate-100 text-slate-600 rounded-md flex items-center gap-1">
                        <FileText className="w-3 h-3" />
                        {order.files.length} Berkas
                      </span>
                    )}
                  </div>
                </div>

                {/* Card Bottom: Status Badge & Action */}
                <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                  <span
                    className={`px-2.5 py-1 text-xs rounded-full font-bold border ${statusConfig.bg} ${statusConfig.color} ${statusConfig.border}`}
                  >
                    {statusConfig.label}
                  </span>

                  <div className="flex items-center gap-1 text-xs text-indigo-600 font-bold group-hover:translate-x-0.5 transition-transform">
                    <span>Buka Rincian</span>
                    <ChevronRight className="w-4 h-4" />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
