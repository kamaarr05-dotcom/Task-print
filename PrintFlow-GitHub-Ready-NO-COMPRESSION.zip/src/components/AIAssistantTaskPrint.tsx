import React, { useEffect, useMemo, useState } from 'react';
import { Bot, CheckCircle2, Clock3, Filter, Lock, RefreshCw, Search, Sparkles, X } from 'lucide-react';
import { aiTaskPrintApi, AITaskPrintResponse, AITaskPrintOrder } from '../services/api.js';
import { useAuth } from '../context/AuthContext.js';
import { STATUS_CONFIG, formatDate } from '../utils/helpers.js';

const statusOptions = Object.keys(STATUS_CONFIG) as Array<keyof typeof STATUS_CONFIG>;

const PremiumGate: React.FC<{ onBack?: () => void }> = ({ onBack }) => (
  <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
    <div className="bg-white border border-amber-200 rounded-3xl shadow-sm p-8 text-center">
      <div className="w-14 h-14 rounded-2xl bg-amber-100 text-amber-700 flex items-center justify-center mx-auto mb-4">
        <Lock className="w-7 h-7" />
      </div>
      <h2 className="text-xl font-black text-slate-900">AI Assistant Task Print</h2>
      <p className="mt-2 text-sm text-slate-600 max-w-xl mx-auto">
        Fitur ini khusus Paket Premium Rp300.000. Paket Basic Rp150.000 tidak memiliki akses AI Assistant.
      </p>
      {onBack && (
        <button onClick={onBack} className="mt-5 px-4 py-2 rounded-xl bg-slate-900 text-white text-sm font-bold hover:bg-slate-800">
          Kembali ke Alur Order
        </button>
      )}
    </div>
  </div>
);

const OrderMiniCard: React.FC<{ order: AITaskPrintOrder }> = ({ order }) => (
  <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs">
    <div className="flex items-start justify-between gap-3">
      <div className="min-w-0">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="font-black text-slate-900">{order.orderNumber}</span>
          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-700">{order.statusLabel}</span>
        </div>
        <p className="text-sm font-semibold text-slate-800 mt-1">{order.customerName}</p>
        <p className="text-xs text-slate-500 mt-0.5">{order.jobType} • {order.quantity} {order.unit} • {order.material}</p>
      </div>
      <div className="text-right shrink-0">
        <p className="text-[10px] text-slate-400 uppercase font-bold">Deadline</p>
        <p className="text-xs font-bold text-slate-700">{formatDate(order.deadline)}</p>
      </div>
    </div>
    <div className="grid grid-cols-2 gap-2 mt-3 text-[11px]">
      <div className="rounded-xl bg-slate-50 p-2"><span className="text-slate-400 block">PIC</span><span className="font-semibold text-slate-700">{order.pic || '-'}</span></div>
      <div className="rounded-xl bg-slate-50 p-2"><span className="text-slate-400 block">Tahap berikutnya</span><span className="font-semibold text-slate-700">{order.nextStep}</span></div>
    </div>
  </div>
);

export const AIAssistantTaskPrint: React.FC<{ onBack?: () => void }> = ({ onBack }) => {
  const { user } = useAuth();
  const [query, setQuery] = useState('');
  const [customer, setCustomer] = useState('');
  const [orderNumber, setOrderNumber] = useState('');
  const [pic, setPic] = useState('');
  const [status, setStatus] = useState('ALL');
  const [deadline, setDeadline] = useState<'ALL' | 'TODAY' | 'TOMORROW' | 'OVERDUE'>('ALL');
  const [result, setResult] = useState<AITaskPrintResponse | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const isPremium = user?.role === 'MASTER' || user?.tenantPlan === 'PREMIUM';

  useEffect(() => {
    if (isPremium) {
      runAssistant('Tampilkan ringkasan pesanan yang sedang berjalan.');
    }
  }, [user?.tenantId, isPremium]);

  const activeFilterCount = useMemo(() => [customer, orderNumber, pic, status !== 'ALL' ? status : '', deadline !== 'ALL' ? deadline : ''].filter(Boolean).length, [customer, orderNumber, pic, status, deadline]);

  async function runAssistant(defaultQuery?: string) {
    if (!isPremium) return;
    setIsLoading(true);
    setError('');
    try {
      const response = await aiTaskPrintApi.ask({
        question: (defaultQuery ?? query).trim() || 'Tampilkan ringkasan pesanan yang belum selesai.',
        filters: {
          customer: customer.trim() || undefined,
          orderNumber: orderNumber.trim() || undefined,
          pic: pic.trim() || undefined,
          status: status !== 'ALL' ? status : undefined,
          deadline: deadline !== 'ALL' ? deadline : undefined,
        },
      });
      setResult(response);
    } catch (e: any) {
      setError(e?.message || 'AI Assistant gagal memproses pertanyaan.');
    } finally {
      setIsLoading(false);
    }
  }

  function clearFilters() {
    setCustomer('');
    setOrderNumber('');
    setPic('');
    setStatus('ALL');
    setDeadline('ALL');
  }

  if (!isPremium) return <PremiumGate onBack={onBack} />;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-5">
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-indigo-100 text-indigo-700 flex items-center justify-center"><Bot className="w-5 h-5" /></div>
            <div>
              <h1 className="text-xl font-black text-slate-900">AI Assistant Task Print</h1>
              <p className="text-xs text-slate-500">Data aktual tenant: {user?.tenantName || 'Premium'}</p>
            </div>
          </div>
        </div>
        <span className="inline-flex items-center gap-1.5 self-start lg:self-auto px-3 py-1.5 rounded-full text-[11px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
          <CheckCircle2 className="w-3.5 h-3.5" /> PREMIUM Rp300.000 • AI ON
        </span>
      </div>

      <form onSubmit={e => { e.preventDefault(); runAssistant(); }} className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs">
        <div className="flex flex-col sm:flex-row gap-2">
          <div className="relative flex-1">
            <Sparkles className="absolute left-3 top-3.5 w-4 h-4 text-indigo-500" />
            <input value={query} onChange={e => setQuery(e.target.value)} placeholder="Contoh: Cek pesanan Pak Ali, yang terlambat, atau deadline besok..." className="w-full pl-9 pr-3 py-3 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
          </div>
          <button disabled={isLoading} className="px-5 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white text-sm font-black inline-flex items-center justify-center gap-2">
            {isLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
            Tanya AI
          </button>
        </div>
        <div className="flex flex-wrap gap-2 mt-3">
          {['Cek pesanan Pak Ali', 'Tampilkan semua yang belum selesai', 'Pesanan yang terlambat', 'Deadline besok', 'Sedang produksi', 'Menunggu approval'].map(text => (
            <button key={text} type="button" onClick={() => { setQuery(text); runAssistant(text); }} className="px-3 py-1.5 rounded-full bg-slate-50 hover:bg-indigo-50 border border-slate-200 text-[11px] text-slate-700 font-semibold">{text}</button>
          ))}
        </div>
      </form>

      <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs">
        <div className="flex items-center justify-between gap-3 mb-3">
          <div className="flex items-center gap-2"><Filter className="w-4 h-4 text-slate-500" /><span className="text-sm font-black text-slate-800">Filter & pencarian</span>{activeFilterCount > 0 && <span className="text-[10px] font-bold bg-indigo-100 text-indigo-700 px-2 py-0.5 rounded-full">{activeFilterCount} aktif</span>}</div>
          {activeFilterCount > 0 && <button type="button" onClick={clearFilters} className="text-xs font-bold text-rose-600 inline-flex items-center gap-1"><X className="w-3 h-3" /> Reset</button>}
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2">
          <input value={customer} onChange={e => setCustomer(e.target.value)} onKeyDown={e => e.key === 'Enter' && runAssistant()} placeholder="Customer" className="px-3 py-2 rounded-xl border border-slate-300 text-xs" />
          <input value={orderNumber} onChange={e => setOrderNumber(e.target.value)} onKeyDown={e => e.key === 'Enter' && runAssistant()} placeholder="Nomor pesanan" className="px-3 py-2 rounded-xl border border-slate-300 text-xs" />
          <input value={pic} onChange={e => setPic(e.target.value)} onKeyDown={e => e.key === 'Enter' && runAssistant()} placeholder="PIC" className="px-3 py-2 rounded-xl border border-slate-300 text-xs" />
          <select value={status} onChange={e => { setStatus(e.target.value); }} className="px-3 py-2 rounded-xl border border-slate-300 text-xs bg-white"><option value="ALL">Semua status</option>{statusOptions.map(s => <option key={s} value={s}>{STATUS_CONFIG[s]?.label || s}</option>)}</select>
          <select value={deadline} onChange={e => setDeadline(e.target.value as any)} className="px-3 py-2 rounded-xl border border-slate-300 text-xs bg-white"><option value="ALL">Semua deadline</option><option value="TODAY">Hari ini</option><option value="TOMORROW">Besok</option><option value="OVERDUE">Terlambat</option></select>
        </div>
        <button type="button" onClick={() => runAssistant()} className="mt-3 px-4 py-2 rounded-xl bg-slate-900 text-white text-xs font-bold">Terapkan Filter</button>
      </div>

      {error && <div className="bg-rose-50 border border-rose-200 text-rose-700 rounded-2xl p-4 text-sm">{error}</div>}

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-5">
        <div className="lg:col-span-3 bg-white border border-slate-200 rounded-2xl shadow-2xs p-5 min-h-[220px]">
          <div className="flex items-center gap-2 mb-3"><Bot className="w-4 h-4 text-indigo-600" /><h2 className="text-sm font-black text-slate-900">Jawaban AI</h2></div>
          {result ? <>
            <div className="whitespace-pre-wrap text-sm leading-6 text-slate-700">{result.answer}</div>
            <div className="mt-4 pt-4 border-t border-slate-100 flex flex-wrap items-center gap-3 text-[11px] text-slate-500">
              <span className="inline-flex items-center gap-1"><Clock3 className="w-3.5 h-3.5" /> Data diperbarui: {formatDate(result.dataUpdatedAt)}</span>
              <span>{result.source === 'supabase' ? 'Sumber: Supabase + RLS' : 'Sumber: Database demo tenant'}</span>
            </div>
          </> : <p className="text-sm text-slate-400">Ajukan pertanyaan untuk melihat jawaban berdasarkan data Task Print terbaru.</p>}
        </div>

        <div className="lg:col-span-2 space-y-3">
          <div className="flex items-center justify-between"><h2 className="text-sm font-black text-slate-900">Pesanan relevan</h2><span className="text-xs text-slate-400">{result?.orders.length || 0} hasil</span></div>
          {result?.orders?.length ? result.orders.map(order => <OrderMiniCard key={order.id} order={order} />) : <div className="bg-white border border-dashed border-slate-300 rounded-2xl p-8 text-center text-sm text-slate-400">Belum ada hasil yang cocok.</div>}
        </div>
      </div>
    </div>
  );
};
