import React, { useState, useEffect } from 'react';
import { User, Role } from '../types.js';
import { userApi } from '../services/api.js';
import { useAuth } from '../context/AuthContext.js';
import { ROLE_LABELS } from '../utils/helpers.js';
import {
  Users,
  UserPlus,
  Trash2,
  ShieldCheck,
  Paintbrush,
  Printer,
  CheckCircle2,
  Phone,
  Lock,
  Sparkles,
} from 'lucide-react';

export const TeamManagement: React.FC = () => {
  const { user } = useAuth();
  const [users, setUsers] = useState<User[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);

  // New staff form state
  const [name, setName] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('123456');
  const [role, setRole] = useState<Role>('DESAINER');
  const [phone, setPhone] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const loadUsers = async () => {
    setIsLoading(true);
    try {
      const list = await userApi.getUsers();
      setUsers(list);
    } catch (e) {
      console.error('Failed to load users', e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadUsers();
  }, [user?.tenantId]);

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !username || !password) {
      alert('Nama, username, dan password wajib diisi.');
      return;
    }

    setIsSubmitting(true);
    try {
      await userApi.createUser({
        name,
        username,
        password,
        role,
        phone,
      });
      setIsModalOpen(false);
      setName('');
      setUsername('');
      setPassword('123456');
      setPhone('');
      await loadUsers();
    } catch (err: any) {
      alert(err.message || 'Gagal menambahkan staf');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteUser = async (userId: string, userName: string) => {
    if (!confirm(`Hapus akun '${userName}' dari tim percetakan ini?`)) return;
    try {
      await userApi.deleteUser(userId);
      await loadUsers();
    } catch (err: any) {
      alert(err.message || 'Gagal menghapus user');
    }
  };

  const getRoleIcon = (r: Role) => {
    switch (r) {
      case 'ADMIN':
        return <Users className="w-4 h-4 text-blue-600" />;
      case 'DESAINER':
        return <Paintbrush className="w-4 h-4 text-fuchsia-600" />;
      case 'OPERATOR_CETAK':
        return <Printer className="w-4 h-4 text-indigo-600" />;
      case 'FINISHING_QC':
        return <CheckCircle2 className="w-4 h-4 text-emerald-600" />;
      default:
        return <Users className="w-4 h-4 text-slate-600" />;
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Akses & Otoritas Internal
            </span>
            <span className="h-3 w-px bg-slate-200" />
            <span className="text-xs font-semibold text-indigo-700">
              {user?.tenantName || 'Tenant'}
            </span>
          </div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 mt-1">
            Manajemen Tim & Karyawan Percetakan
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Admin mengelola akun internal: Desainer, Operator Cetak, dan Finishing + QC untuk tenant ini.
          </p>
        </div>

        <button
          id="add-team-member-btn"
          onClick={() => setIsModalOpen(true)}
          className="inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors cursor-pointer"
        >
          <UserPlus className="w-4 h-4" />
          Tambah Anggota Tim
        </button>
      </div>

      {/* Team Members Table */}
      <div className="bg-white border border-slate-200 rounded-2xl shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Users className="w-4 h-4 text-slate-500" />
            <h2 className="font-bold text-sm text-slate-900">Daftar Akun Tim Aktif</h2>
            <span className="px-2 py-0.5 text-xs bg-slate-100 text-slate-700 rounded-full font-semibold">
              {users.length}
            </span>
          </div>
        </div>

        {isLoading ? (
          <div className="p-12 text-center text-slate-400 text-sm">Memuat data tim...</div>
        ) : users.length === 0 ? (
          <div className="p-12 text-center text-slate-500 text-sm">
            Belum ada anggota tim terdaftar.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-600">
              <thead className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200 uppercase tracking-wider">
                <tr>
                  <th className="px-4 py-3">Nama Lengkap & Username</th>
                  <th className="px-4 py-3">Peran / Hak Akses</th>
                  <th className="px-4 py-3">Tugas Kerja Utama</th>
                  <th className="px-4 py-3">Kontak WhatsApp</th>
                  <th className="px-4 py-3 text-right">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {users.map(member => {
                  const roleConfig = ROLE_LABELS[member.role] || ROLE_LABELS.ADMIN;
                  const isCurrent = user?.id === member.id;

                  const roleDescriptionMap: Record<Role, string> = {
                    MASTER: 'Platform Master Owner',
                    ADMIN: 'Mengelola operasional, order masuk, dan akun staf',
                    DESAINER: 'Mengerjakan visual layout, mockup, & approval konsumen',
                    OPERATOR_CETAK: 'Menjalankan mesin cetak digital/offset/sablon',
                    FINISHING_QC: 'Penyelesaian jilid, laminasi, potong, & kontrol mutu',
                  };

                  return (
                    <tr key={member.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="px-4 py-3.5">
                        <div className="flex items-center gap-2.5">
                          <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center">
                            {getRoleIcon(member.role)}
                          </div>
                          <div>
                            <span className="font-bold text-slate-900 text-sm block">
                              {member.name}
                              {isCurrent && (
                                <span className="ml-2 text-[10px] font-semibold text-indigo-700 bg-indigo-50 px-1.5 py-0.5 rounded">
                                  (Anda)
                                </span>
                              )}
                            </span>
                            <span className="text-[11px] text-slate-400 font-mono">
                              @{member.username}
                            </span>
                          </div>
                        </div>
                      </td>

                      <td className="px-4 py-3.5">
                        <span
                          className={`inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-bold rounded-full border ${roleConfig.badge}`}
                        >
                          {roleConfig.title}
                        </span>
                      </td>

                      <td className="px-4 py-3.5 text-slate-600 max-w-xs">
                        {roleDescriptionMap[member.role]}
                      </td>

                      <td className="px-4 py-3.5 font-mono text-slate-700">
                        {member.phone || '-'}
                      </td>

                      <td className="px-4 py-3.5 text-right">
                        {!isCurrent && (
                          <button
                            onClick={() => handleDeleteUser(member.id, member.name)}
                            className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                            title="Hapus akun"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* CREATE USER MODAL */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6 my-8 border border-slate-200">
            <h2 className="text-lg font-bold text-slate-900 mb-1">Tambah Akun Tim Percetakan</h2>
            <p className="text-xs text-slate-500 mb-4">
              Buat akun peran untuk Desainer, Operator Cetak, Finishing + QC, atau Admin tambahan.
            </p>

            <form onSubmit={handleCreateUser} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Nama Lengkap *</label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Rahmat Pratama"
                  value={name}
                  onChange={e => setName(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Peran / Akses Operasional *
                </label>
                <select
                  value={role}
                  onChange={e => setRole(e.target.value as Role)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none font-semibold bg-white"
                >
                  <option value="DESAINER">Desainer Grafis (Desain & Approval)</option>
                  <option value="OPERATOR_CETAK">Operator Cetak (Mesin & Produksi)</option>
                  <option value="FINISHING_QC">Finishing + QC (Kontrol Kualitas & Kemasan)</option>
                  <option value="ADMIN">Admin Percetakan (Kelola Seluruh Operasional)</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Username Login *</label>
                  <input
                    type="text"
                    required
                    placeholder="nama_user"
                    value={username}
                    onChange={e => setUsername(e.target.value.toLowerCase())}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none font-mono"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Password *</label>
                  <input
                    type="text"
                    required
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">No. WhatsApp / HP</label>
                <input
                  type="text"
                  placeholder="081234567xxx"
                  value={phone}
                  onChange={e => setPhone(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none font-mono"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 font-bold bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl shadow-xs transition-colors cursor-pointer"
                >
                  {isSubmitting ? 'Menyimpan...' : 'Simpan Akun'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
