import React from 'react';
import { useAuth } from '../context/AuthContext.js';
import { ROLE_LABELS } from '../utils/helpers.js';
import {
  ShieldCheck,
  Building2,
  Users,
  Paintbrush,
  Printer,
  CheckCircle2,
  Lock,
  QrCode,
  X,
  Sparkles,
} from 'lucide-react';

interface RoleSwitcherModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const RoleSwitcherModal: React.FC<RoleSwitcherModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { user, demoUsers, switchUser } = useAuth();

  if (!isOpen) return null;

  // Filter out any MASTER users so Master is strictly hidden from role switcher & tenant UI
  const cahayaUsers = demoUsers.filter(u => u.tenantId === 'tenant-cahaya' && u.role !== 'MASTER');
  const primaUsers = demoUsers.filter(u => u.tenantId === 'tenant-prima' && u.role !== 'MASTER');

  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'ADMIN':
        return <Users className="w-4 h-4 text-blue-600" />;
      case 'DESAINER':
        return <Paintbrush className="w-4 h-4 text-fuchsia-600" />;
      case 'OPERATOR_CETAK':
        return <Printer className="w-4 h-4 text-indigo-600" />;
      case 'FINISHING_QC':
        return <CheckCircle2 className="w-4 h-4 text-emerald-600" />;
      default:
        return <Users className="w-4 h-4 text-slate-600" />;
    }
  };

  const handleSelect = async (userId: string) => {
    await switchUser(userId);
    onClose();
  };

  return (
    <div
      id="role-switcher-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto"
    >
      <div className="bg-white rounded-2xl shadow-2xl max-w-3xl w-full p-6 my-8 border border-slate-200">
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-amber-500" />
              <h2 className="text-xl font-bold text-slate-900">Uji Akun & Isolasi Multi-Tenant</h2>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Ganti akun peran dengan 1 klik untuk memverifikasi isolasi data antar-tenant, hak akses role, serta fitur paket.
            </p>
          </div>
          <button
            id="close-switcher-btn"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-6 mt-5 max-h-[75vh] overflow-y-auto pr-1">
          {/* SECTION 1: TENANT 1 - CAHAYA PRINT (PREMIUM - TRACKING ON) */}
          <div className="bg-emerald-50/40 border border-emerald-200 rounded-xl p-4">
            <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
              <div className="flex items-center gap-2">
                <span className="p-1.5 bg-emerald-100 text-emerald-700 rounded-lg">
                  <Building2 className="w-4 h-4" />
                </span>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-sm font-semibold text-slate-900">Cahaya Print Digital</h3>
                    <span className="px-2 py-0.5 text-[10px] font-bold bg-emerald-700 text-white rounded-full flex items-center gap-1">
                      <QrCode className="w-3 h-3" />
                      PREMIUM Rp300.000 • Client Tracking ON
                    </span>
                  </div>
                  <p className="text-xs text-slate-500">
                    Konsumen dapat melacak status via Link & QR Code tanpa login.
                  </p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {cahayaUsers.map(u => {
                const isActive = user?.id === u.id;
                return (
                  <button
                    key={u.id}
                    id={`switch-user-${u.username}`}
                    onClick={() => handleSelect(u.id)}
                    className={`flex items-center justify-between p-2.5 rounded-lg border text-left transition-all ${
                      isActive
                        ? 'bg-emerald-100/70 border-emerald-500 ring-2 ring-emerald-200 text-emerald-950 font-medium'
                        : 'bg-white border-slate-200 hover:border-emerald-300 hover:bg-emerald-50/30'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="w-7 h-7 rounded-full bg-slate-100 flex items-center justify-center">
                        {getRoleIcon(u.role)}
                      </div>
                      <div>
                        <p className="text-xs font-semibold text-slate-900">{u.name}</p>
                        <span className="inline-block text-[10px] px-1.5 py-0.2 rounded bg-slate-100 text-slate-700 font-medium">
                          {ROLE_LABELS[u.role].title}
                        </span>
                      </div>
                    </div>
                    {isActive ? (
                      <span className="text-[11px] font-semibold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded">
                        Aktif
                      </span>
                    ) : (
                      <span className="text-[11px] text-slate-400">Masuk &rarr;</span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* SECTION 3: TENANT 2 - PRIMA OFFSET (BASIC - TRACKING OFF) */}
          <div className="bg-amber-50/40 border border-amber-200 rounded-xl p-4">
            <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
              <div className="flex items-center gap-2">
                <span className="p-1.5 bg-amber-100 text-amber-700 rounded-lg">
                  <Building2 className="w-4 h-4" />
                </span>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-sm font-semibold text-slate-900">Prima Offset & Sablon</h3>
                    <span className="px-2 py-0.5 text-[10px] font-bold bg-amber-600 text-white rounded-full flex items-center gap-1">
                      <Lock className="w-3 h-3" />
                      BASIC Rp150.000 • Client Tracking OFF
                    </span>
                  </div>
                  <p className="text-xs text-slate-500">
                    Data terisolasi total dari Cahaya Print. Tracking QR Code publik tidak diizinkan di paket Basic.
                  </p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {primaUsers.map(u => {
                const isActive = user?.id === u.id;
                return (
                  <button
                    key={u.id}
                    id={`switch-user-${u.username}`}
                    onClick={() => handleSelect(u.id)}
                    className={`flex items-center justify-between p-2.5 rounded-lg border text-left transition-all ${
                      isActive
                        ? 'bg-amber-100/70 border-amber-500 ring-2 ring-amber-200 text-amber-950 font-medium'
                        : 'bg-white border-slate-200 hover:border-amber-300 hover:bg-amber-50/30'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="w-7 h-7 rounded-full bg-slate-100 flex items-center justify-center">
                        {getRoleIcon(u.role)}
                      </div>
                      <div>
                        <p className="text-xs font-semibold text-slate-900">{u.name}</p>
                        <span className="inline-block text-[10px] px-1.5 py-0.2 rounded bg-slate-100 text-slate-700 font-medium">
                          {ROLE_LABELS[u.role].title}
                        </span>
                      </div>
                    </div>
                    {isActive ? (
                      <span className="text-[11px] font-semibold text-amber-800 bg-amber-100 px-2 py-0.5 rounded">
                        Aktif
                      </span>
                    ) : (
                      <span className="text-[11px] text-slate-400">Masuk &rarr;</span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        <div className="mt-5 pt-3 border-t border-slate-100 flex justify-between items-center text-xs text-slate-500">
          <span>Password semua akun staf demo: <code className="bg-slate-100 px-1 py-0.5 rounded">123456</code> (Master: <code className="bg-slate-100 px-1 py-0.5 rounded">master123</code>)</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-100 rounded-lg transition-colors"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
