import React from 'react';
import { OrderStatus } from '../types.js';
import { STATUS_CONFIG } from '../utils/helpers.js';
import { Check, Clock, ChevronRight } from 'lucide-react';

interface WorkflowProgressBarProps {
  currentStatus: OrderStatus;
  needsDesign: boolean;
  onStatusClick?: (status: OrderStatus) => void;
  interactive?: boolean;
}

const ORDERED_STEPS: OrderStatus[] = [
  'PESANAN_MASUK',
  'VERIFIKASI',
  'DESAIN',
  'APPROVAL',
  'PRODUKSI_CETAK',
  'FINISHING_QC',
  'SIAP_DIAMBIL_DIKIRIM',
  'SELESAI',
];

export const WorkflowProgressBar: React.FC<WorkflowProgressBarProps> = ({
  currentStatus,
  needsDesign,
  onStatusClick,
  interactive = false,
}) => {
  const currentStepNum = STATUS_CONFIG[currentStatus]?.step || 1;

  return (
    <div className="w-full py-3">
      {/* Desktop / Tablet Stepper */}
      <div className="hidden md:flex items-center justify-between relative">
        <div className="absolute top-1/2 left-0 right-0 h-0.5 bg-slate-200 -translate-y-1/2 z-0" />
        {ORDERED_STEPS.map((statusKey, index) => {
          const config = STATUS_CONFIG[statusKey];
          const isSkipped = !needsDesign && (statusKey === 'DESAIN' || statusKey === 'APPROVAL');
          const isPassed = currentStepNum > config.step;
          const isCurrent = currentStatus === statusKey;

          let nodeBg = 'bg-white border-2 border-slate-300 text-slate-400';
          let labelColor = 'text-slate-500 font-normal';

          if (isSkipped) {
            nodeBg = 'bg-slate-100 border-2 border-dashed border-slate-300 text-slate-400';
            labelColor = 'text-slate-400 line-through';
          } else if (isPassed) {
            nodeBg = 'bg-emerald-600 border-2 border-emerald-600 text-white';
            labelColor = 'text-emerald-700 font-semibold';
          } else if (isCurrent) {
            nodeBg = 'bg-indigo-600 border-4 border-indigo-200 text-white shadow-md ring-2 ring-indigo-500';
            labelColor = 'text-indigo-900 font-bold';
          }

          return (
            <div
              key={statusKey}
              onClick={() => interactive && onStatusClick && onStatusClick(statusKey)}
              className={`flex flex-col items-center relative z-10 group ${
                interactive ? 'cursor-pointer' : ''
              }`}
            >
              <div
                className={`w-9 h-9 rounded-full flex items-center justify-center transition-all ${nodeBg}`}
              >
                {isPassed && !isSkipped ? (
                  <Check className="w-4 h-4 stroke-[3]" />
                ) : isCurrent ? (
                  <Clock className="w-4 h-4 animate-pulse" />
                ) : (
                  <span className="text-xs font-semibold">{index + 1}</span>
                )}
              </div>
              <div className="mt-2 text-center max-w-[85px]">
                <p className={`text-[11px] leading-tight ${labelColor}`}>{config.label}</p>
                {isSkipped && (
                  <span className="text-[9px] text-slate-400 block -mt-0.5">Dilewati</span>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Mobile Stepper (compact view with current step prominence) */}
      <div className="md:hidden bg-slate-50 border border-slate-200 rounded-xl p-3">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs text-slate-500">
            Tahap {currentStepNum} dari 8 {!needsDesign ? '(Jalur Cepat Tanpa Desain)' : ''}
          </span>
          <span
            className={`text-xs px-2.5 py-0.5 rounded-full font-semibold ${STATUS_CONFIG[currentStatus]?.bg} ${STATUS_CONFIG[currentStatus]?.color}`}
          >
            {STATUS_CONFIG[currentStatus]?.label}
          </span>
        </div>
        <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
          <div
            className="bg-indigo-600 h-full rounded-full transition-all duration-300"
            style={{ width: `${(currentStepNum / 8) * 100}%` }}
          />
        </div>
        <div className="flex items-center gap-1 mt-2 text-[11px] text-slate-600 overflow-x-auto pb-1 scrollbar-none">
          {ORDERED_STEPS.map((s, idx) => {
            const isCurr = s === currentStatus;
            const isSkip = !needsDesign && (s === 'DESAIN' || s === 'APPROVAL');
            return (
              <span
                key={s}
                className={`whitespace-nowrap px-2 py-0.5 rounded ${
                  isCurr
                    ? 'bg-indigo-600 text-white font-medium'
                    : isSkip
                    ? 'text-slate-300 line-through'
                    : 'text-slate-500'
                }`}
              >
                {idx + 1}. {STATUS_CONFIG[s].label}
              </span>
            );
          })}
        </div>
      </div>
    </div>
  );
};
