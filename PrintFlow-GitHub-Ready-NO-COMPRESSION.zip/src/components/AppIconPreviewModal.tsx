import React from 'react';
import { TaskPrintLogo } from './TaskPrintLogo.js';
import { X, Smartphone, Layers, Check, Download, Sparkles, ExternalLink } from 'lucide-react';

interface AppIconPreviewModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AppIconPreviewModal: React.FC<AppIconPreviewModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-200">
        {/* Modal Header */}
        <div className="flex items-center justify-between pb-5 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <TaskPrintLogo size={42} />
            <div>
              <h2 className="text-xl font-black text-[#1E3A5F] tracking-tight flex items-center gap-1.5">
                TASK<span className="text-[#00A896]">PRINT</span>
                <span className="text-xs font-semibold px-2 py-0.5 bg-teal-50 text-teal-700 border border-teal-200 rounded-md">
                  App Launcher Icon
                </span>
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Spesifikasi resmi icon aplikasi Android (Squircle), Favicon, dan Web App
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-full transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="py-6 space-y-6">
          {/* Main Showcase Banner */}
          <div className="bg-linear-to-br from-slate-900 via-[#1E3A5F] to-slate-900 rounded-2xl p-6 text-white flex flex-col sm:flex-row items-center justify-around gap-6 shadow-inner">
            {/* Primary Squircle 140px */}
            <div className="flex flex-col items-center">
              <div className="p-3 bg-white/5 rounded-3xl border border-white/10 backdrop-blur-sm shadow-xl">
                <TaskPrintLogo size={120} />
              </div>
              <span className="mt-3 text-xs font-semibold text-slate-300">
                Android Launcher Icon (Squircle)
              </span>
            </div>

            {/* Mobile Mockup Preview */}
            <div className="w-48 bg-slate-800/80 border border-slate-700/60 rounded-2xl p-3 shadow-lg">
              <div className="flex items-center justify-between text-[10px] text-slate-400 pb-2 border-b border-slate-700/40">
                <span>12:00</span>
                <span>LTE 100%</span>
              </div>
              <div className="grid grid-cols-3 gap-2 pt-3">
                <div className="flex flex-col items-center gap-1">
                  <div className="w-9 h-9 rounded-xl bg-slate-700/50 flex items-center justify-center">
                    <Smartphone className="w-4 h-4 text-slate-400" />
                  </div>
                  <span className="text-[9px] text-slate-400">Telepon</span>
                </div>
                {/* Task Print Icon */}
                <div className="flex flex-col items-center gap-1">
                  <TaskPrintLogo size={36} />
                  <span className="text-[9px] font-bold text-teal-300 truncate max-w-full">
                    Task Print
                  </span>
                </div>
                <div className="flex flex-col items-center gap-1">
                  <div className="w-9 h-9 rounded-xl bg-slate-700/50 flex items-center justify-center">
                    <Layers className="w-4 h-4 text-slate-400" />
                  </div>
                  <span className="text-[9px] text-slate-400">Berkas</span>
                </div>
              </div>
            </div>
          </div>

          {/* Size Scale Verification Grid */}
          <div>
            <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-3">
              Uji Skala & Keterbacaan Ukuran (Scalability Test)
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {/* 64px */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 flex flex-col items-center justify-center text-center">
                <TaskPrintLogo size={64} />
                <span className="text-xs font-bold text-slate-700 mt-2">64 × 64 px</span>
                <span className="text-[10px] text-slate-400">Tablet / Desktop</span>
              </div>

              {/* 48px */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 flex flex-col items-center justify-center text-center">
                <TaskPrintLogo size={48} />
                <span className="text-xs font-bold text-slate-700 mt-2">48 × 48 px</span>
                <span className="text-[10px] text-slate-400">Android MDPI</span>
              </div>

              {/* 32px */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 flex flex-col items-center justify-center text-center">
                <TaskPrintLogo size={32} />
                <span className="text-xs font-bold text-slate-700 mt-2">32 × 32 px</span>
                <span className="text-[10px] text-slate-400">Tab Favicon</span>
              </div>

              {/* 16px */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 flex flex-col items-center justify-center text-center">
                <TaskPrintLogo size={16} />
                <span className="text-xs font-bold text-slate-700 mt-2">16 × 16 px</span>
                <span className="text-[10px] text-slate-400">Mini Favicon</span>
              </div>
            </div>
          </div>

          {/* Guidelines Checklist */}
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4">
            <h4 className="text-xs font-bold text-slate-800 mb-2.5">
              Karakteristik Desain Berdasarkan Logo Asli:
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-600">
              <div className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-teal-600 shrink-0" />
                <span>Bentuk identik: Tray Navy + Checkmark Teal</span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-teal-600 shrink-0" />
                <span>Warna identitas: Navy (#1E3A5F) & Teal (#00A896)</span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-teal-600 shrink-0" />
                <span>Format squircle Android adaptif (22% radius)</span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-teal-600 shrink-0" />
                <span>Bebas teks / slogan (fokus pada simbol ikonik)</span>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between pt-4 border-t border-slate-100">
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <span className="w-2 h-2 rounded-full bg-teal-500" />
            <span>Terkoneksi ke /public/favicon.svg & /manifest.json</span>
          </div>

          <div className="flex items-center gap-2">
            <a
              href="/app-icon.svg"
              download="task-print-app-icon.svg"
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-[#1E3A5F] bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              Unduh SVG Icon
            </a>
            <button
              onClick={onClose}
              className="px-4 py-2 bg-[#1E3A5F] hover:bg-[#162a4a] text-white text-xs font-bold rounded-xl shadow-xs transition-colors"
            >
              Tutup
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
