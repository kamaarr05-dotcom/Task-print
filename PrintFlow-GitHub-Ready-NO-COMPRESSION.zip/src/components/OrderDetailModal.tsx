import React, { useState, useEffect } from 'react';
import QRCode from 'qrcode';
import { Order, OrderStatus, Role } from '../types.js';
import { orderApi } from '../services/api.js';
import { useAuth } from '../context/AuthContext.js';
import { STATUS_CONFIG, formatDeadline, formatDate, formatWhatsappUrl } from '../utils/helpers.js';
import { WorkflowProgressBar } from './WorkflowProgressBar.js';
import { uploadOrderFileToSupabase, isSupabaseConfigured } from '../services/supabase.js';
import {
  X,
  QrCode,
  Lock,
  ExternalLink,
  MessageCircle,
  Copy,
  Check,
  Upload,
  FileText,
  Clock,
  User,
  Calendar,
  Layers,
  ArrowRight,
  Sparkles,
  AlertCircle,
  Trash2,
  Share2,
} from 'lucide-react';

interface OrderDetailModalProps {
  orderId: string | null;
  onClose: () => void;
  onOrderUpdated: () => void;
  onOpenPublicTracking: (trackingCode: string) => void;
}

export const OrderDetailModal: React.FC<OrderDetailModalProps> = ({
  orderId,
  onClose,
  onOrderUpdated,
  onOpenPublicTracking,
}) => {
  const { user } = useAuth();
  const [order, setOrder] = useState<Order | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [copied, setCopied] = useState(false);
  const [transitionNote, setTransitionNote] = useState('');
  const [isUpdatingStatus, setIsUpdatingStatus] = useState(false);

  // File upload state
  const [isUploadingFile, setIsUploadingFile] = useState(false);
  const [fileName, setFileName] = useState('');
  const [fileCategory, setFileCategory] = useState<'BRIEF_KONSUMEN' | 'FILE_DESAIN' | 'BUKTI_APPROVAL' | 'FILE_CETAK'>('FILE_DESAIN');

  const isPremium = user?.tenantPlan === 'PREMIUM';

  const fetchOrder = async () => {
    if (!orderId) return;
    setIsLoading(true);
    try {
      const data = await orderApi.getOrderById(orderId);
      setOrder(data);

      // Generate QR Code if premium
      if (isPremium) {
        const trackingUrl = `${window.location.origin}/?track=${data.trackingCode}`;
        const qr = await QRCode.toDataURL(trackingUrl, {
          width: 220,
          margin: 2,
          color: {
            dark: '#1e1b4b',
            light: '#ffffff',
          },
        });
        setQrDataUrl(qr);
      }
    } catch (e: any) {
      console.error('Failed to get order', e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchOrder();
  }, [orderId]);

  if (!orderId) return null;

  // Determine Next Status in Workflow
  // Pesanan Masuk -> Verifikasi -> Desain -> Approval -> Produksi/Cetak -> Finishing + QC -> Siap Diambil/Dikirim -> Selesai
  // Shortcut rule: "Jika tidak membutuhkan desain, langsung ke Produksi."
  const getNextStatus = (current: OrderStatus, needsDesign: boolean): OrderStatus | null => {
    switch (current) {
      case 'PESANAN_MASUK':
        return 'VERIFIKASI';
      case 'VERIFIKASI':
        return needsDesign ? 'DESAIN' : 'PRODUKSI_CETAK';
      case 'DESAIN':
        return 'APPROVAL';
      case 'APPROVAL':
        return 'PRODUKSI_CETAK';
      case 'PRODUKSI_CETAK':
        return 'FINISHING_QC';
      case 'FINISHING_QC':
        return 'SIAP_DIAMBIL_DIKIRIM';
      case 'SIAP_DIAMBIL_DIKIRIM':
        return 'SELESAI';
      case 'SELESAI':
        return null;
    }
  };

  const nextStatus = order ? getNextStatus(order.status, order.needsDesign) : null;

  const handleAdvanceStatus = async () => {
    if (!order || !nextStatus) return;
    setIsUpdatingStatus(true);
    try {
      await orderApi.updateStatus(order.id, nextStatus, transitionNote.trim());
      setTransitionNote('');
      await fetchOrder();
      onOrderUpdated();
    } catch (err: any) {
      alert(err.message || 'Gagal mengubah status');
    } finally {
      setIsUpdatingStatus(false);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !order) return;

    setIsUploadingFile(true);
    try {
      if (isSupabaseConfigured()) {
        await uploadOrderFileToSupabase({
          file,
          fileName: file.name,
          tenantId: order.tenantId,
          orderId: order.id,
          category: fileCategory,
          uploadedByName: user?.name || 'Operator',
        });
        await fetchOrder();
        onOrderUpdated();
      } else {
        const reader = new FileReader();
        reader.onload = async () => {
          const base64Url = reader.result as string;
          await orderApi.attachFile(order.id, {
            name: file.name,
            url: base64Url,
            fileType: file.type || 'application/octet-stream',
            category: fileCategory,
            size: `${(file.size / (1024 * 1024)).toFixed(2)} MB`,
          });
          await fetchOrder();
          onOrderUpdated();
        };
        reader.readAsDataURL(file);
      }
    } catch (err: any) {
      alert(err.message || 'Gagal mengunggah berkas');
    } finally {
      setIsUploadingFile(false);
      e.target.value = '';
    }
  };

  const handleCopyTrackingLink = () => {
    if (!order) return;
    const url = `${window.location.origin}/?track=${order.trackingCode}`;
    navigator.clipboard.writeText(url);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSendWhatsappUpdate = () => {
    if (!order) return;
    const trackingUrl = `${window.location.origin}/?track=${order.trackingCode}`;
    const message = isPremium
      ? `Halo ${order.customerName},\n\nUpdate pesanan Anda *#${order.orderNumber}* (${order.jobType}):\nSaat ini status: *${STATUS_CONFIG[order.status].label}*.\n\nAnda dapat memantau progres pengerjaan secara langsung melalui link tracking berikut:\n${trackingUrl}\n\nTerima kasih atas kepercayaannya!`
      : `Halo ${order.customerName},\n\nUpdate pesanan Anda *#${order.orderNumber}* (${order.jobType}):\nSaat ini status telah masuk tahap: *${STATUS_CONFIG[order.status].label}*.\n\nEstimasi selesai: ${formatDate(order.deadline)}.\nTerima kasih!`;

    window.open(formatWhatsappUrl(order.customerWhatsapp, message), '_blank');
  };

  const deadlineInfo = order ? formatDeadline(order.deadline) : null;

  return (
    <div
      id="order-detail-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto"
    >
      <div className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full my-6 border border-slate-200 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-slate-200 bg-slate-50/70 flex items-start justify-between gap-3 shrink-0">
          <div className="space-y-1">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-base sm:text-lg font-black font-mono text-slate-900">
                {order?.orderNumber}
              </span>
              {order && (
                <span
                  className={`px-2.5 py-0.5 text-xs rounded-full font-bold border ${STATUS_CONFIG[order.status].bg} ${STATUS_CONFIG[order.status].color} ${STATUS_CONFIG[order.status].border}`}
                >
                  {STATUS_CONFIG[order.status].label}
                </span>
              )}
              {order?.needsDesign ? (
                <span className="px-2 py-0.5 text-[11px] font-semibold bg-purple-100 text-purple-800 rounded-md">
                  Perlu Desain
                </span>
              ) : (
                <span className="px-2 py-0.5 text-[11px] font-semibold bg-emerald-100 text-emerald-800 rounded-md">
                  ⚡ Siap Cetak (Langsung Produksi)
                </span>
              )}
            </div>
            <p className="text-xs text-slate-500">
              Didaftarkan pada: {order ? formatDate(order.createdAt) : '-'} • PIC: {order?.pic || '-'}
            </p>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-200 rounded-lg transition-colors shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        {isLoading || !order ? (
          <div className="p-12 text-center text-slate-400">Memuat rincian pesanan...</div>
        ) : (
          <div className="p-4 sm:p-6 overflow-y-auto space-y-6">
            {/* WORKFLOW PROGRESS TRACKER */}
            <div className="bg-slate-50/90 border border-slate-200 rounded-2xl p-4">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                  <Layers className="w-4 h-4 text-indigo-600" />
                  Alur Proses Produksi
                </h3>
                {deadlineInfo && (
                  <span
                    className={`text-xs font-semibold px-2 py-0.5 rounded-md flex items-center gap-1 ${
                      deadlineInfo.isOverdue
                        ? 'bg-rose-100 text-rose-800'
                        : deadlineInfo.isUrgent
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-slate-100 text-slate-700'
                    }`}
                  >
                    <Clock className="w-3 h-3" />
                    Deadline: {deadlineInfo.text}
                  </span>
                )}
              </div>

              <WorkflowProgressBar
                currentStatus={order.status}
                needsDesign={order.needsDesign}
              />

              {/* ACTION: ADVANCE TO NEXT STEP */}
              {nextStatus ? (
                <div className="mt-4 pt-3 border-t border-slate-200/80 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-white p-3 rounded-xl border">
                  <div className="flex-1">
                    <p className="text-xs text-slate-500 font-medium">Langkah Berikutnya:</p>
                    <p className="text-sm font-bold text-indigo-900 flex items-center gap-1">
                      {STATUS_CONFIG[nextStatus].label}
                      <ArrowRight className="w-4 h-4 text-indigo-500" />
                    </p>
                    {!order.needsDesign && order.status === 'VERIFIKASI' && (
                      <p className="text-[11px] text-emerald-700 font-medium mt-0.5">
                        *File siap cetak: Langsung menuju Produksi/Cetak (melewati Desain & Approval).
                      </p>
                    )}
                  </div>

                  <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                    <input
                      type="text"
                      placeholder="Catatan pengerjaan (opsional)..."
                      value={transitionNote}
                      onChange={e => setTransitionNote(e.target.value)}
                      className="px-3 py-1.5 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500 w-full sm:w-60"
                    />
                    <button
                      id="advance-status-btn"
                      disabled={isUpdatingStatus}
                      onClick={handleAdvanceStatus}
                      className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center justify-center gap-1.5 shrink-0 cursor-pointer"
                    >
                      {isUpdatingStatus ? 'Memproses...' : `Lanjutkan ke ${STATUS_CONFIG[nextStatus].label}`}
                    </button>
                  </div>
                </div>
              ) : (
                <div className="mt-3 p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs font-bold text-emerald-800 flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-600" />
                  Pesanan telah SELESAI seluruh tahapan pengerjaan.
                </div>
              )}
            </div>

            {/* TWO COLUMNS: SPECS & CLIENT TRACKING */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* LEFT: JOB SPECIFICATIONS */}
              <div className="lg:col-span-7 space-y-4">
                <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs">
                  <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-3">
                    Spesifikasi Order
                  </h3>

                  <div className="grid grid-cols-2 gap-3 text-xs">
                    <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                      <span className="text-slate-400 block text-[10px]">Jenis Pekerjaan</span>
                      <span className="font-bold text-slate-900 text-sm">{order.jobType}</span>
                    </div>

                    <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                      <span className="text-slate-400 block text-[10px]">Jumlah & Satuan</span>
                      <span className="font-bold text-slate-900 text-sm">
                        {order.quantity.toLocaleString('id-ID')} {order.unit}
                      </span>
                    </div>

                    <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                      <span className="text-slate-400 block text-[10px]">Ukuran</span>
                      <span className="font-semibold text-slate-800">{order.size}</span>
                    </div>

                    <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                      <span className="text-slate-400 block text-[10px]">Bahan / Material</span>
                      <span className="font-semibold text-slate-800">{order.material}</span>
                    </div>

                    <div className="col-span-2 bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                      <span className="text-slate-400 block text-[10px]">Finishing</span>
                      <span className="font-semibold text-slate-800">{order.finishing}</span>
                    </div>

                    <div className="col-span-2 bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                      <span className="text-slate-400 block text-[10px]">Catatan Khusus</span>
                      <span className="text-slate-700 italic">{order.notes || 'Tidak ada catatan tambahan'}</span>
                    </div>
                  </div>
                </div>

                {/* CUSTOMER INFO */}
                <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs">
                  <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-2">
                    Informasi Konsumen
                  </h3>
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                      <p className="text-sm font-bold text-slate-900">{order.customerName}</p>
                      <p className="text-xs text-slate-500 font-mono mt-0.5">
                        WA: {order.customerWhatsapp || '-'}
                      </p>
                    </div>

                    {order.customerWhatsapp && (
                      <button
                        onClick={handleSendWhatsappUpdate}
                        className="inline-flex items-center gap-1.5 px-3 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer shadow-2xs"
                      >
                        <MessageCircle className="w-4 h-4" />
                        Chat & Kirim Update WA
                      </button>
                    )}
                  </div>
                </div>
              </div>

              {/* RIGHT: CLIENT TRACKING & QR CODE (PREMIUM ONLY) */}
              <div className="lg:col-span-5 space-y-4">
                <div
                  className={`rounded-2xl p-5 border ${
                    isPremium
                      ? 'bg-emerald-50/50 border-emerald-200'
                      : 'bg-amber-50/50 border-amber-200'
                  }`}
                >
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-1.5">
                      <QrCode
                        className={`w-4 h-4 ${
                          isPremium ? 'text-emerald-700' : 'text-amber-700'
                        }`}
                      />
                      <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900">
                        Client Tracking
                      </h3>
                    </div>

                    {isPremium ? (
                      <span className="px-2 py-0.5 text-[10px] font-bold bg-emerald-600 text-white rounded-md">
                        PREMIUM ON
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 text-[10px] font-bold bg-amber-600 text-white rounded-md">
                        BASIC OFF
                      </span>
                    )}
                  </div>

                  {isPremium ? (
                    <div className="space-y-4">
                      <p className="text-xs text-slate-600">
                        Konsumen dapat memantau status pesanan secara real-time via QR Code atau link tanpa perlu login.
                      </p>

                      {/* QR Code Display */}
                      {qrDataUrl && (
                        <div className="flex flex-col items-center justify-center p-3 bg-white rounded-xl border border-emerald-100 shadow-2xs">
                          <img
                            src={qrDataUrl}
                            alt="QR Code Tracking"
                            className="w-36 h-36 rounded-lg"
                          />
                          <span className="text-[10px] font-mono text-slate-400 mt-1">
                            Kode: {order.trackingCode}
                          </span>
                        </div>
                      )}

                      <div className="space-y-2">
                        <button
                          onClick={handleCopyTrackingLink}
                          className="w-full flex items-center justify-center gap-1.5 px-3 py-2 bg-white hover:bg-emerald-50 border border-emerald-300 text-emerald-900 rounded-xl text-xs font-bold transition-colors cursor-pointer"
                        >
                          {copied ? (
                            <>
                              <Check className="w-3.5 h-3.5 text-emerald-600" />
                              Tautan Berhasil Disalin!
                            </>
                          ) : (
                            <>
                              <Copy className="w-3.5 h-3.5 text-emerald-600" />
                              Salin Tautan Tracking Konsumen
                            </>
                          )}
                        </button>

                        <button
                          onClick={() => onOpenPublicTracking(order.trackingCode)}
                          className="w-full flex items-center justify-center gap-1.5 px-3 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer shadow-2xs"
                        >
                          <ExternalLink className="w-3.5 h-3.5" />
                          Buka Tampilan Pelanggan
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      <div className="p-3 bg-white rounded-xl border border-amber-200 text-xs text-amber-900 space-y-1.5">
                        <div className="flex items-center gap-1.5 font-bold text-amber-800">
                          <Lock className="w-4 h-4 text-amber-600 shrink-0" />
                          Fitur Tidak Aktif (Paket BASIC)
                        </div>
                        <p className="text-[11px] text-slate-600">
                          Bisnis Anda saat ini menggunakan paket <strong>BASIC (Rp150.000)</strong>. Fitur Client Tracking melalui link publik dan QR Code hanya aktif untuk paket <strong>PREMIUM (Rp300.000)</strong>.
                        </p>
                      </div>

                      <button
                        onClick={() => onOpenPublicTracking(order.trackingCode)}
                        className="w-full py-2 px-3 text-xs font-medium text-slate-600 hover:text-slate-900 border border-slate-300 rounded-xl bg-white text-center hover:bg-slate-50 transition-colors cursor-pointer"
                      >
                        Lihat Respons Tracking Paket Basic &rarr;
                      </button>
                    </div>
                  )}
                </div>

                {/* UPLOAD ATTACHMENT */}
                <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1">
                      <FileText className="w-4 h-4 text-indigo-600" />
                      Berkas & Desain ({order.files.length})
                    </h3>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <select
                        value={fileCategory}
                        onChange={e => setFileCategory(e.target.value as any)}
                        className="text-xs border border-slate-300 rounded-lg px-2 py-1.5 bg-white"
                      >
                        <option value="FILE_DESAIN">File Desain (Mockup)</option>
                        <option value="FILE_CETAK">File Siap Cetak</option>
                        <option value="BUKTI_APPROVAL">Bukti Approval</option>
                        <option value="BRIEF_KONSUMEN">Brief Konsumen</option>
                      </select>

                      <label className="flex-1 flex items-center justify-center gap-1 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs rounded-lg cursor-pointer transition-colors border border-slate-200">
                        <Upload className="w-3.5 h-3.5" />
                        <span>{isUploadingFile ? 'Mengunggah...' : 'Upload File'}</span>
                        <input
                          type="file"
                          onChange={handleFileUpload}
                          disabled={isUploadingFile}
                          className="hidden"
                        />
                      </label>
                    </div>

                    {/* Files List */}
                    <div className="divide-y divide-slate-100 max-h-40 overflow-y-auto">
                      {order.files.length === 0 ? (
                        <p className="text-[11px] text-slate-400 text-center py-3">
                          Belum ada berkas terlampir.
                        </p>
                      ) : (
                        order.files.map(f => (
                          <div
                            key={f.id}
                            className="py-2 flex items-center justify-between text-xs gap-2"
                          >
                            <div className="min-w-0">
                              <p className="font-semibold text-slate-800 truncate">{f.name}</p>
                              <span className="text-[10px] text-slate-400">
                                {f.category} • {f.size} • oleh {f.uploadedBy}
                              </span>
                            </div>
                            <a
                              href={f.url}
                              target="_blank"
                              rel="noreferrer"
                              className="text-indigo-600 hover:text-indigo-800 text-xs font-semibold shrink-0"
                            >
                              Lihat
                            </a>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* TIMELINE AUDIT HISTORY */}
            <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-5 shadow-2xs">
              <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-4 flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-slate-500" />
                Histori & Log Timeline Proses
              </h3>

              <div className="space-y-4 relative before:absolute before:left-3.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-200">
                {order.timeline.map((event, idx) => {
                  const cfg = STATUS_CONFIG[event.status];
                  return (
                    <div key={event.id || idx} className="flex items-start gap-3 relative z-10">
                      <div
                        className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 border-2 bg-white ${
                          cfg ? cfg.border : 'border-slate-300'
                        }`}
                      >
                        <div
                          className={`w-2.5 h-2.5 rounded-full ${
                            cfg ? cfg.bg.replace('bg-', 'bg-indigo-') : 'bg-slate-400'
                          }`}
                        />
                      </div>
                      <div className="flex-1 bg-slate-50 rounded-xl p-3 border border-slate-100">
                        <div className="flex flex-wrap items-center justify-between gap-1">
                          <span className="font-bold text-xs text-slate-900">{event.title}</span>
                          <span className="text-[10px] text-slate-400 font-mono">
                            {formatDate(event.timestamp)}
                          </span>
                        </div>
                        {event.note && (
                          <p className="text-xs text-slate-600 mt-1">{event.note}</p>
                        )}
                        <p className="text-[10px] text-slate-400 mt-1 font-medium">
                          Pelaksana: <span className="text-slate-600">{event.actorName}</span> ({event.actorRole})
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* Modal Footer */}
        <div className="p-3 bg-slate-50 border-t border-slate-200 flex justify-end shrink-0">
          <button
            onClick={onClose}
            className="px-5 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-200 rounded-xl transition-colors cursor-pointer"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
