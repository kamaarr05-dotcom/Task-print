import { createClient, SupabaseClient, RealtimeChannel } from '@supabase/supabase-js';
import {
  Tenant,
  User,
  Order,
  OrderStatus,
  OrderFile,
  OrderTimelineEvent,
  TenantPlan,
  Role,
  OrderTrackingInfo,
} from '../types.js';

// Environment variables requested:
// VITE_SUPABASE_URL
// VITE_SUPABASE_PUBLISHABLE_KEY (also supports VITE_SUPABASE_ANON_KEY)
const metaEnv = (import.meta as unknown as { env?: Record<string, string> }).env || {};
const envUrl = metaEnv.VITE_SUPABASE_URL || '';
const envKey = metaEnv.VITE_SUPABASE_PUBLISHABLE_KEY || metaEnv.VITE_SUPABASE_ANON_KEY || '';

export const isSupabaseConfigured = (): boolean => {
  return Boolean(
    envUrl &&
      envKey &&
      envUrl.startsWith('http') &&
      !envUrl.includes('placeholder') &&
      !envKey.includes('placeholder')
  );
};

// Create Supabase client singleton
export const supabase: SupabaseClient = createClient(
  envUrl || 'https://placeholder.supabase.co',
  envKey || 'placeholder-anon-key',
  {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
      detectSessionInUrl: true,
    },
    realtime: {
      params: {
        eventsPerSecond: 10,
      },
    },
  }
);

// Bucket name for order files and QC photos
export const STORAGE_BUCKET = 'orders-storage';

// ==============================================================================
// STORAGE SERVICE
// ==============================================================================
export interface UploadFileOptions {
  file: File | Blob;
  fileName: string;
  tenantId: string;
  orderId: string;
  category: 'BRIEF_KONSUMEN' | 'FILE_DESAIN' | 'BUKTI_APPROVAL' | 'FILE_CETAK' | 'FOTO_QC';
  uploadedByName: string;
}

export async function uploadOrderFileToSupabase(options: UploadFileOptions): Promise<OrderFile> {
  if (!isSupabaseConfigured()) {
    throw new Error('Supabase belum dikonfigurasi. Mohon isi VITE_SUPABASE_URL & VITE_SUPABASE_PUBLISHABLE_KEY.');
  }

  const { file, fileName, tenantId, orderId, category, uploadedByName } = options;
  const cleanFileName = fileName.replace(/[^a-zA-Z0-9._-]/g, '_');
  const filePath = `${tenantId}/${orderId}/${category.toLowerCase()}_${Date.now()}_${cleanFileName}`;

  const { data, error } = await supabase.storage
    .from(STORAGE_BUCKET)
    .upload(filePath, file, {
      cacheControl: '3600',
      upsert: false,
    });

  if (error) {
    console.error('Supabase storage upload error:', error);
    throw new Error(`Gagal mengunggah file ke Supabase Storage: ${error.message}`);
  }

  const { data: publicUrlData } = supabase.storage
    .from(STORAGE_BUCKET)
    .getPublicUrl(data.path);

  const fileBytes = file.size || 1024 * 1024;
  const sizeFormatted = fileBytes > 1024 * 1024
    ? `${(fileBytes / (1024 * 1024)).toFixed(1)} MB`
    : `${(fileBytes / 1024).toFixed(0)} KB`;

  // Insert record into order_files table
  const { data: fileRecord, error: dbError } = await supabase
    .from('order_files')
    .insert({
      order_id: orderId,
      tenant_id: tenantId,
      name: fileName,
      file_type: file.type || 'application/octet-stream',
      category,
      url: publicUrlData.publicUrl,
      storage_path: data.path,
      size: sizeFormatted,
      uploaded_by: uploadedByName,
    })
    .select()
    .single();

  if (dbError) {
    console.error('Failed to record order file in database:', dbError);
  }

  return {
    id: fileRecord?.id || `file-${Date.now()}`,
    name: fileName,
    fileType: file.type || 'application/octet-stream',
    category,
    url: publicUrlData.publicUrl,
    size: sizeFormatted,
    uploadedBy: uploadedByName,
    uploadedAt: fileRecord?.created_at || new Date().toISOString(),
  };
}

// ==============================================================================
// REALTIME SUBSCRIPTION SERVICE
// ==============================================================================
export function subscribeToTenantOrdersRealtime(
  tenantId: string,
  onOrderChange: (payload: any) => void
): RealtimeChannel | null {
  if (!isSupabaseConfigured()) return null;

  const channelName = `tenant-orders-${tenantId}-${Date.now()}`;
  const channel = supabase
    .channel(channelName)
    .on(
      'postgres_changes',
      {
        event: '*',
        schema: 'public',
        table: 'orders',
        filter: `tenant_id=eq.${tenantId}`,
      },
      payload => {
        onOrderChange(payload);
      }
    )
    .subscribe();

  return channel;
}

// ==============================================================================
// SUPABASE CLIENT-SIDE DATA ACCESS WITH RLS
// ==============================================================================
export const supabaseDb = {
  // Fetch tenant profile for current user
  getTenant: async (tenantId: string): Promise<Tenant | null> => {
    const { data, error } = await supabase
      .from('tenants')
      .select('*')
      .eq('id', tenantId)
      .single();

    if (error || !data) return null;
    return {
      id: data.id,
      name: data.name,
      code: data.code,
      plan: data.plan as TenantPlan,
      trackingEnabled: data.tracking_enabled,
      phone: data.phone || '',
      address: data.address || '',
      status: data.status,
      createdAt: data.created_at,
    };
  },

  // Master: Fetch all tenants
  getAllTenants: async (): Promise<Array<Tenant & { orderCount: number; userCount: number }>> => {
    const { data: tenants, error: tErr } = await supabase
      .from('tenants')
      .select('*')
      .order('created_at', { ascending: false });

    if (tErr) throw new Error(tErr.message);

    // Get counts
    const results: Array<Tenant & { orderCount: number; userCount: number }> = [];
    for (const t of tenants || []) {
      const { count: orderCount } = await supabase
        .from('orders')
        .select('*', { count: 'exact', head: true })
        .eq('tenant_id', t.id);

      const { count: userCount } = await supabase
        .from('profiles')
        .select('*', { count: 'exact', head: true })
        .eq('tenant_id', t.id);

      results.push({
        id: t.id,
        name: t.name,
        code: t.code,
        plan: t.plan as TenantPlan,
        trackingEnabled: t.tracking_enabled,
        phone: t.phone || '',
        address: t.address || '',
        status: t.status,
        createdAt: t.created_at,
        orderCount: orderCount || 0,
        userCount: userCount || 0,
      });
    }

    return results;
  },

  // Fetch orders for tenant (Row Level Security applies automatically)
  getOrders: async (tenantId: string): Promise<Order[]> => {
    const { data: ordersData, error } = await supabase
      .from('orders')
      .select(`
        *,
        order_files (*),
        order_timeline (*)
      `)
      .eq('tenant_id', tenantId)
      .order('created_at', { ascending: false });

    if (error) throw new Error(error.message);

    return (ordersData || []).map(o => ({
      id: o.id,
      tenantId: o.tenant_id,
      orderNumber: o.order_number,
      trackingCode: o.tracking_code,
      customerName: o.customer_name,
      customerWhatsapp: o.customer_whatsapp,
      jobType: o.job_type,
      size: o.size,
      material: o.material,
      quantity: o.quantity,
      unit: o.unit,
      finishing: o.finishing || '',
      deadline: o.deadline,
      notes: o.notes || '',
      needsDesign: o.needs_design,
      pic: o.pic || '',
      status: o.status as OrderStatus,
      files: (o.order_files || []).map((f: any) => ({
        id: f.id,
        name: f.name,
        fileType: f.file_type,
        category: f.category,
        url: f.url,
        size: f.size,
        uploadedBy: f.uploaded_by,
        uploadedAt: f.created_at,
      })),
      timeline: (o.order_timeline || [])
        .sort((a: any, b: any) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime())
        .map((t: any) => ({
          id: t.id,
          status: t.status as OrderStatus,
          title: t.title,
          note: t.note || '',
          actorName: t.actor_name,
          actorRole: t.actor_role,
          timestamp: t.created_at,
        })),
      createdAt: o.created_at,
      updatedAt: o.updated_at,
    }));
  },

  // Update order status & append to timeline
  updateOrderStatus: async (
    orderId: string,
    tenantId: string,
    nextStatus: OrderStatus,
    note: string,
    actorName: string,
    actorRole: string
  ): Promise<void> => {
    const { error: orderError } = await supabase
      .from('orders')
      .update({
        status: nextStatus,
        updated_at: new Date().toISOString(),
      })
      .eq('id', orderId)
      .eq('tenant_id', tenantId);

    if (orderError) throw new Error(orderError.message);

    const titleMap: Record<OrderStatus, string> = {
      PESANAN_MASUK: 'Pesanan Masuk & Dicatat',
      VERIFIKASI: 'Verifikasi Spesifikasi Teknis',
      DESAIN: 'Proses Pengerjaan Desain',
      APPROVAL: 'Menunggu Approval Konsumen',
      PRODUKSI_CETAK: 'Proses Produksi / Cetak Mesin',
      FINISHING_QC: 'Tahap Finishing & Uji QC',
      SIAP_DIAMBIL_DIKIRIM: 'Pesanan Siap Diambil / Dikirim',
      SELESAI: 'Pesanan Selesai Diterima Konsumen',
    };

    const { error: tlError } = await supabase.from('order_timeline').insert({
      order_id: orderId,
      tenant_id: tenantId,
      status: nextStatus,
      title: titleMap[nextStatus] || nextStatus,
      note: note || `Status diperbarui menjadi ${titleMap[nextStatus]}`,
      actor_name: actorName,
      actor_role: actorRole,
    });

    if (tlError) {
      console.warn('Could not record order timeline:', tlError);
    }
  },

  // Public Client Tracking: Validates that tenant is on PREMIUM plan with tracking enabled
  getPublicTracking: async (code: string): Promise<OrderTrackingInfo> => {
    const { data: order, error } = await supabase
      .from('orders')
      .select(`
        *,
        tenants (*),
        order_timeline (*)
      `)
      .or(`tracking_code.eq.${code},order_number.eq.${code}`)
      .single();

    if (error || !order) {
      const err = new Error('Nomor order atau kode tracking tidak ditemukan.');
      (err as any).code = 'ORDER_NOT_FOUND';
      throw err;
    }

    const tenant = order.tenants;
    if (!tenant) {
      const err = new Error('Tenant tidak ditemukan.');
      throw err;
    }

    // CHECK PLAN: BASIC vs PREMIUM
    if (tenant.plan !== 'PREMIUM' || !tenant.tracking_enabled) {
      const err = new Error(
        'Bisnis percetakan ini menggunakan paket BASIC (Rp150.000). Fitur Client Tracking dan QR Code hanya aktif untuk paket PREMIUM (Rp300.000).'
      );
      (err as any).code = 'TRACKING_DISABLED';
      (err as any).plan = tenant.plan;
      (err as any).tenantName = tenant.name;
      throw err;
    }

    return {
      orderNumber: order.order_number,
      trackingCode: order.tracking_code,
      tenantName: tenant.name,
      tenantPhone: tenant.phone || '',
      tenantAddress: tenant.address || '',
      customerName: order.customer_name,
      jobType: order.job_type,
      size: order.size,
      material: order.material,
      quantity: order.quantity,
      unit: order.unit,
      finishing: order.finishing || '',
      deadline: order.deadline,
      status: order.status as OrderStatus,
      needsDesign: order.needs_design,
      timeline: (order.order_timeline || [])
        .sort((a: any, b: any) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime())
        .map((t: any) => ({
          id: t.id,
          status: t.status as OrderStatus,
          title: t.title,
          note: t.note || '',
          actorName: t.actor_name,
          actorRole: t.actor_role,
          timestamp: t.created_at,
        })),
      updatedAt: order.updated_at,
    };
  },
};
