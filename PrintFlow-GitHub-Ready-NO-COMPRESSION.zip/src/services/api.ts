import {
  Tenant,
  User,
  Order,
  OrderStatus,
  OrderTrackingInfo,
  MasterStats,
  TenantPlan,
  Role,
} from '../types.js';

const API_BASE = '/api';

function getAuthHeader(): Record<string, string> {
  const token = localStorage.getItem('alurcetak_token');
  if (!token) return {};
  return { Authorization: `Bearer ${token}` };
}

export async function request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const headers = {
    'Content-Type': 'application/json',
    ...getAuthHeader(),
    ...(options.headers || {}),
  };

  const res = await fetch(`${API_BASE}${endpoint}`, {
    ...options,
    headers,
  });

  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error || data.message || 'Terjadi kesalahan pada server');
  }

  return data as T;
}

export interface AITaskPrintOrder {
  id: string; orderNumber: string; customerName: string; jobType: string; size: string; material: string;
  quantity: number; unit: string; deadline: string; pic: string; status: string; statusLabel: string;
  nextStep: string; needsDesign: boolean; notes: string; approvalInfo?: string;
}
export interface AITaskPrintResponse {
  answer: string; orders: AITaskPrintOrder[]; dataUpdatedAt: string; source: 'supabase' | 'demo'; tenantId: string;
}
export const aiTaskPrintApi = {
  ask: async (payload: { question: string; filters?: { customer?: string; orderNumber?: string; pic?: string; status?: string; deadline?: 'TODAY' | 'TOMORROW' | 'OVERDUE'; } }) =>
    request<AITaskPrintResponse>('/ai/task-print', { method: 'POST', body: JSON.stringify(payload) }),
};

// Authentication
export const authApi = {
  login: async (username: string, password: string) => {
    return request<{ token: string; user: User }>('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ username, password }),
    });
  },
  getMe: async () => {
    return request<User & { tenant?: Tenant | null }>('/auth/me');
  },
  getDemoUsers: async () => {
    return request<
      Array<{
        id: string;
        username: string;
        name: string;
        role: Role;
        tenantId: string | null;
        tenantName: string;
        tenantPlan?: TenantPlan;
      }>
    >('/auth/demo-users');
  },
};

// Master Platform
export const masterApi = {
  getSetupStatus: async () => {
    return request<{
      isConfigured: boolean;
      email: string;
      name: string;
      username: string;
    }>('/master/setup-status');
  },
  setupPassword: async (payload: {
    email: string;
    password: string;
    currentPassword?: string;
  }) => {
    return request<{ success: boolean; message: string }>('/master/setup-password', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },
  getTenants: async () => {
    return request<Array<Tenant & { orderCount: number; userCount: number }>>('/master/tenants');
  },
  getStats: async () => {
    return request<MasterStats>('/master/stats');
  },
  createTenant: async (payload: {
    name: string;
    code?: string;
    plan: TenantPlan;
    phone?: string;
    address?: string;
    adminName: string;
    adminUsername: string;
    adminPassword: string;
    adminPhone?: string;
  }) => {
    return request<{ tenant: Tenant; admin: User }>('/master/tenants', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },
  updateTenant: async (
    id: string,
    payload: {
      name?: string;
      code?: string;
      plan?: TenantPlan;
      status?: 'ACTIVE' | 'SUSPENDED';
      phone?: string;
      address?: string;
    }
  ) => {
    return request<Tenant>(`/master/tenants/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },
};

// Tenant Staff / User Management (Admin)
export const userApi = {
  getUsers: async (tenantId?: string) => {
    const q = tenantId ? `?tenantId=${tenantId}` : '';
    return request<User[]>(`/users${q}`);
  },
  createUser: async (payload: {
    username: string;
    password: string;
    name: string;
    role: Role;
    phone?: string;
    tenantId?: string;
  }) => {
    return request<User>('/users', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },
  deleteUser: async (id: string) => {
    return request<{ message: string }>(`/users/${id}`, {
      method: 'DELETE',
    });
  },
};

// Order Management
export const orderApi = {
  getOrders: async (tenantId?: string) => {
    const q = tenantId ? `?tenantId=${tenantId}` : '';
    return request<Order[]>(`/orders${q}`);
  },
  getOrderById: async (id: string) => {
    return request<Order>(`/orders/${id}`);
  },
  createOrder: async (payload: {
    customerName: string;
    customerWhatsapp?: string;
    jobType: string;
    size?: string;
    material?: string;
    quantity: number;
    unit?: string;
    finishing?: string;
    deadline?: string;
    notes?: string;
    needsDesign: boolean;
    pic?: string;
    initialFile?: {
      name: string;
      url: string;
      fileType: string;
      category: string;
      size: string;
    };
  }) => {
    return request<Order>('/orders', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },
  updateStatus: async (id: string, nextStatus: OrderStatus, note?: string) => {
    return request<Order>(`/orders/${id}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ nextStatus, note }),
    });
  },
  attachFile: async (
    id: string,
    file: {
      name: string;
      url: string;
      fileType: string;
      category: string;
      size: string;
    }
  ) => {
    return request<Order>(`/orders/${id}/files`, {
      method: 'POST',
      body: JSON.stringify(file),
    });
  },
  deleteOrder: async (id: string) => {
    return request<{ message: string }>(`/orders/${id}`, {
      method: 'DELETE',
    });
  },
};

// Public Client Tracking (No Login)
export const trackingApi = {
  getTracking: async (code: string) => {
    const res = await fetch(`${API_BASE}/tracking/${encodeURIComponent(code)}`);
    const data = await res.json();
    if (!res.ok) {
      const err = new Error(data.message || 'Tracking gagal');
      (err as any).code = data.error;
      (err as any).plan = data.plan;
      (err as any).tenantName = data.tenantName;
      throw err;
    }
    return data as OrderTrackingInfo;
  },
};
