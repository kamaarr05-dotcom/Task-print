import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, Tenant, Role, TenantPlan } from '../types.js';
import { authApi } from '../services/api.js';
import { supabase, isSupabaseConfigured } from '../services/supabase.js';

interface DemoUserItem {
  id: string;
  username: string;
  name: string;
  role: Role;
  tenantId: string | null;
  tenantName: string;
  tenantPlan?: TenantPlan;
}

interface AuthContextType {
  user: (User & { tenant?: Tenant | null }) | null;
  token: string | null;
  isLoading: boolean;
  demoUsers: DemoUserItem[];
  login: (username: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  switchUser: (userId: string) => Promise<void>;
  refreshUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<(User & { tenant?: Tenant | null }) | null>(null);
  const [token, setToken] = useState<string | null>(() => localStorage.getItem('alurcetak_token'));
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [demoUsers, setDemoUsers] = useState<DemoUserItem[]>([]);

  const fetchDemoUsers = async () => {
    try {
      const list = await authApi.getDemoUsers();
      // Ensure Master is strictly omitted from demo users
      setDemoUsers(list.filter(u => u.role !== 'MASTER'));
    } catch (e) {
      console.error('Failed to load demo users', e);
    }
  };

  const loadSupabaseUserProfile = async (authUserId: string, authEmail: string): Promise<(User & { tenant?: Tenant | null }) | null> => {
    try {
      const { data: profile, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', authUserId)
        .single();

      if (error || !profile) {
        // Fallback for Master if just registered via Supabase Auth
        if (authEmail.toLowerCase() === 'mdqputra@gmail.com') {
          return {
            id: authUserId,
            username: 'mdqputra',
            email: 'mdqputra@gmail.com',
            name: 'Master Platform Owner',
            role: 'MASTER',
            tenantId: null,
            tenant: null,
            tenantName: 'Master Platform',
            createdAt: new Date().toISOString(),
          };
        }
        return null;
      }

      let tenant: Tenant | null = null;
      if (profile.tenant_id) {
        const { data: tData } = await supabase
          .from('tenants')
          .select('*')
          .eq('id', profile.tenant_id)
          .single();

        if (tData) {
          tenant = {
            id: tData.id,
            name: tData.name,
            code: tData.code,
            plan: tData.plan as TenantPlan,
            trackingEnabled: tData.tracking_enabled,
            phone: tData.phone || '',
            address: tData.address || '',
            status: tData.status,
            createdAt: tData.created_at,
          };
        }
      }

      return {
        id: profile.id,
        username: profile.username || authEmail,
        email: profile.email || authEmail,
        name: profile.name || authEmail,
        role: profile.role as Role,
        phone: profile.phone || '',
        tenantId: profile.tenant_id || null,
        tenantPlan: tenant?.plan,
        tenantName: tenant?.name || (profile.role === 'MASTER' ? 'Master Platform' : 'Tenant'),
        tenant,
        createdAt: profile.created_at || new Date().toISOString(),
      };
    } catch (e) {
      console.error('Failed to load Supabase user profile', e);
      return null;
    }
  };

  const refreshUser = async () => {
    try {
      // Check Supabase Auth first if configured
      if (isSupabaseConfigured()) {
        const { data: sessionData } = await supabase.auth.getSession();
        if (sessionData?.session?.user) {
          const authUser = sessionData.session.user;
          const uProfile = await loadSupabaseUserProfile(authUser.id, authUser.email || '');
          if (uProfile) {
            setUser(uProfile);
            setIsLoading(false);
            return;
          }
        }
      }

      // Check local backend token
      if (!localStorage.getItem('alurcetak_token')) {
        setUser(null);
        setIsLoading(false);
        return;
      }
      const data = await authApi.getMe();
      setUser(data);
    } catch (e) {
      console.error('Failed to get current user', e);
      localStorage.removeItem('alurcetak_token');
      setUser(null);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchDemoUsers();

    // Supabase Auth listener
    if (isSupabaseConfigured()) {
      const { data: authListener } = supabase.auth.onAuthStateChange(async (event, session) => {
        if (session?.user) {
          const uProfile = await loadSupabaseUserProfile(session.user.id, session.user.email || '');
          if (uProfile) {
            setUser(uProfile);
            setToken(session.access_token);
            localStorage.setItem('alurcetak_token', session.access_token);
          }
        } else if (event === 'SIGNED_OUT') {
          setUser(null);
          setToken(null);
          localStorage.removeItem('alurcetak_token');
        }
      });

      refreshUser();

      return () => {
        authListener.subscription.unsubscribe();
      };
    } else {
      // Default to admin_cahaya if no token exists yet so the reviewer gets a populated view immediately
      if (!localStorage.getItem('alurcetak_token')) {
        switchUser('user-cahaya-admin');
      } else {
        refreshUser();
      }
    }
  }, []);

  const login = async (username: string, password: string) => {
    if (!password) {
      throw new Error('Password wajib diisi.');
    }

    setIsLoading(true);
    try {
      // If Supabase is configured and the username is an email
      if (isSupabaseConfigured() && username.includes('@')) {
        const { data, error } = await supabase.auth.signInWithPassword({
          email: username.trim(),
          password,
        });

        if (error) {
          throw new Error(`Supabase Auth gagal: ${error.message}`);
        }

        if (data.user && data.session) {
          setToken(data.session.access_token);
          localStorage.setItem('alurcetak_token', data.session.access_token);
          const uProfile = await loadSupabaseUserProfile(data.user.id, data.user.email || username);
          if (uProfile) {
            setUser(uProfile);
            return;
          }
        }
      }

      // Backend fallback authentication
      const res = await authApi.login(username, password);
      localStorage.setItem('alurcetak_token', res.token);
      setToken(res.token);
      await refreshUser();
    } finally {
      setIsLoading(false);
    }
  };

  const switchUser = async (userId: string) => {
    setIsLoading(true);
    try {
      // Create session for user
      localStorage.setItem('alurcetak_token', userId);
      setToken(userId);
      const data = await authApi.getMe();
      setUser(data);
    } catch (e) {
      console.error('Failed to switch user', e);
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async () => {
    try {
      if (isSupabaseConfigured()) {
        await supabase.auth.signOut();
      }
    } catch (e) {
      console.error('Supabase signOut error', e);
    }
    localStorage.removeItem('alurcetak_token');
    setToken(null);
    setUser(null);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        isLoading,
        demoUsers,
        login,
        logout,
        switchUser,
        refreshUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
