export type Role = 'MASTER' | 'ADMIN' | 'DESAINER' | 'OPERATOR_CETAK' | 'FINISHING_QC';

export type TenantPlan = 'BASIC' | 'PREMIUM';

export type OrderStatus =
  | 'PESANAN_MASUK'
  | 'VERIFIKASI'
  | 'DESAIN'
  | 'APPROVAL'
  | 'PRODUKSI_CETAK'
  | 'FINISHING_QC'
  | 'SIAP_DIAMBIL_DIKIRIM'
  | 'SELESAI';

export interface Tenant {
  id: string;
  name: string;
  code: string; // e.g. "CHP" or "PRM" for order prefixes
  plan: TenantPlan; // BASIC: 150000, PREMIUM: 300000
  trackingEnabled: boolean;
  phone: string;
  address: string;
  status: 'ACTIVE' | 'SUSPENDED';
  createdAt: string;
}

export interface User {
  id: string;
  tenantId: string | null; // null for MASTER
  tenantName?: string;
  tenantPlan?: TenantPlan;
  username: string;
  email?: string;
  name: string;
  role: Role;
  phone?: string;
  createdAt: string;
  isConfigured?: boolean;
}

export interface OrderFile {
  id: string;
  name: string;
  fileType: string;
  category: 'BRIEF_KONSUMEN' | 'FILE_DESAIN' | 'BUKTI_APPROVAL' | 'FILE_CETAK' | 'FOTO_QC';
  url: string;
  size: string;
  uploadedBy: string;
  uploadedAt: string;
}

export interface OrderTimelineEvent {
  id: string;
  status: OrderStatus;
  title: string;
  note?: string;
  actorName: string;
  actorRole: string;
  timestamp: string;
}

export interface Order {
  id: string;
  tenantId: string; // Strictly isolated
  orderNumber: string;
  trackingCode: string; // Public tracking unguessable token
  customerName: string;
  customerWhatsapp: string;
  jobType: string;
  size: string;
  material: string;
  quantity: number;
  unit: string;
  finishing: string;
  deadline: string; // ISO string
  notes: string;
  needsDesign: boolean;
  pic: string;
  status: OrderStatus;
  files: OrderFile[];
  timeline: OrderTimelineEvent[];
  createdAt: string;
  updatedAt: string;
}

export interface OrderTrackingInfo {
  orderNumber: string;
  trackingCode: string;
  tenantName: string;
  tenantPhone: string;
  tenantAddress: string;
  customerName: string;
  jobType: string;
  size: string;
  material: string;
  quantity: number;
  unit: string;
  finishing: string;
  deadline: string;
  status: OrderStatus;
  needsDesign: boolean;
  timeline: OrderTimelineEvent[];
  updatedAt: string;
}

export interface MasterStats {
  totalTenants: number;
  activeTenants: number;
  basicTenantsCount: number;
  premiumTenantsCount: number;
  totalOrdersAcrossPlatform: number;
}
