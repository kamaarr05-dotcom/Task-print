import 'dotenv/config';
import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import { createServer as createViteServer } from 'vite';
import { createClient } from '@supabase/supabase-js';
import { GoogleGenAI } from '@google/genai';
import {
  Tenant,
  User,
  Order,
  OrderStatus,
  OrderFile,
  OrderTimelineEvent,
  TenantPlan,
  Role,
} from './src/types.js';

export const MASTER_EMAIL = 'mdqputra@gmail.com';
export const MASTER_USERNAME = 'mdqputra';

// Cryptographic Password Hashing & Verification (PBKDF2 SHA-512 + Salt)
// No plaintext password is ever stored or hardcoded.
function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.pbkdf2Sync(password, salt, 100000, 64, 'sha512').toString('hex');
  return `pbkdf2$100000$${salt}$${hash}`;
}

function verifyPassword(password: string, storedHash: string): boolean {
  if (!storedHash) return false;
  if (!storedHash.startsWith('pbkdf2$')) {
    // Plaintext fallback for pre-seeded non-master tenant staff demo accounts (e.g. 123456)
    return password === storedHash;
  }
  const parts = storedHash.split('$');
  if (parts.length !== 4) return false;
  const iterations = parseInt(parts[1], 10);
  const salt = parts[2];
  const originalHash = parts[3];
  const testHash = crypto.pbkdf2Sync(password, salt, iterations, 64, 'sha512').toString('hex');
  return crypto.timingSafeEqual(Buffer.from(testHash, 'hex'), Buffer.from(originalHash, 'hex'));
}

interface AuthRequest extends Request {
  user?: {
    id: string;
    username: string;
    name: string;
    role: Role;
    tenantId: string | null;
  };
}

const PORT = 3000;
const DATA_DIR = path.join(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');

// In-Memory Database with JSON Disk Sync
interface DatabaseSchema {
  tenants: Tenant[];
  users: (User & { passwordHash: string })[];
  orders: Order[];
}

function initData(): DatabaseSchema {
  if (fs.existsSync(DB_FILE)) {
    try {
      const data = JSON.parse(fs.readFileSync(DB_FILE, 'utf-8'));
      if (data.tenants && data.users && data.orders) {
        // Enforce Single Master Account Rule & Purge any plaintext/hardcoded master passwords
        const masterUser = data.users.find((u: any) => u.role === 'MASTER' || u.id === 'user-master');
        if (masterUser) {
          masterUser.id = 'user-master';
          masterUser.username = MASTER_USERNAME;
          masterUser.email = MASTER_EMAIL;
          masterUser.role = 'MASTER';
          masterUser.tenantId = null;
          masterUser.name = 'Master Platform Owner';
          // If password is old mock 'master123' or not a PBKDF2 hash, purge it so user types their own password
          if (masterUser.passwordHash === 'master123' || !masterUser.passwordHash || !masterUser.passwordHash.startsWith('pbkdf2$')) {
            masterUser.passwordHash = '';
          }
        } else {
          data.users.unshift({
            id: 'user-master',
            tenantId: null,
            username: MASTER_USERNAME,
            email: MASTER_EMAIL,
            passwordHash: '',
            name: 'Master Platform Owner',
            role: 'MASTER',
            phone: '08111000222',
            createdAt: new Date('2026-07-01T00:00:00Z').toISOString(),
          });
        }

        // Ensure NO other user can have role MASTER
        data.users = data.users.filter((u: any) => {
          if (u.role === 'MASTER') {
            return u.id === 'user-master';
          }
          return true;
        });

        fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
        return data;
      }
    } catch (e) {
      console.error('Failed to read db.json, reinitializing seed data', e);
    }
  }

  // Pre-seed Realistic Printing Multi-Tenant Data
  const seedTenants: Tenant[] = [
    {
      id: 'tenant-cahaya',
      name: 'Cahaya Print Digital',
      code: 'CPD',
      plan: 'PREMIUM',
      trackingEnabled: true,
      phone: '081234567890',
      address: 'Jl. Surya Kencana No. 45, Jakarta Selatan',
      status: 'ACTIVE',
      createdAt: new Date('2026-08-01T08:00:00Z').toISOString(),
    },
    {
      id: 'tenant-prima',
      name: 'Prima Offset & Sablon',
      code: 'POS',
      plan: 'BASIC',
      trackingEnabled: false,
      phone: '089876543210',
      address: 'Jl. Merdeka Barat No. 12, Bandung',
      status: 'ACTIVE',
      createdAt: new Date('2026-08-10T09:30:00Z').toISOString(),
    },
  ];

  const seedUsers: (User & { passwordHash: string })[] = [
    // MASTER PLATFORM OWNER (Satu-satunya akun Master dalam seluruh sistem: mdqputra@gmail.com)
    {
      id: 'user-master',
      tenantId: null,
      username: MASTER_USERNAME,
      email: MASTER_EMAIL,
      passwordHash: '', // Password tidak disimpan di source code. Dibuat sendiri oleh pemilik melalui setup password aman.
      name: 'Master Platform Owner',
      role: 'MASTER',
      phone: '08111000222',
      createdAt: new Date('2026-07-01T00:00:00Z').toISOString(),
    },

    // TENANT 1: Cahaya Print Digital (PREMIUM)
    {
      id: 'user-cahaya-admin',
      tenantId: 'tenant-cahaya',
      username: 'admin_cahaya',
      passwordHash: '123456',
      name: 'Budi Santoso (Admin CPD)',
      role: 'ADMIN',
      phone: '081234567891',
      createdAt: new Date('2026-08-01T08:05:00Z').toISOString(),
    },
    {
      id: 'user-cahaya-desain',
      tenantId: 'tenant-cahaya',
      username: 'desain_cahaya',
      passwordHash: '123456',
      name: 'Dian Permata (Desainer CPD)',
      role: 'DESAINER',
      phone: '081234567892',
      createdAt: new Date('2026-08-01T08:10:00Z').toISOString(),
    },
    {
      id: 'user-cahaya-cetak',
      tenantId: 'tenant-cahaya',
      username: 'cetak_cahaya',
      passwordHash: '123456',
      name: 'Hendra Gunawan (Operator Cetak CPD)',
      role: 'OPERATOR_CETAK',
      phone: '081234567893',
      createdAt: new Date('2026-08-01T08:15:00Z').toISOString(),
    },
    {
      id: 'user-cahaya-qc',
      tenantId: 'tenant-cahaya',
      username: 'qc_cahaya',
      passwordHash: '123456',
      name: 'Siti Rahma (Finishing & QC CPD)',
      role: 'FINISHING_QC',
      phone: '081234567894',
      createdAt: new Date('2026-08-01T08:20:00Z').toISOString(),
    },

    // TENANT 2: Prima Offset & Sablon (BASIC)
    {
      id: 'user-prima-admin',
      tenantId: 'tenant-prima',
      username: 'admin_prima',
      passwordHash: '123456',
      name: 'Agus Pratama (Admin Prima)',
      role: 'ADMIN',
      phone: '089876543211',
      createdAt: new Date('2026-08-10T09:35:00Z').toISOString(),
    },
    {
      id: 'user-prima-desain',
      tenantId: 'tenant-prima',
      username: 'desain_prima',
      passwordHash: '123456',
      name: 'Rian Ardiansyah (Desainer Prima)',
      role: 'DESAINER',
      phone: '089876543212',
      createdAt: new Date('2026-08-10T09:40:00Z').toISOString(),
    },
    {
      id: 'user-prima-cetak',
      tenantId: 'tenant-prima',
      username: 'cetak_prima',
      passwordHash: '123456',
      name: 'Joko Widodo (Operator Cetak Prima)',
      role: 'OPERATOR_CETAK',
      phone: '089876543213',
      createdAt: new Date('2026-08-10T09:45:00Z').toISOString(),
    },
    {
      id: 'user-prima-qc',
      tenantId: 'tenant-prima',
      username: 'qc_prima',
      passwordHash: '123456',
      name: 'Maya Indah (Finishing & QC Prima)',
      role: 'FINISHING_QC',
      phone: '089876543214',
      createdAt: new Date('2026-08-10T09:50:00Z').toISOString(),
    },
  ];

  const seedOrders: Order[] = [
    // Orders for Cahaya Print Digital (PREMIUM)
    {
      id: 'ord-cahaya-1',
      tenantId: 'tenant-cahaya',
      orderNumber: 'CPD-202609-001',
      trackingCode: 'trk-cpd-001-abc88',
      customerName: 'PT Nusantara Sentosa (Ibu Maya)',
      customerWhatsapp: '6281311223344',
      jobType: 'Brosur Promosi Triwulan',
      size: 'A4 Lipat 3 (21 x 29.7 cm)',
      material: 'Art Paper 150 gr',
      quantity: 2000,
      unit: 'lembar',
      finishing: 'Laminasi Doff 2 Sisi + Lipat Rel 3',
      deadline: new Date(Date.now() + 86400000 * 2).toISOString(),
      notes: 'Warna corporate harus presisi CMYK #003366, packaging rapi per 100 lembar',
      needsDesign: true,
      pic: 'Dian Permata (Desainer)',
      status: 'APPROVAL',
      files: [
        {
          id: 'file-1',
          name: 'Draft_Brosur_Nusantara_v2.pdf',
          fileType: 'application/pdf',
          category: 'FILE_DESAIN',
          url: 'https://images.unsplash.com/photo-1541701494587-cb58502866ab?auto=format&fit=crop&w=800&q=80',
          size: '4.2 MB',
          uploadedBy: 'Dian Permata (Desainer)',
          uploadedAt: new Date(Date.now() - 3600000 * 5).toISOString(),
        },
      ],
      timeline: [
        {
          id: 'tl-1',
          status: 'PESANAN_MASUK',
          title: 'Pesanan Masuk & Dicatat',
          note: 'Pesanan diinput oleh Admin dengan kebutuhan desain baru.',
          actorName: 'Budi Santoso',
          actorRole: 'ADMIN',
          timestamp: new Date(Date.now() - 3600000 * 24).toISOString(),
        },
        {
          id: 'tl-2',
          status: 'VERIFIKASI',
          title: 'Verifikasi Spesifikasi & File Awal',
          note: 'Spesifikasi ukuran A4 lipat 3 dan kuantiti 2000 lembar valid.',
          actorName: 'Budi Santoso',
          actorRole: 'ADMIN',
          timestamp: new Date(Date.now() - 3600000 * 18).toISOString(),
        },
        {
          id: 'tl-3',
          status: 'DESAIN',
          title: 'Proses Pengerjaan Layout Desain',
          note: 'Desainer menyelesaikan mockup draft v2 sesuai brand guidelines klien.',
          actorName: 'Dian Permata',
          actorRole: 'DESAINER',
          timestamp: new Date(Date.now() - 3600000 * 10).toISOString(),
        },
        {
          id: 'tl-4',
          status: 'APPROVAL',
          title: 'Menunggu Approval Konsumen',
          note: 'Preview dikirim ke WhatsApp Ibu Maya untuk konfirmasi cetak.',
          actorName: 'Dian Permata',
          actorRole: 'DESAINER',
          timestamp: new Date(Date.now() - 3600000 * 5).toISOString(),
        },
      ],
      createdAt: new Date(Date.now() - 3600000 * 24).toISOString(),
      updatedAt: new Date(Date.now() - 3600000 * 5).toISOString(),
    },
    {
      id: 'ord-cahaya-2',
      tenantId: 'tenant-cahaya',
      orderNumber: 'CPD-202609-002',
      trackingCode: 'trk-cpd-002-xyz99',
      customerName: 'Kopi Kenangan Senja (Bpk Kevin)',
      customerWhatsapp: '6281299887766',
      jobType: 'Stiker Cup & Label Botol',
      size: '5 x 5 cm Bulat',
      material: 'Stiker Vinyl Transparan Waterproof',
      quantity: 5000,
      unit: 'pcs',
      finishing: 'Kiss Cut Die Cut Lembaran A3+',
      deadline: new Date(Date.now() + 86400000 * 1).toISOString(),
      notes: 'File siap cetak dari konsumen, tanpa desain baru.',
      needsDesign: false, // JALUR LANGSUNG PRODUKSI
      pic: 'Hendra Gunawan (Operator Cetak)',
      status: 'PRODUKSI_CETAK',
      files: [
        {
          id: 'file-2',
          name: 'Label_Kopi_Kenangan_SiapCetak.ai',
          fileType: 'application/illustrator',
          category: 'FILE_CETAK',
          url: 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&w=800&q=80',
          size: '8.5 MB',
          uploadedBy: 'Budi Santoso (Admin)',
          uploadedAt: new Date(Date.now() - 3600000 * 8).toISOString(),
        },
      ],
      timeline: [
        {
          id: 'tl-21',
          status: 'PESANAN_MASUK',
          title: 'Pesanan Masuk (File Siap Cetak)',
          note: 'Konsumen membawa file vektor siap cetak.',
          actorName: 'Budi Santoso',
          actorRole: 'ADMIN',
          timestamp: new Date(Date.now() - 3600000 * 12).toISOString(),
        },
        {
          id: 'tl-22',
          status: 'VERIFIKASI',
          title: 'Verifikasi File Selesai (Langsung ke Produksi)',
          note: 'File verified 300 DPI CMYK. Tanpa desain, diteruskan langsung ke mesin Roland UV.',
          actorName: 'Budi Santoso',
          actorRole: 'ADMIN',
          timestamp: new Date(Date.now() - 3600000 * 8).toISOString(),
        },
        {
          id: 'tl-23',
          status: 'PRODUKSI_CETAK',
          title: 'Sedang Proses Cetak Mesin Roland UV',
          note: 'Mesin 1 sedang mencetak lembar A3+ vinyl transparan.',
          actorName: 'Hendra Gunawan',
          actorRole: 'OPERATOR_CETAK',
          timestamp: new Date(Date.now() - 3600000 * 2).toISOString(),
        },
      ],
      createdAt: new Date(Date.now() - 3600000 * 12).toISOString(),
      updatedAt: new Date(Date.now() - 3600000 * 2).toISOString(),
    },
    {
      id: 'ord-cahaya-3',
      tenantId: 'tenant-cahaya',
      orderNumber: 'CPD-202609-003',
      trackingCode: 'trk-cpd-003-fin11',
      customerName: 'Event Organizer Harmoni (Kak Rian)',
      customerWhatsapp: '6285677889900',
      jobType: 'Roll Up Banner & Backdrop Panggung',
      size: '85 x 200 cm (2 unit)',
      material: 'Luster / Albatros Matte Anti Lengkung',
      quantity: 2,
      unit: 'set',
      finishing: 'Pemasangan pada Standing Roll Up Aluminium',
      deadline: new Date(Date.now() + 3600000 * 6).toISOString(),
      notes: 'Untuk acara besok pagi jam 08.00 WIB, cek kelurusan tarikan roll up.',
      needsDesign: false,
      pic: 'Siti Rahma (Finishing/QC)',
      status: 'FINISHING_QC',
      files: [],
      timeline: [
        {
          id: 'tl-31',
          status: 'PESANAN_MASUK',
          title: 'Pesanan Masuk',
          note: 'Order kilat event backdrop.',
          actorName: 'Budi Santoso',
          actorRole: 'ADMIN',
          timestamp: new Date(Date.now() - 3600000 * 10).toISOString(),
        },
        {
          id: 'tl-32',
          status: 'VERIFIKASI',
          title: 'Verifikasi Cepat',
          note: 'Langsung ke Produksi cetak indoor.',
          actorName: 'Budi Santoso',
          actorRole: 'ADMIN',
          timestamp: new Date(Date.now() - 3600000 * 8).toISOString(),
        },
        {
          id: 'tl-33',
          status: 'PRODUKSI_CETAK',
          title: 'Selesai Cetak Indoor High Res',
          note: 'Cetak tajam warna cerah selesai.',
          actorName: 'Hendra Gunawan',
          actorRole: 'OPERATOR_CETAK',
          timestamp: new Date(Date.now() - 3600000 * 3).toISOString(),
        },
        {
          id: 'tl-34',
          status: 'FINISHING_QC',
          title: 'Proses Pemasangan & Quality Control',
          note: 'Memasang ke mekanis aluminium dan pengujian tarikan pegas.',
          actorName: 'Siti Rahma',
          actorRole: 'FINISHING_QC',
          timestamp: new Date(Date.now() - 3600000 * 1).toISOString(),
        },
      ],
      createdAt: new Date(Date.now() - 3600000 * 10).toISOString(),
      updatedAt: new Date(Date.now() - 3600000 * 1).toISOString(),
    },

    // Orders for Prima Offset & Sablon (BASIC - Strictly Isolated!)
    {
      id: 'ord-prima-1',
      tenantId: 'tenant-prima',
      orderNumber: 'POS-202609-001',
      trackingCode: 'trk-pos-001-bsc22',
      customerName: 'Toko Buku Sejahtera (Bpk Asep)',
      customerWhatsapp: '6287711223344',
      jobType: 'Buku Nota & Faktur 3 Rangkap NCR',
      size: '1/4 Folio (10.5 x 16.5 cm)',
      material: 'Kertas NCR Putih-Merah-Kuning',
      quantity: 50,
      unit: 'buku',
      finishing: 'Jilid Lem Punggung + Porporasi Sobek + Nomorator 001-2500',
      deadline: new Date(Date.now() + 86400000 * 3).toISOString(),
      notes: 'Nomorator start dari 001, cetak tinta biru 1 warna',
      needsDesign: true,
      pic: 'Rian Ardiansyah (Desainer Prima)',
      status: 'DESAIN',
      files: [],
      timeline: [
        {
          id: 'tl-p1',
          status: 'PESANAN_MASUK',
          title: 'Pesanan Masuk',
          note: 'Diterima oleh Admin Prima.',
          actorName: 'Agus Pratama',
          actorRole: 'ADMIN',
          timestamp: new Date(Date.now() - 3600000 * 16).toISOString(),
        },
        {
          id: 'tl-p2',
          status: 'VERIFIKASI',
          title: 'Verifikasi Format Tabel Nota',
          note: 'Memerlukan setting format kolom.',
          actorName: 'Agus Pratama',
          actorRole: 'ADMIN',
          timestamp: new Date(Date.now() - 3600000 * 12).toISOString(),
        },
        {
          id: 'tl-p3',
          status: 'DESAIN',
          title: 'Penyusunan Format Nota & Nomorator',
          note: 'Desainer sedang menata header dan kolom.',
          actorName: 'Rian Ardiansyah',
          actorRole: 'DESAINER',
          timestamp: new Date(Date.now() - 3600000 * 4).toISOString(),
        },
      ],
      createdAt: new Date(Date.now() - 3600000 * 16).toISOString(),
      updatedAt: new Date(Date.now() - 3600000 * 4).toISOString(),
    },
  ];

  const initialData: DatabaseSchema = {
    tenants: seedTenants,
    users: seedUsers,
    orders: seedOrders,
  };

  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  fs.writeFileSync(DB_FILE, JSON.stringify(initialData, null, 2), 'utf-8');
  return initialData;
}

const db: DatabaseSchema = initData();

function saveDatabase() {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), 'utf-8');
  } catch (err) {
    console.error('Failed to write database file', err);
  }
}

// Helper: Token Generator & Decoder (Stateful token map or simple base64 auth for robustness)
const activeSessions: Map<string, { userId: string; createdAt: number }> = new Map();

function createSession(userId: string): string {
  const token = `tok_${userId}_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
  activeSessions.set(token, { userId, createdAt: Date.now() });
  return token;
}

// Authentication & Strict Tenant Isolation Middleware
function authenticateAuthToken(req: AuthRequest, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'UNAUTHORIZED', message: 'Token otentikasi tidak ditemukan.' });
  }

  const token = authHeader.split(' ')[1];
  
  // Also support quick token format `tok_user-id` for testing
  let userId: string | null = null;
  if (activeSessions.has(token)) {
    userId = activeSessions.get(token)!.userId;
  } else if (token.startsWith('user-')) {
    // STRICT SECURITY: Master platform owner must authenticate with their real PBKDF2 password
    // Quick-token bypass is prohibited for the Master role.
    if (token !== 'user-master') {
      userId = token;
    }
  }

  if (!userId) {
    return res.status(401).json({ error: 'INVALID_TOKEN', message: 'Sesi Anda tidak valid atau telah kedaluwarsa.' });
  }

  const user = db.users.find(u => u.id === userId);
  if (!user) {
    return res.status(401).json({ error: 'USER_NOT_FOUND', message: 'Pengguna tidak ditemukan.' });
  }

  req.user = {
    id: user.id,
    username: user.username,
    name: user.name,
    role: user.role,
    tenantId: user.tenantId,
  };

  next();
}

// Strict Tenant Isolation Guard: Ensures tenant user cannot touch data belonging to another tenant
function requireTenantIsolation(req: AuthRequest, res: Response, next: NextFunction) {
  if (!req.user) {
    return res.status(401).json({ error: 'UNAUTHORIZED' });
  }

  if (req.user.role === 'MASTER') {
    return next();
  }

  if (!req.user.tenantId) {
    return res.status(403).json({ error: 'FORBIDDEN', message: 'User tidak memiliki asosiasi tenant.' });
  }

  next();
}

// Require Master role
function requireMasterRole(req: AuthRequest, res: Response, next: NextFunction) {
  if (!req.user || req.user.role !== 'MASTER') {
    return res.status(403).json({
      error: 'FORBIDDEN',
      message: 'Akses ditolak: Operasi ini hanya diizinkan untuk MASTER platform.',
    });
  }
  next();
}

// Require Admin role (Tenant Admin or Master)
function requireAdminRole(req: AuthRequest, res: Response, next: NextFunction) {
  if (!req.user || (req.user.role !== 'ADMIN' && req.user.role !== 'MASTER')) {
    return res.status(403).json({
      error: 'FORBIDDEN',
      message: 'Akses ditolak: Operasi ini hanya diizinkan untuk Admin Tenant.',
    });
  }
  next();
}



// ==============================================================================
// AI ASSISTANT TASK PRINT (PREMIUM ONLY, TENANT-SCOPED)
// =====================================================================
type AIFilterDeadline = 'TODAY' | 'TOMORROW' | 'OVERDUE';
interface AIFilters {
  customer?: string;
  orderNumber?: string;
  pic?: string;
  status?: string;
  deadline?: AIFilterDeadline;
}
interface AIAssistantContext {
  mode: 'demo' | 'supabase';
  userId: string;
  tenantId: string;
  tenantName: string;
  userName: string;
  role: Role;
  supabaseClient?: ReturnType<typeof createClient>;
}
interface AIOrderRecord {
  id: string;
  orderNumber: string;
  customerName: string;
  jobType: string;
  size: string;
  material: string;
  quantity: number;
  unit: string;
  deadline: string;
  pic: string;
  status: string;
  statusLabel: string;
  nextStep: string;
  needsDesign: boolean;
  notes: string;
  timeline: Array<{ status: string; title: string; note?: string; actorName: string; createdAt: string }>;
  files: Array<{ category: string; name: string; createdAt: string; uploadedBy: string }>;
}

const AI_STATUS_LABELS: Record<string, string> = {
  PESANAN_MASUK: 'Pesanan Masuk',
  VERIFIKASI: 'Verifikasi',
  DESAIN: 'Desain',
  APPROVAL: 'Menunggu Approval',
  PRODUKSI_CETAK: 'Produksi',
  FINISHING_QC: 'Finishing + QC',
  SIAP_DIAMBIL_DIKIRIM: 'Siap Diambil/Dikirim',
  SELESAI: 'Selesai',
};
const AI_NEXT_STEPS: Record<string, string> = {
  PESANAN_MASUK: 'Verifikasi',
  VERIFIKASI: 'Desain / Produksi',
  DESAIN: 'Approval',
  APPROVAL: 'Produksi',
  PRODUKSI_CETAK: 'Finishing + QC',
  FINISHING_QC: 'Siap Diambil/Dikirim',
  SIAP_DIAMBIL_DIKIRIM: 'Selesai',
  SELESAI: 'Tidak ada — selesai',
};

function isLikelySupabaseJwt(token: string) {
  return token.split('.').length === 3 && token.length > 100;
}

function getServerSupabaseConfig() {
  const url = process.env.VITE_SUPABASE_URL || '';
  const key = process.env.VITE_SUPABASE_PUBLISHABLE_KEY || process.env.VITE_SUPABASE_ANON_KEY || '';
  if (!url || !key || url.includes('placeholder') || key.includes('placeholder')) return null;
  return { url, key };
}

function jakartaDateKey(date: Date) {
  return new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Jakarta', year: 'numeric', month: '2-digit', day: '2-digit'
  }).format(date);
}

function relativeDeadlineMatches(deadline: string, filter?: AIFilterDeadline) {
  if (!filter) return true;
  const d = new Date(deadline);
  const today = new Date();
  const todayKey = jakartaDateKey(today);
  const dKey = jakartaDateKey(d);
  if (filter === 'TODAY') return dKey === todayKey;
  const tomorrow = new Date(today.getTime() + 24 * 60 * 60 * 1000);
  if (filter === 'TOMORROW') return dKey === jakartaDateKey(tomorrow);
  return d.getTime() < today.getTime();
}

function compactText(value: unknown, max = 260) {
  return String(value ?? '').replace(/\s+/g, ' ').trim().slice(0, max);
}

function mapSupabaseOrder(row: any): AIOrderRecord {
  const timeline = Array.isArray(row.order_timeline) ? row.order_timeline : [];
  const files = Array.isArray(row.order_files) ? row.order_files : [];
  return {
    id: row.id,
    orderNumber: row.order_number,
    customerName: row.customer_name,
    jobType: row.job_type,
    size: row.size,
    material: row.material,
    quantity: Number(row.quantity || 0),
    unit: row.unit,
    deadline: row.deadline,
    pic: row.pic || '',
    status: row.status,
    statusLabel: AI_STATUS_LABELS[row.status] || row.status,
    nextStep: AI_NEXT_STEPS[row.status] || '-',
    needsDesign: Boolean(row.needs_design),
    notes: compactText(row.notes),
    timeline: timeline.map((t: any) => ({
      status: t.status,
      title: t.title,
      note: compactText(t.note),
      actorName: t.actor_name,
      createdAt: t.created_at,
    })),
    files: files.map((f: any) => ({
      category: f.category,
      name: f.name,
      createdAt: f.created_at,
      uploadedBy: f.uploaded_by,
    })),
  };
}

function mapDemoOrder(row: Order): AIOrderRecord {
  return {
    id: row.id,
    orderNumber: row.orderNumber,
    customerName: row.customerName,
    jobType: row.jobType,
    size: row.size,
    material: row.material,
    quantity: row.quantity,
    unit: row.unit,
    deadline: row.deadline,
    pic: row.pic || '',
    status: row.status,
    statusLabel: AI_STATUS_LABELS[row.status] || row.status,
    nextStep: AI_NEXT_STEPS[row.status] || '-',
    needsDesign: Boolean(row.needsDesign),
    notes: compactText(row.notes),
    timeline: (row.timeline || []).map(t => ({
      status: t.status,
      title: t.title,
      note: compactText(t.note),
      actorName: t.actorName,
      createdAt: t.timestamp,
    })),
    files: (row.files || []).map(f => ({ category: f.category, name: f.name, createdAt: f.uploadedAt, uploadedBy: f.uploadedBy })),
  };
}

function extractOrderNumber(question: string, orders: AIOrderRecord[]) {
  const lower = question.toLowerCase();
  return orders.find(o => lower.includes(o.orderNumber.toLowerCase()))?.orderNumber;
}

function extractCustomerPhrase(question: string, orders: AIOrderRecord[]) {
  const lower = question.toLowerCase();
  const match = orders.find(o => lower.includes(o.customerName.toLowerCase()));
  if (match) return match.customerName;
  const pak = lower.match(/\b(?:pak|bpk|ibu|bu)\s+([a-z0-9][a-z0-9 .'-]{1,40})/i);
  return pak ? pak[1].trim() : undefined;
}

function matchesQuestion(question: string, order: AIOrderRecord, filters: AIFilters) {
  const q = question.toLowerCase();
  if (filters.customer && !order.customerName.toLowerCase().includes(filters.customer.toLowerCase())) return false;
  if (filters.orderNumber && !order.orderNumber.toLowerCase().includes(filters.orderNumber.toLowerCase())) return false;
  if (filters.pic && !order.pic.toLowerCase().includes(filters.pic.toLowerCase())) return false;
  if (filters.status && order.status !== filters.status) return false;
  if (!relativeDeadlineMatches(order.deadline, filters.deadline)) return false;
  if (filters.deadline === 'OVERDUE' && order.status === 'SELESAI') return false;

  const customer = extractCustomerPhrase(question, [order]);
  if (customer && !order.customerName.toLowerCase().includes(customer.toLowerCase())) return false;

  if (/terlambat|telat|overdue/.test(q) && !(new Date(order.deadline).getTime() < Date.now() && order.status !== 'SELESAI')) return false;
  if (/besok|deadline.*besok/.test(q) && !relativeDeadlineMatches(order.deadline, 'TOMORROW')) return false;
  if (/hari ini|deadline.*hari ini/.test(q) && !relativeDeadlineMatches(order.deadline, 'TODAY')) return false;
  if (/sedang produksi|produksi/.test(q) && order.status !== 'PRODUKSI_CETAK') return false;
  if (/menunggu approval|approval/.test(q) && order.status !== 'APPROVAL') return false;
  if (/belum selesai|belum.*selesai/.test(q) && order.status === 'SELESAI') return false;
  return true;
}

function humanDate(value: string) {
  try {
    return new Intl.DateTimeFormat('id-ID', { dateStyle: 'long', timeZone: 'Asia/Jakarta' }).format(new Date(value));
  } catch { return value; }
}

function approvalInfo(order: AIOrderRecord) {
  const approvalFile = order.files.find(f => f.category === 'BUKTI_APPROVAL');
  const approvalEvent = [...order.timeline].reverse().find(t => t.status === 'APPROVAL');
  if (approvalFile) return `Bukti approval tersedia: ${approvalFile.name}`;
  if (approvalEvent) return compactText(approvalEvent.note || approvalEvent.title);
  return order.needsDesign ? 'Pesanan membutuhkan desain; data approval belum tercatat.' : 'Tidak ada catatan approval khusus.';
}

function makeAIAnswer(question: string, orders: AIOrderRecord[]) {
  const q = question.toLowerCase();
  if (!orders.length) return 'Tidak ada pesanan yang cocok dengan pertanyaan atau filter Anda pada tenant ini.';
  if (/siapa\s+pic|pic\s+(?:untuk|pesanan)/.test(q)) {
    return orders.map(o => `${o.customerName} (${o.orderNumber}) → PIC: ${o.pic || '-'}; status: ${o.statusLabel}.`).join('\n');
  }
  if (/sudah sampai mana|status|cek pesanan/.test(q) && orders.length <= 3) {
    return orders.map(o => `Pesanan ${o.customerName} saat ini ${o.statusLabel}.\nNomor pesanan: ${o.orderNumber}\nPekerjaan: ${o.jobType}\nPIC: ${o.pic || '-'}\nDeadline: ${humanDate(o.deadline)}\nTahap berikutnya: ${o.nextStep}\nApproval: ${approvalInfo(o)}`).join('\n\n');
  }
  if (/terlambat|telat/.test(q)) return `Ada ${orders.length} pesanan yang terlambat:\n` + orders.slice(0, 25).map(o => `• ${o.orderNumber} — ${o.customerName} — deadline ${humanDate(o.deadline)} — ${o.statusLabel}`).join('\n');
  if (/besok/.test(q)) return `Pesanan dengan deadline besok (${orders.length}):\n` + orders.slice(0, 25).map(o => `• ${o.orderNumber} — ${o.customerName} — ${o.jobType} — PIC ${o.pic || '-'}`).join('\n');
  if (/produksi/.test(q)) return `Pesanan yang sedang produksi (${orders.length}):\n` + orders.slice(0, 25).map(o => `• ${o.orderNumber} — ${o.customerName} — ${o.jobType} — deadline ${humanDate(o.deadline)} — PIC ${o.pic || '-'}`).join('\n');
  if (/approval/.test(q)) return `Pesanan yang sedang menunggu approval (${orders.length}):\n` + orders.slice(0, 25).map(o => `• ${o.orderNumber} — ${o.customerName} — PIC ${o.pic || '-'} — ${approvalInfo(o)}`).join('\n');
  return `Saya menemukan ${orders.length} pesanan yang relevan:\n` + orders.slice(0, 25).map(o => `• ${o.orderNumber} — ${o.customerName} — ${o.statusLabel} — deadline ${humanDate(o.deadline)} — PIC ${o.pic || '-'}`).join('\n');
}

async function polishWithGemini(question: string, orders: AIOrderRecord[], fallback: string) {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return fallback;
  try {
    const ai = new GoogleGenAI({ apiKey });
    const safeData = orders.slice(0, 30).map(o => ({
      nomor_pesanan: o.orderNumber, customer: o.customerName, pekerjaan: o.jobType, ukuran: o.size,
      material: o.material, jumlah: o.quantity, unit: o.unit, deadline: humanDate(o.deadline), pic: o.pic,
      status: o.statusLabel, tahap_berikutnya: o.nextStep, butuh_desain: o.needsDesign, approval: approvalInfo(o), catatan: o.notes,
    }));
    const prompt = `Anda adalah AI Assistant Task Print. Jawab dalam Bahasa Indonesia, ringkas, jelas, tanpa membuat data baru.\n\nPERTANYAAN USER:\n${question}\n\nDATA TASK PRINT (sudah dibatasi ke tenant user):\n${JSON.stringify(safeData)}\n\nATURAN: Gunakan hanya data di atas. Jangan pernah menyebut data tenant lain. Jangan menampilkan URL/file rahasia. Jika tidak ada data, katakan tidak ditemukan. Maksimal 8 baris utama.`;
    const response = await ai.models.generateContent({ model: 'gemini-2.5-flash', contents: prompt });
    const text = response.text?.trim();
    return text || fallback;
  } catch (error) {
    console.warn('Gemini AI polishing skipped:', error);
    return fallback;
  }
}

async function authenticateAIAssistant(req: Request, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  if (!authHeader?.startsWith('Bearer ')) return res.status(401).json({ error: 'UNAUTHORIZED', message: 'Token otentikasi tidak ditemukan.' });
  const token = authHeader.slice(7);

  // First support secure local demo sessions used by this project.
  let localUserId: string | null = null;
  if (activeSessions.has(token)) localUserId = activeSessions.get(token)!.userId;
  else if (token.startsWith('user-') && token !== 'user-master') localUserId = token;
  if (localUserId) {
    const user = db.users.find(u => u.id === localUserId);
    if (!user || !user.tenantId) return res.status(403).json({ error: 'AI_TENANT_REQUIRED', message: 'AI Assistant hanya tersedia untuk akun tenant Premium.' });
    const tenant = db.tenants.find(t => t.id === user.tenantId);
    if (!tenant || tenant.plan !== 'PREMIUM' || tenant.status !== 'ACTIVE') {
      return res.status(403).json({ error: 'AI_PREMIUM_REQUIRED', message: 'AI Assistant hanya tersedia untuk Paket Premium Rp300.000.' });
    }
    (req as any).aiContext = { mode: 'demo', userId: user.id, tenantId: tenant.id, tenantName: tenant.name, userName: user.name, role: user.role } satisfies AIAssistantContext;
    return next();
  }

  // For real Supabase Auth, query using the caller's JWT. This preserves RLS.
  if (!isLikelySupabaseJwt(token)) return res.status(401).json({ error: 'INVALID_TOKEN', message: 'Sesi Supabase tidak valid.' });
  const cfg = getServerSupabaseConfig();
  if (!cfg) return res.status(503).json({ error: 'SUPABASE_NOT_CONFIGURED', message: 'Supabase belum dikonfigurasi di server.' });
  const sb = createClient(cfg.url, cfg.key, { global: { headers: { Authorization: `Bearer ${token}` } }, auth: { persistSession: false, autoRefreshToken: false } });
  const { data: authData, error: authError } = await sb.auth.getUser(token);
  if (authError || !authData.user) return res.status(401).json({ error: 'INVALID_TOKEN', message: 'Token Supabase tidak valid atau telah kedaluwarsa.' });
  const { data: profile, error: profileError } = await sb.from('profiles').select('id,name,role,tenant_id').eq('id', authData.user.id).single();
  if (profileError || !profile?.tenant_id) return res.status(403).json({ error: 'AI_TENANT_REQUIRED', message: 'AI Assistant hanya tersedia untuk akun tenant.' });
  const { data: tenant, error: tenantError } = await sb.from('tenants').select('id,name,plan,status').eq('id', profile.tenant_id).single();
  if (tenantError || !tenant) return res.status(403).json({ error: 'TENANT_NOT_FOUND', message: 'Tenant aktif tidak ditemukan.' });
  if (tenant.plan !== 'PREMIUM' || tenant.status !== 'ACTIVE') return res.status(403).json({ error: 'AI_PREMIUM_REQUIRED', message: 'AI Assistant hanya tersedia untuk Paket Premium Rp300.000.' });
  (req as any).aiContext = { mode: 'supabase', userId: profile.id, tenantId: tenant.id, tenantName: tenant.name, userName: profile.name, role: profile.role as Role, supabaseClient: sb } satisfies AIAssistantContext;
  return next();
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '15mb' }));

  // ==========================================
  // MASTER SETUP & RECOVERY ENDPOINTS
  // ==========================================

  // Check if Master Account password has been configured
  app.get('/api/master/setup-status', (req: Request, res: Response) => {
    const masterUser = db.users.find(u => u.role === 'MASTER' || u.id === 'user-master');
    const isConfigured = Boolean(masterUser && masterUser.passwordHash && masterUser.passwordHash.startsWith('pbkdf2$'));
    res.json({
      isConfigured,
      email: MASTER_EMAIL,
      username: MASTER_USERNAME,
      name: masterUser ? masterUser.name : 'Master Platform Owner',
    });
  });

  // Setup or Change Master Password (Strictly for mdqputra@gmail.com only)
  app.post('/api/master/setup-password', (req: Request, res: Response) => {
    const { email, password, currentPassword } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: 'Email dan password baru wajib diisi.' });
    }

    // Strict Rule: Master email is immutable and uniquely mdqputra@gmail.com
    if (email.trim().toLowerCase() !== MASTER_EMAIL.toLowerCase()) {
      return res.status(403).json({
        error: 'FORBIDDEN',
        message: `Setup akun Master hanya diizinkan secara eksklusif untuk email ${MASTER_EMAIL}.`,
      });
    }

    const masterUser = db.users.find(u => u.role === 'MASTER' || u.id === 'user-master');
    if (!masterUser) {
      return res.status(404).json({ error: 'Akun Master tidak ditemukan.' });
    }

    const isAlreadyConfigured = Boolean(masterUser.passwordHash && masterUser.passwordHash.startsWith('pbkdf2$'));

    // If already configured, require current password to prevent unauthorized override
    if (isAlreadyConfigured) {
      if (!currentPassword) {
        return res.status(400).json({
          error: 'CURRENT_PASSWORD_REQUIRED',
          message: 'Password akun Master sudah aktif. Masukkan password saat ini untuk melakukan perubahan.',
        });
      }
      if (!verifyPassword(currentPassword, masterUser.passwordHash)) {
        return res.status(401).json({
          error: 'INVALID_CURRENT_PASSWORD',
          message: 'Password saat ini yang Anda masukkan tidak cocok.',
        });
      }
    }

    // Password strength check
    if (typeof password !== 'string' || password.length < 8) {
      return res.status(400).json({
        error: 'PASSWORD_TOO_SHORT',
        message: 'Password Master harus memiliki panjang minimal 8 karakter demi keamanan platform.',
      });
    }

    // Secure Hash with PBKDF2 (100,000 iterations, random salt, SHA-512)
    masterUser.passwordHash = hashPassword(password);
    masterUser.email = MASTER_EMAIL;
    masterUser.username = MASTER_USERNAME;
    saveDatabase();

    res.json({
      success: true,
      message: 'Password akun Master berhasil dibuat dan disimpan secara aman dengan enkripsi PBKDF2.',
      email: MASTER_EMAIL,
    });
  });

  // ==========================================
  // AUTHENTICATION ROUTES
  // ==========================================

  // Demo users list for convenient evaluation of roles and tenants
  // STRICT PRIVACY: Master is strictly hidden from public list and role switchers
  app.get('/api/auth/demo-users', (req: Request, res: Response) => {
    const list = db.users
      .filter(u => u.role !== 'MASTER' && u.id !== 'user-master')
      .map(u => {
        const tenant = u.tenantId ? db.tenants.find(t => t.id === u.tenantId) : null;
        return {
          id: u.id,
          username: u.username,
          email: u.email,
          name: u.name,
          role: u.role,
          tenantId: u.tenantId,
          tenantName: tenant ? tenant.name : 'Tenant',
          tenantPlan: tenant ? tenant.plan : undefined,
          isConfigured: true,
        };
      });
    res.json(list);
  });

  // Login (Supports login via Email or Username)
  app.post('/api/auth/login', (req: Request, res: Response) => {
    const { username, password } = req.body;
    if (!username || !password) {
      return res.status(400).json({ error: 'Email/username dan password wajib diisi.' });
    }

    const identifier = username.trim().toLowerCase();
    const user = db.users.find(u =>
      u.username.toLowerCase() === identifier ||
      (u.email && u.email.toLowerCase() === identifier)
    );

    if (!user) {
      return res.status(401).json({ error: 'Email/username atau password salah.' });
    }

    if (user.role === 'MASTER') {
      // Check if Master password has been configured
      const isConfigured = Boolean(user.passwordHash && user.passwordHash.startsWith('pbkdf2$'));
      if (!isConfigured) {
        return res.status(400).json({
          error: 'MASTER_NOT_CONFIGURED',
          message: 'Akun Master belum mengatur password. Silakan atur password melalui halaman setup Master terlebih dahulu.',
          setupRequired: true,
          email: MASTER_EMAIL,
        });
      }

      // Verify Master Password securely with PBKDF2
      const isValid = verifyPassword(password, user.passwordHash);
      if (!isValid) {
        return res.status(401).json({ error: 'Password akun Master salah. Pastikan Anda memasukkan password yang telah dibuat pada Setup Master.' });
      }
    } else {
      // Non-master users (Tenant Admin, Desainer, Operator Cetak, Finishing & QC)
      const isValid = verifyPassword(password, user.passwordHash);
      if (!isValid) {
        return res.status(401).json({ error: 'Username atau password salah.' });
      }

      const tenant = user.tenantId ? db.tenants.find(t => t.id === user.tenantId) : null;
      if (tenant && tenant.status === 'SUSPENDED') {
        return res.status(403).json({ error: 'Bisnis/Tenant ini sedang ditangguhkan oleh Master.' });
      }
    }

    const token = createSession(user.id);
    res.json({
      token,
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        name: user.name,
        role: user.role,
        tenantId: user.tenantId,
        tenantName: user.tenantId ? db.tenants.find(t => t.id === user.tenantId)?.name : undefined,
        tenantPlan: user.tenantId ? db.tenants.find(t => t.id === user.tenantId)?.plan : undefined,
        isConfigured: user.role === 'MASTER' ? Boolean(user.passwordHash && user.passwordHash.startsWith('pbkdf2$')) : true,
      },
    });
  });

  // Current user info
  app.get('/api/auth/me', authenticateAuthToken, (req: AuthRequest, res: Response) => {
    const user = db.users.find(u => u.id === req.user!.id);
    if (!user) {
      return res.status(404).json({ error: 'Pengguna tidak ditemukan.' });
    }

    const tenant = user.tenantId ? db.tenants.find(t => t.id === user.tenantId) : null;
    res.json({
      id: user.id,
      username: user.username,
      email: user.email,
      name: user.name,
      role: user.role,
      tenantId: user.tenantId,
      tenantName: tenant ? tenant.name : undefined,
      tenantPlan: tenant ? tenant.plan : undefined,
      tenant: tenant || null,
      isConfigured: user.role === 'MASTER' ? Boolean(user.passwordHash && user.passwordHash.startsWith('pbkdf2$')) : true,
    });
  });

  // ==========================================
  // MASTER ROUTES (Strictly Role === 'MASTER')
  // ==========================================

  // List all tenants with statistics
  app.get('/api/master/tenants', authenticateAuthToken, requireMasterRole, (req: AuthRequest, res: Response) => {
    const result = db.tenants.map(t => {
      const orderCount = db.orders.filter(o => o.tenantId === t.id).length;
      const userCount = db.users.filter(u => u.tenantId === t.id).length;
      return {
        ...t,
        orderCount,
        userCount,
      };
    });
    res.json(result);
  });

  // Master Global Stats
  app.get('/api/master/stats', authenticateAuthToken, requireMasterRole, (req: AuthRequest, res: Response) => {
    const totalTenants = db.tenants.length;
    const activeTenants = db.tenants.filter(t => t.status === 'ACTIVE').length;
    const basicTenantsCount = db.tenants.filter(t => t.plan === 'BASIC').length;
    const premiumTenantsCount = db.tenants.filter(t => t.plan === 'PREMIUM').length;
    const totalOrdersAcrossPlatform = db.orders.length;

    res.json({
      totalTenants,
      activeTenants,
      basicTenantsCount,
      premiumTenantsCount,
      totalOrdersAcrossPlatform,
    });
  });

  // Create Tenant & Initial Admin (Master only)
  app.post('/api/master/tenants', authenticateAuthToken, requireMasterRole, (req: AuthRequest, res: Response) => {
    const { name, code, plan, phone, address, adminName, adminUsername, adminPassword, adminPhone } = req.body;

    if (!name || !plan || !adminUsername || !adminPassword) {
      return res.status(400).json({ error: 'Nama tenant, paket (BASIC/PREMIUM), dan data Admin wajib diisi.' });
    }

    const tenantCode = (code || name.substring(0, 3)).toUpperCase().replace(/[^A-Z0-9]/g, '');
    const tenantId = `tenant-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    
    // Check if username already exists
    if (db.users.some(u => u.username.toLowerCase() === adminUsername.trim().toLowerCase())) {
      return res.status(400).json({ error: `Username admin '${adminUsername}' sudah digunakan. Gunakan username lain.` });
    }

    const isPremium = plan === 'PREMIUM';
    const newTenant: Tenant = {
      id: tenantId,
      name: name.trim(),
      code: tenantCode || 'PRT',
      plan: isPremium ? 'PREMIUM' : 'BASIC',
      trackingEnabled: isPremium,
      phone: phone || '',
      address: address || '',
      status: 'ACTIVE',
      createdAt: new Date().toISOString(),
    };

    const newAdminUser: User & { passwordHash: string } = {
      id: `user-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      tenantId: tenantId,
      username: adminUsername.trim().toLowerCase(),
      passwordHash: adminPassword,
      name: adminName || `Admin ${name}`,
      role: 'ADMIN',
      phone: adminPhone || phone || '',
      createdAt: new Date().toISOString(),
    };

    db.tenants.push(newTenant);
    db.users.push(newAdminUser);
    saveDatabase();

    res.status(201).json({
      tenant: newTenant,
      admin: {
        id: newAdminUser.id,
        username: newAdminUser.username,
        name: newAdminUser.name,
        role: newAdminUser.role,
      },
    });
  });

  // Update Tenant (Master only: change plan BASIC/PREMIUM, toggle status, etc.)
  app.patch('/api/master/tenants/:id', authenticateAuthToken, requireMasterRole, (req: AuthRequest, res: Response) => {
    const { id } = req.params;
    const tenant = db.tenants.find(t => t.id === id);
    if (!tenant) {
      return res.status(404).json({ error: 'Tenant tidak ditemukan.' });
    }

    const { name, code, plan, status, phone, address } = req.body;

    if (name) tenant.name = name.trim();
    if (code) tenant.code = code.toUpperCase().trim();
    if (phone !== undefined) tenant.phone = phone;
    if (address !== undefined) tenant.address = address;
    if (status && (status === 'ACTIVE' || status === 'SUSPENDED')) {
      tenant.status = status;
    }
    if (plan && (plan === 'BASIC' || plan === 'PREMIUM')) {
      tenant.plan = plan;
      tenant.trackingEnabled = plan === 'PREMIUM';
    }

    saveDatabase();
    res.json(tenant);
  });

  // ==========================================
  // TENANT USER MANAGEMENT (ADMIN ONLY, STRICTLY SCOPED)
  // ==========================================

  // Get users for the authenticated user's tenant
  app.get('/api/users', authenticateAuthToken, requireTenantIsolation, (req: AuthRequest, res: Response) => {
    // If master, optional tenant filter query; else strictly bound to req.user.tenantId
    const targetTenantId = req.user!.role === 'MASTER' ? (req.query.tenantId as string) || null : req.user!.tenantId;

    if (!targetTenantId) {
      // If master with no query, return all
      const list = db.users.map(u => {
        const { passwordHash, ...rest } = u;
        return rest;
      });
      return res.json(list);
    }

    const filtered = db.users
      .filter(u => u.tenantId === targetTenantId)
      .map(u => {
        const { passwordHash, ...rest } = u;
        return rest;
      });

    res.json(filtered);
  });

  // Admin creates staff (Desainer, Operator Cetak, Finishing & QC, or another Admin)
  app.post('/api/users', authenticateAuthToken, requireTenantIsolation, requireAdminRole, (req: AuthRequest, res: Response) => {
    const { username, password, name, role, phone, email } = req.body;

    if (!username || !password || !name || !role) {
      return res.status(400).json({ error: 'Username, password, nama lengkap, dan role wajib diisi.' });
    }

    // STRICT RULE: Only 1 Master account allowed in whole system (mdqputra@gmail.com)
    // No "Register Master" or role escalation allowed anywhere.
    if (role === 'MASTER' || (role as string).toUpperCase() === 'MASTER') {
      return res.status(403).json({
        error: 'FORBIDDEN',
        message: 'Akses Ditolak: Hanya diizinkan 1 akun Master dalam seluruh sistem (mdqputra@gmail.com). Role Master tidak dapat dibuat atau didaftarkan.',
      });
    }

    const normalizedUsername = username.trim().toLowerCase();
    if (normalizedUsername === MASTER_USERNAME.toLowerCase() || normalizedUsername === 'master') {
      return res.status(400).json({ error: `Username '${username}' dicadangkan khusus untuk akun Master platform.` });
    }

    if (email && email.trim().toLowerCase() === MASTER_EMAIL.toLowerCase()) {
      return res.status(400).json({ error: `Email '${MASTER_EMAIL}' adalah email eksklusif akun Master platform.` });
    }

    const allowedRoles: Role[] = ['ADMIN', 'DESAINER', 'OPERATOR_CETAK', 'FINISHING_QC'];
    if (!allowedRoles.includes(role)) {
      return res.status(400).json({ error: 'Role tidak valid.' });
    }

    if (db.users.some(u => u.username.toLowerCase() === normalizedUsername)) {
      return res.status(400).json({ error: `Username '${username}' sudah digunakan.` });
    }

    const targetTenantId = req.user!.role === 'MASTER' ? req.body.tenantId || req.user!.tenantId : req.user!.tenantId;
    if (!targetTenantId) {
      return res.status(400).json({ error: 'Tenant ID wajib ditentukan.' });
    }

    const newUser: User & { passwordHash: string } = {
      id: `user-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      tenantId: targetTenantId,
      username: normalizedUsername,
      email: email ? email.trim() : undefined,
      passwordHash: password,
      name: name.trim(),
      role: role as Role,
      phone: phone || '',
      createdAt: new Date().toISOString(),
    };

    db.users.push(newUser);
    saveDatabase();

    const { passwordHash, ...safeUser } = newUser;
    res.status(201).json(safeUser);
  });

  // Delete/toggle user (Admin only, strictly within tenant)
  app.delete('/api/users/:id', authenticateAuthToken, requireTenantIsolation, requireAdminRole, (req: AuthRequest, res: Response) => {
    const { id } = req.params;
    const userIndex = db.users.findIndex(u => u.id === id);
    if (userIndex === -1) {
      return res.status(404).json({ error: 'Pengguna tidak ditemukan.' });
    }

    const targetUser = db.users[userIndex];

    // Master account is completely immutable and cannot be deleted
    if (targetUser.role === 'MASTER' || targetUser.id === 'user-master') {
      return res.status(403).json({ error: 'Akses Ditolak: Akun Master tunggal sistem tidak dapat dihapus.' });
    }

    // Tenant isolation verification: Cannot delete user from another tenant!
    if (req.user!.role !== 'MASTER' && targetUser.tenantId !== req.user!.tenantId) {
      return res.status(403).json({ error: 'Akses Ditolak: Anda tidak dapat mengelola user tenant lain.' });
    }

    if (targetUser.id === req.user!.id) {
      return res.status(400).json({ error: 'Anda tidak dapat menghapus akun Anda sendiri.' });
    }

    db.users.splice(userIndex, 1);
    saveDatabase();
    res.json({ message: 'Pengguna berhasil dihapus.' });
  });


  // ============================================================================
  // AI ASSISTANT TASK PRINT (PREMIUM ONLY)
  // ============================================================================
  app.post('/api/ai/task-print', authenticateAIAssistant, async (req: Request, res: Response) => {
    const ctx = (req as any).aiContext as AIAssistantContext;
    const question = typeof req.body?.question === 'string' ? req.body.question.trim() : '';
    const rawFilters = req.body?.filters || {};
    const filters: AIFilters = {
      customer: typeof rawFilters.customer === 'string' ? rawFilters.customer.trim() : undefined,
      orderNumber: typeof rawFilters.orderNumber === 'string' ? rawFilters.orderNumber.trim() : undefined,
      pic: typeof rawFilters.pic === 'string' ? rawFilters.pic.trim() : undefined,
      status: typeof rawFilters.status === 'string' ? rawFilters.status : undefined,
      deadline: ['TODAY', 'TOMORROW', 'OVERDUE'].includes(rawFilters.deadline) ? rawFilters.deadline : undefined,
    };
    if (!question && !Object.values(filters).some(Boolean)) return res.status(400).json({ error: 'QUESTION_REQUIRED', message: 'Pertanyaan AI wajib diisi.' });

    try {
      let orders: AIOrderRecord[] = [];
      if (ctx.mode === 'supabase' && ctx.supabaseClient) {
        const { data, error } = await ctx.supabaseClient
          .from('orders')
          .select(`*, order_timeline(*), order_files(*)`)
          .eq('tenant_id', ctx.tenantId)
          .order('updated_at', { ascending: false });
        if (error) return res.status(500).json({ error: 'AI_DATA_READ_FAILED', message: `Gagal membaca Task Print dari Supabase: ${error.message}` });
        orders = (data || []).map(mapSupabaseOrder);
      } else {
        orders = db.orders.filter(o => o.tenantId === ctx.tenantId).map(mapDemoOrder);
      }

      const q = question.toLowerCase();
      const customerHint = extractCustomerPhrase(q, orders);
      const orderNumberHint = extractOrderNumber(q, orders);
      const effectiveFilters = { ...filters, customer: filters.customer || customerHint, orderNumber: filters.orderNumber || orderNumberHint };
      let matches = orders.filter(o => matchesQuestion(q, o, effectiveFilters));

      // If the query is generic, avoid returning completed orders unless explicitly asked for all history.
      if (!/semua\s+pesanan|semua\s+order|riwayat|selesai/.test(q) && /ringkasan|pesanan/.test(q) && !customerHint && !filters.status && !filters.deadline) {
        const active = matches.filter(o => o.status !== 'SELESAI');
        if (active.length) matches = active;
      }

      const answer = await polishWithGemini(question || 'Tampilkan data sesuai filter.', matches, makeAIAnswer(question || 'Tampilkan data sesuai filter.', matches));
      const responseOrders = matches.slice(0, 30).map(o => ({
        id: o.id, orderNumber: o.orderNumber, customerName: o.customerName, jobType: o.jobType, size: o.size,
        material: o.material, quantity: o.quantity, unit: o.unit, deadline: o.deadline, pic: o.pic,
        status: o.status, statusLabel: o.statusLabel, nextStep: o.nextStep, needsDesign: o.needsDesign, notes: o.notes,
        approvalInfo: approvalInfo(o),
      }));
      res.json({ answer, orders: responseOrders, dataUpdatedAt: new Date().toISOString(), source: ctx.mode, tenantId: ctx.tenantId });
    } catch (error: any) {
      console.error('AI Assistant Task Print error:', error);
      res.status(500).json({ error: 'AI_ASSISTANT_FAILED', message: 'AI Assistant gagal memproses permintaan.' });
    }
  });

  // ==========================================
  // ORDER MANAGEMENT (STRICT DATABASE ISOLATION)
  // ==========================================

  // Get Orders (STRICTLY FILTERED BY TENANT ID IN DATABASE)
  app.get('/api/orders', authenticateAuthToken, requireTenantIsolation, (req: AuthRequest, res: Response) => {
    const tenantId = req.user!.role === 'MASTER' ? (req.query.tenantId as string) : req.user!.tenantId;

    if (!tenantId && req.user!.role === 'MASTER') {
      return res.json(db.orders);
    }

    // Strict backend filter: return ONLY this tenant's orders
    const tenantOrders = db.orders.filter(o => o.tenantId === tenantId);
    res.json(tenantOrders);
  });

  // Get Single Order (Strict isolation check)
  app.get('/api/orders/:id', authenticateAuthToken, requireTenantIsolation, (req: AuthRequest, res: Response) => {
    const order = db.orders.find(o => o.id === req.params.id);
    if (!order) {
      return res.status(404).json({ error: 'Order tidak ditemukan.' });
    }

    // Tenant isolation verification
    if (req.user!.role !== 'MASTER' && order.tenantId !== req.user!.tenantId) {
      return res.status(403).json({
        error: 'Akses Ditolak: Order ini bukan milik tenant Anda.',
      });
    }

    res.json(order);
  });

  // Create Order (Admin / Staff within tenant)
  app.post('/api/orders', authenticateAuthToken, requireTenantIsolation, (req: AuthRequest, res: Response) => {
    const {
      customerName,
      customerWhatsapp,
      jobType,
      size,
      material,
      quantity,
      unit,
      finishing,
      deadline,
      notes,
      needsDesign,
      pic,
      initialFile,
    } = req.body;

    if (!customerName || !jobType || !quantity) {
      return res.status(400).json({ error: 'Nama konsumen, jenis pekerjaan, dan jumlah wajib diisi.' });
    }

    const tenantId = req.user!.tenantId!;
    const tenant = db.tenants.find(t => t.id === tenantId);
    const tenantCode = tenant ? tenant.code : 'ORD';

    // Auto-generate order number (e.g. CPD-202609-004)
    const now = new Date();
    const yearMonth = `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}`;
    const countThisMonth = db.orders.filter(o => o.tenantId === tenantId && o.orderNumber.includes(yearMonth)).length + 1;
    const orderNumber = `${tenantCode}-${yearMonth}-${String(countThisMonth).padStart(3, '0')}`;

    // Unguessable tracking token
    const trackingCode = `trk-${tenantCode.toLowerCase()}-${String(countThisMonth).padStart(3, '0')}-${Math.random().toString(36).substring(2, 7)}`;

    const files: OrderFile[] = [];
    if (initialFile && initialFile.name && initialFile.url) {
      files.push({
        id: `f-${Date.now()}`,
        name: initialFile.name,
        fileType: initialFile.fileType || 'application/octet-stream',
        category: initialFile.category || 'BRIEF_KONSUMEN',
        url: initialFile.url,
        size: initialFile.size || '1.0 MB',
        uploadedBy: req.user!.name,
        uploadedAt: now.toISOString(),
      });
    }

    const timeline: OrderTimelineEvent[] = [
      {
        id: `tl-${Date.now()}`,
        status: 'PESANAN_MASUK',
        title: 'Pesanan Masuk & Didaftarkan',
        note: `Order dibuat oleh ${req.user!.name}. ${needsDesign ? 'Membutuhkan bantuan desain.' : 'File siap cetak (tanpa desain).'}` ,
        actorName: req.user!.name,
        actorRole: req.user!.role,
        timestamp: now.toISOString(),
      },
    ];

    const newOrder: Order = {
      id: `ord-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      tenantId,
      orderNumber,
      trackingCode,
      customerName: customerName.trim(),
      customerWhatsapp: customerWhatsapp ? customerWhatsapp.replace(/[^0-9]/g, '') : '',
      jobType: jobType.trim(),
      size: size || '-',
      material: material || '-',
      quantity: Number(quantity) || 1,
      unit: unit || 'pcs',
      finishing: finishing || 'Tanpa finishing tambahan',
      deadline: deadline ? new Date(deadline).toISOString() : new Date(Date.now() + 86400000 * 2).toISOString(),
      notes: notes || '',
      needsDesign: Boolean(needsDesign),
      pic: pic || req.user!.name,
      status: 'PESANAN_MASUK',
      files,
      timeline,
      createdAt: now.toISOString(),
      updatedAt: now.toISOString(),
    };

    db.orders.unshift(newOrder);
    saveDatabase();

    res.status(201).json(newOrder);
  });

  // Advance Order Workflow Status
  // Pesanan Masuk -> Verifikasi -> Desain -> Approval -> Produksi/Cetak -> Finishing + QC -> Siap Diambil/Dikirim -> Selesai
  // Shortcut rule: "Jika tidak membutuhkan desain, langsung ke Produksi."
  app.patch('/api/orders/:id/status', authenticateAuthToken, requireTenantIsolation, (req: AuthRequest, res: Response) => {
    const { id } = req.params;
    const { nextStatus, note } = req.body;

    const order = db.orders.find(o => o.id === id);
    if (!order) {
      return res.status(404).json({ error: 'Order tidak ditemukan.' });
    }

    // Strict Tenant Isolation Verification
    if (req.user!.role !== 'MASTER' && order.tenantId !== req.user!.tenantId) {
      return res.status(403).json({ error: 'Akses Ditolak: Order bukan milik tenant Anda.' });
    }

    const validStatuses: OrderStatus[] = [
      'PESANAN_MASUK',
      'VERIFIKASI',
      'DESAIN',
      'APPROVAL',
      'PRODUKSI_CETAK',
      'FINISHING_QC',
      'SIAP_DIAMBIL_DIKIRIM',
      'SELESAI',
    ];

    if (!validStatuses.includes(nextStatus)) {
      return res.status(400).json({ error: 'Status alur tidak valid.' });
    }

    const prevStatus = order.status;
    order.status = nextStatus;
    order.updatedAt = new Date().toISOString();

    const titlesMap: Record<OrderStatus, string> = {
      PESANAN_MASUK: 'Pesanan Masuk',
      VERIFIKASI: 'Verifikasi Spesifikasi & Kelayakan',
      DESAIN: 'Proses Pengerjaan Desain',
      APPROVAL: 'Menunggu Approval Konsumen',
      PRODUKSI_CETAK: 'Proses Produksi / Cetak',
      FINISHING_QC: 'Tahap Finishing & Quality Control',
      SIAP_DIAMBIL_DIKIRIM: 'Siap Diambil / Siap Dikirim',
      SELESAI: 'Pesanan Selesai Diterima',
    };

    order.timeline.push({
      id: `tl-${Date.now()}`,
      status: nextStatus,
      title: titlesMap[nextStatus],
      note: note || `Status diperbarui dari ${titlesMap[prevStatus]} menjadi ${titlesMap[nextStatus]}.`,
      actorName: req.user!.name,
      actorRole: req.user!.role,
      timestamp: new Date().toISOString(),
    });

    saveDatabase();
    res.json(order);
  });

  // Attach File to Order
  app.post('/api/orders/:id/files', authenticateAuthToken, requireTenantIsolation, (req: AuthRequest, res: Response) => {
    const { id } = req.params;
    const { name, url, fileType, size, category } = req.body;

    const order = db.orders.find(o => o.id === id);
    if (!order) {
      return res.status(404).json({ error: 'Order tidak ditemukan.' });
    }

    if (req.user!.role !== 'MASTER' && order.tenantId !== req.user!.tenantId) {
      return res.status(403).json({ error: 'Akses Ditolak: Order bukan milik tenant Anda.' });
    }

    if (!name || !url) {
      return res.status(400).json({ error: 'Nama dan data file wajib diisi.' });
    }

    const newFile: OrderFile = {
      id: `file-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      name,
      fileType: fileType || 'application/octet-stream',
      category: category || 'FILE_DESAIN',
      url,
      size: size || '1.0 MB',
      uploadedBy: req.user!.name,
      uploadedAt: new Date().toISOString(),
    };

    order.files.push(newFile);
    order.timeline.push({
      id: `tl-${Date.now()}`,
      status: order.status,
      title: 'File Ditambahkan',
      note: `${req.user!.name} mengunggah berkas: ${name} (${category || 'Berkas'})`,
      actorName: req.user!.name,
      actorRole: req.user!.role,
      timestamp: new Date().toISOString(),
    });
    order.updatedAt = new Date().toISOString();

    saveDatabase();
    res.status(201).json(order);
  });

  // Delete Order (Admin only)
  app.delete('/api/orders/:id', authenticateAuthToken, requireTenantIsolation, requireAdminRole, (req: AuthRequest, res: Response) => {
    const { id } = req.params;
    const orderIndex = db.orders.findIndex(o => o.id === id);
    if (orderIndex === -1) {
      return res.status(404).json({ error: 'Order tidak ditemukan.' });
    }

    const order = db.orders[orderIndex];
    if (req.user!.role !== 'MASTER' && order.tenantId !== req.user!.tenantId) {
      return res.status(403).json({ error: 'Akses Ditolak: Order bukan milik tenant Anda.' });
    }

    db.orders.splice(orderIndex, 1);
    saveDatabase();
    res.json({ message: 'Order berhasil dihapus.' });
  });

  // ==========================================
  // CLIENT TRACKING (PUBLIC - STRICTLY PREMIUM ONLY!)
  // ==========================================
  // "Hanya aktif pada tenant dengan paket PREMIUM. Konsumen dapat melihat progres order melalui link tracking atau QR Code tanpa login. Basic tidak mendapatkan fitur tracking."
  app.get('/api/tracking/:code', (req: Request, res: Response) => {
    const { code } = req.params;

    // Support lookup by trackingCode OR orderNumber
    const order = db.orders.find(o => o.trackingCode === code || o.orderNumber === code);
    if (!order) {
      return res.status(404).json({
        error: 'ORDER_NOT_FOUND',
        message: 'Nomor order atau kode tracking tidak ditemukan. Silakan periksa kembali tautan Anda.',
      });
    }

    const tenant = db.tenants.find(t => t.id === order.tenantId);
    if (!tenant) {
      return res.status(404).json({ error: 'Tenant tidak ditemukan.' });
    }

    // CHECK PLAN: BASIC vs PREMIUM
    if (tenant.plan !== 'PREMIUM') {
      return res.status(403).json({
        error: 'TRACKING_DISABLED',
        plan: tenant.plan,
        tenantName: tenant.name,
        message: 'Bisnis percetakan ini menggunakan paket BASIC (Rp150.000). Fitur Client Tracking dan QR Code hanya aktif untuk paket PREMIUM (Rp300.000). Silakan hubungi percetakan secara langsung untuk menanyakan status pesanan Anda.',
      });
    }

    // Return sanitized public tracking info
    res.json({
      orderNumber: order.orderNumber,
      trackingCode: order.trackingCode,
      tenantName: tenant.name,
      tenantPhone: tenant.phone,
      tenantAddress: tenant.address,
      customerName: order.customerName,
      jobType: order.jobType,
      size: order.size,
      material: order.material,
      quantity: order.quantity,
      unit: order.unit,
      finishing: order.finishing,
      deadline: order.deadline,
      status: order.status,
      needsDesign: order.needsDesign,
      timeline: order.timeline,
      updatedAt: order.updatedAt,
      filesCount: order.files.length,
    });
  });

  // ==========================================
  // VITE MIDDLEWARE SETUP
  // ==========================================
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`AlurCetak Server running on port ${PORT}`);
  });
}

startServer();
